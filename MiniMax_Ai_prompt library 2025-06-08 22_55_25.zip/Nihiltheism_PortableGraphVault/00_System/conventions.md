# Nihiltheism Vault Conventions

## File Naming
- Main: `{id}_{Title}.md`
- Sub: `{id}_{Title}.md` 
- Detail: `{id}_{Title}.md`

## YAML Requirements
- Mandatory frontmatter with id, title, level, parent, children
- Tags: ["Nihiltheism", "Level{X}", domain]
- Category, domain, importance metadata

## Content Structure
1. ❶ Definition
2. ❷ Semantic Core
3. ❸ Parent Reference
4. ❹ Sibling Links
5. ❺ Cousin Reference
6. ❶ Transversal Insight
7. ❼ Vault Traceback

## Philosophical Standards
- Authentic content from source materials
- No speculation beyond documented concepts
- Maintain philosophical rigor and accuracy
