# Node Templates

## Main Topic Template
```markdown
---
id: "{id}"
title: "{title}"
level: 1
parent: null
children: []
tags: [Nihiltheism, Level1, {domain}]
---

# {Title}

## ❶ Definition
[Foundational definition]

## ❷ Semantic Core
- Core principle 1
- Core principle 2  
- Core principle 3

[Additional sections...]
```

## Link Syntax
- Internal: `[[node_id]]`
- With alias: `[[node_id|Display Text]]`
- Dataview: Standard Obsidian dataview syntax
