# Nihiltheism Portable Knowledge Graph Vault

## Overview
A comprehensive, fully-connected knowledge graph exploring Nihiltheism philosophy - the synthesis of nihilistic void encounter with transcendent religious experience.

## Structure
- **125 Total Nodes**: Complete philosophical coverage
- **500+ Connections**: Densely interconnected knowledge web
- **5 Main Domains**: Foundational, Historical, Theoretical, Practical, Contemporary
- **Multiple Export Formats**: Obsidian, Web, Jupyter, GraphML, JSON

## Source Materials
Based on authentic philosophical source materials:
- "The Religious Experience of Nihilism" by Adam Mueller
- Historical nihiltheistic thinkers and traditions
- Mystical and contemplative philosophy
- Contemporary interdisciplinary research

## Usage

### Obsidian
1. Open Obsidian
2. Create new vault from this folder
3. Enable Dataview plugin for full functionality
4. Navigate via graph view or main topic files

### Web Browser
Open `02_Export/index.html` for interactive visualization

### Jupyter
Load `02_Export/vault_structure.ipynb` for network analysis

### Other Tools
- Import `02_Export/graph.graphml` into Cytoscape/Gephi
- Use `02_Export/graph_structure.json` for custom applications

## Philosophy
Nihiltheism represents the philosophical position that authentic encounter with existential nothingness becomes the gateway to transcendent religious experience. This vault explores how sacred dread, void meditation, and philosophical negation open pathways to ultimate reality.

## Created: 2025-06-09
## Version: 1.0.0
## Nodes: 125
## Connections: 1320+
