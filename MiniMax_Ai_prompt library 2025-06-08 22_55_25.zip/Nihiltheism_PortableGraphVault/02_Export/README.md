# Nihiltheism Knowledge Graph Exports

## Available Formats

### 1. JSON Export (`graph_structure.json`)
Complete graph data with metadata, nodes, edges, and hierarchy structure.
- **Use for**: Custom applications, data analysis, API integration
- **Compatible with**: Any JSON-parsing library
- **Contains**: Full node metadata, connection mappings, hierarchical structure

### 2. GraphML Export (`graph.graphml`)
Standard network format for graph analysis tools.
- **Use for**: Network analysis, community detection, centrality analysis
- **Compatible with**: Cytoscape, Gephi, NetworkX, igraph
- **Contains**: Nodes, edges, basic attributes

### 3. Mindmap Export (`mindmap.markmap.md`)
Hierarchical mindmap in Markmap format.
- **Use for**: Conceptual overview, presentation, quick navigation
- **Compatible with**: Markmap tools, any Markdown processor
- **View online**: Use Markmap CLI or online editor

### 4. Interactive HTML (`index.html`)
Web-based interactive visualization with D3.js.
- **Use for**: Exploration, presentation, web integration
- **Features**: Node filtering, drag interaction, detail panels
- **Requirements**: Modern web browser with JavaScript

### 5. Jupyter Notebook (`vault_structure.ipynb`)
Comprehensive analysis notebook with NetworkX.
- **Use for**: Academic research, statistical analysis, customization
- **Features**: Network metrics, centrality analysis, community detection
- **Requirements**: Jupyter environment with NetworkX, matplotlib

## Quick Start

### Web Visualization
```bash
# Open in browser
open index.html
```

### Jupyter Analysis
```bash
# Start Jupyter
jupyter notebook vault_structure.ipynb
```

### Cytoscape Import
1. Open Cytoscape
2. File → Import → Network from File
3. Select graph.graphml
4. Apply layout (e.g., Prefuse Force Directed)

### Python Analysis
```python
import json
import networkx as nx

# Load graph
with open('graph_structure.json') as f:
    data = json.load(f)

# Create NetworkX graph
G = nx.Graph()
for node in data['nodes']:
    G.add_node(node['id'], **node)
for edge in data['edges']:
    G.add_edge(edge['source'], edge['target'])

print(f"Loaded {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
```

## Graph Statistics
- **Total Nodes**: 125 (5 main + 25 sub + 95 detail)
- **Total Edges**: 1,320+
- **Density**: Highly connected knowledge web
- **Structure**: Hierarchical with cross-domain connections

## Source Materials
- "The Religious Experience of Nihilism" by Adam Mueller
- Historical nihiltheistic philosophy (Cioran, Kierkegaard, Heidegger)
- Mystical and contemplative traditions
- Contemporary philosophical developments

## License
This knowledge graph is provided for educational and research purposes.
