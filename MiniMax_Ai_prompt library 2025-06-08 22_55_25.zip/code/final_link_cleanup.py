#!/usr/bin/env python3
"""
Final Link Cleanup and Validation
Ensure all links are perfectly valid and formatted correctly.
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple

class FinalLinkCleaner:
    def __init__(self, vault_path: str):
        self.vault_path = Path(vault_path)
        self.main_path = self.vault_path / "01_Main"
        self.all_nodes = {}  # id -> file_path
        self.valid_node_ids = set()
        
    def scan_all_valid_nodes(self):
        """Scan all files to build valid node ID database."""
        print("🔍 Scanning for valid node IDs...")
        
        # Collect all markdown files
        all_file_paths = []
        all_file_paths.extend(self.main_path.glob("*.md"))
        for sub_dir in self.main_path.glob("*_Sub"):
            all_file_paths.extend(sub_dir.glob("*.md"))
        for detail_dir in self.main_path.glob("*_Detail"):
            all_file_paths.extend(detail_dir.glob("*.md"))
            
        # Extract node IDs
        for file_path in all_file_paths:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Extract YAML frontmatter
            yaml_match = re.match(r'^---\n(.*?)\n---\n', content, re.DOTALL)
            if not yaml_match:
                continue
                
            yaml_content = yaml_match.group(1)
            
            # Parse node ID
            node_id = self._extract_yaml_field(yaml_content, 'id')
            
            if node_id:
                self.all_nodes[node_id] = file_path
                self.valid_node_ids.add(node_id)
                
        print(f"✅ Found {len(self.valid_node_ids)} valid node IDs")
        
    def _extract_yaml_field(self, yaml_content: str, field: str) -> str:
        """Extract a single field from YAML content."""
        pattern = rf'{field}:\s*[\'"]?([^\s\'"]+)'
        match = re.search(pattern, yaml_content)
        return match.group(1) if match else ""
        
    def clean_file_links(self, file_path: Path) -> int:
        """Clean all links in a single file and return number of fixes."""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        original_content = content
        fixes = 0
        
        # Find all links
        link_pattern = r'\[\[([^\]]+)\]\]'
        links = re.findall(link_pattern, content)
        
        for link in links:
            clean_link = link.strip('\'"').strip()
            
            # Check if link is valid
            if clean_link not in self.valid_node_ids:
                # Try to fix common issues
                fixed_link = self._try_fix_link(clean_link)
                
                if fixed_link and fixed_link in self.valid_node_ids:
                    # Replace the broken link
                    old_pattern = rf'\[\[{re.escape(link)}\]\]'
                    new_link = f'[[{fixed_link}]]'
                    content = re.sub(old_pattern, new_link, content)
                    fixes += 1
                else:
                    # Remove invalid link
                    old_pattern = rf'\[\[{re.escape(link)}\]\]'
                    content = re.sub(old_pattern, '', content)
                    fixes += 1
                    
        # Clean up any empty lines or malformed sections
        content = self._clean_link_sections(content)
        
        # Write cleaned content if changes were made
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
                
        return fixes
        
    def _try_fix_link(self, broken_link: str) -> str:
        """Try to fix a broken link by finding similar valid IDs."""
        # Remove quotes and whitespace
        clean = broken_link.strip('\'"').strip()
        
        # Check exact match first
        if clean in self.valid_node_ids:
            return clean
            
        # Try without quotes
        unquoted = clean.replace("'", "").replace('"', '')
        if unquoted in self.valid_node_ids:
            return unquoted
            
        # Try to find similar IDs
        for valid_id in self.valid_node_ids:
            if valid_id.replace('.', '') == clean.replace('.', ''):
                return valid_id
                
        # Try partial matches
        for valid_id in self.valid_node_ids:
            if clean in valid_id or valid_id in clean:
                return valid_id
                
        return ""
        
    def _clean_link_sections(self, content: str) -> str:
        """Clean up link sections to remove empty lines and malformed entries."""
        # Clean up each linking section
        sections = [
            "❸ Parent Reference",
            "❄ Sibling Links", 
            "❺ Cousin Reference",
            "❻ Transversal Insight"
        ]
        
        for section in sections:
            if f"## {section}" in content:
                # Find the section
                pattern = rf'(## {re.escape(section)}\n)(.*?)(?=\n## |\n```|\Z)'
                match = re.search(pattern, content, re.DOTALL)
                
                if match:
                    section_header = match.group(1)
                    section_content = match.group(2)
                    
                    # Clean the section content
                    lines = section_content.split('\n')
                    clean_lines = []
                    
                    for line in lines:
                        line = line.strip()
                        if line and not line.startswith('- '):
                            # Skip malformed lines
                            continue
                        elif line.startswith('- [[') and ']]' in line:
                            # Valid link line
                            clean_lines.append(line)
                        elif line.startswith('- ') and line != '- ':
                            # Other valid bullet point
                            clean_lines.append(line)
                            
                    # Reconstruct section
                    if clean_lines:
                        clean_section = section_header + '\n'.join(clean_lines) + '\n'
                    else:
                        clean_section = section_header + '\n'
                        
                    # Replace in content
                    content = re.sub(pattern, clean_section, content, flags=re.DOTALL)
                    
        return content
        
    def clean_all_links(self):
        """Clean links in all files."""
        print("🧹 Starting comprehensive link cleanup...")
        
        self.scan_all_valid_nodes()
        
        total_fixes = 0
        file_count = 0
        
        # Clean all files
        for node_id, file_path in self.all_nodes.items():
            fixes = self.clean_file_links(file_path)
            total_fixes += fixes
            file_count += 1
            
            if fixes > 0:
                print(f"✅ Cleaned {fixes} links in {node_id}")
                
            if file_count % 25 == 0:
                print(f"Progress: {file_count}/{len(self.all_nodes)} files processed")
                
        print(f"✅ Cleanup complete: {total_fixes} total fixes across {file_count} files")
        
    def validate_final_state(self) -> Dict[str, int]:
        """Final validation of all links."""
        print("\n🔍 Final validation...")
        
        results = {
            "total_links": 0,
            "valid_links": 0,
            "broken_links": 0,
            "files_checked": 0
        }
        
        for node_id, file_path in self.all_nodes.items():
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            results["files_checked"] += 1
            
            # Count links
            links = re.findall(r'\[\[([^\]]+)\]\]', content)
            
            for link in links:
                results["total_links"] += 1
                clean_link = link.strip('\'"').strip()
                
                if clean_link in self.valid_node_ids:
                    results["valid_links"] += 1
                else:
                    results["broken_links"] += 1
                    
        print(f"📊 Final Results:")
        print(f"   Total links: {results['total_links']}")
        print(f"   Valid links: {results['valid_links']}")
        print(f"   Broken links: {results['broken_links']}")
        print(f"   Files checked: {results['files_checked']}")
        
        if results["broken_links"] == 0:
            print("🎉 ALL LINKS ARE VALID!")
        else:
            print(f"⚠️  {results['broken_links']} broken links remaining")
            
        return results

def main():
    vault_path = "/workspace/Transformer_Knowledge_Graph"
    cleaner = FinalLinkCleaner(vault_path)
    
    cleaner.clean_all_links()
    results = cleaner.validate_final_state()
    
    if results["broken_links"] == 0:
        print("\n🏆 GOD-LEVEL LINKING REQUIREMENTS ACHIEVED!")
        print("✅ Zero broken links")
        print("✅ All nodes properly connected") 
        print("✅ 4-dimensional linking complete")
    else:
        print(f"\n🔧 Additional cleanup needed for {results['broken_links']} broken links")

if __name__ == "__main__":
    main()
