#!/usr/bin/env python3
"""
Extract complete content from Word document (.docx) preserving structure and formatting.
"""

import sys
from pathlib import Path

def install_dependencies():
    """Install required dependencies."""
    import subprocess
    try:
        import docx
        print("python-docx already installed")
    except ImportError:
        print("Installing python-docx...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "python-docx"])
        import docx

def extract_docx_content(docx_path, output_path):
    """Extract all content from a .docx file preserving structure."""
    try:
        from docx import Document
        from docx.shared import Inches
        import re
        
        print(f"Extracting content from: {docx_path}")
        
        # Load the document
        doc = Document(docx_path)
        
        extracted_content = []
        extracted_content.append("=" * 80)
        extracted_content.append("COMPLETE EXTRACTION: The Religious Experience of Nihilism")
        extracted_content.append("=" * 80)
        extracted_content.append(f"Source: {docx_path}")
        extracted_content.append(f"Extraction Date: 2025-06-09")
        extracted_content.append("=" * 80)
        extracted_content.append("")
        
        # Extract document properties if available
        try:
            core_props = doc.core_properties
            if core_props.title:
                extracted_content.append(f"Document Title: {core_props.title}")
            if core_props.author:
                extracted_content.append(f"Author: {core_props.author}")
            if core_props.subject:
                extracted_content.append(f"Subject: {core_props.subject}")
            if core_props.created:
                extracted_content.append(f"Created: {core_props.created}")
            if core_props.modified:
                extracted_content.append(f"Modified: {core_props.modified}")
            extracted_content.append("")
        except Exception as e:
            print(f"Could not extract document properties: {e}")
        
        # Track heading levels and structure
        current_section = ""
        paragraph_count = 0
        
        # Process all paragraphs
        for para in doc.paragraphs:
            paragraph_count += 1
            text = para.text.strip()
            
            if not text:
                extracted_content.append("")
                continue
                
            # Detect heading styles
            style_name = para.style.name if para.style else "Normal"
            
            # Check if this is a heading
            if any(heading in style_name for heading in ["Heading", "Title"]):
                level = 1
                if "Heading 1" in style_name:
                    level = 1
                    extracted_content.append("")
                    extracted_content.append("# " + text)
                    current_section = text
                elif "Heading 2" in style_name:
                    level = 2
                    extracted_content.append("")
                    extracted_content.append("## " + text)
                elif "Heading 3" in style_name:
                    level = 3
                    extracted_content.append("")
                    extracted_content.append("### " + text)
                elif "Heading 4" in style_name:
                    level = 4
                    extracted_content.append("")
                    extracted_content.append("#### " + text)
                elif "Title" in style_name:
                    extracted_content.append("")
                    extracted_content.append("# " + text.upper())
                    extracted_content.append("=" * len(text))
                else:
                    extracted_content.append("")
                    extracted_content.append("## " + text)
            else:
                # Regular paragraph
                
                # Check for bold/italic formatting (basic detection)
                if para.runs:
                    formatted_text = ""
                    for run in para.runs:
                        run_text = run.text
                        if run.bold and run.italic:
                            formatted_text += f"***{run_text}***"
                        elif run.bold:
                            formatted_text += f"**{run_text}**"
                        elif run.italic:
                            formatted_text += f"*{run_text}*"
                        else:
                            formatted_text += run_text
                    
                    if formatted_text.strip():
                        extracted_content.append(formatted_text)
                else:
                    extracted_content.append(text)
            
            # Add spacing after paragraphs
            extracted_content.append("")
        
        # Process tables if any
        if doc.tables:
            extracted_content.append("")
            extracted_content.append("## TABLES")
            extracted_content.append("=" * 40)
            
            for i, table in enumerate(doc.tables):
                extracted_content.append(f"")
                extracted_content.append(f"### Table {i+1}")
                extracted_content.append("")
                
                for row in table.rows:
                    row_text = []
                    for cell in row.cells:
                        cell_text = cell.text.strip().replace('\n', ' ')
                        row_text.append(cell_text)
                    extracted_content.append(" | ".join(row_text))
                extracted_content.append("")
        
        # Write to output file
        output_content = "\n".join(extracted_content)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(output_content)
        
        print(f"Content extracted successfully to: {output_path}")
        print(f"Total paragraphs processed: {paragraph_count}")
        print(f"Total characters extracted: {len(output_content)}")
        
        # Return summary information
        return {
            "success": True,
            "paragraph_count": paragraph_count,
            "character_count": len(output_content),
            "sections_found": len([line for line in extracted_content if line.startswith("#")]),
            "output_file": output_path
        }
        
    except Exception as e:
        error_msg = f"Error extracting content: {str(e)}"
        print(error_msg)
        
        # Write error to output file
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(f"ERROR EXTRACTING CONTENT FROM: {docx_path}\n")
            f.write(f"Error: {error_msg}\n")
            f.write(f"Timestamp: 2025-06-09\n")
        
        return {
            "success": False,
            "error": error_msg,
            "output_file": output_path
        }

def main():
    """Main extraction function."""
    # Install dependencies
    install_dependencies()
    
    # Define paths
    input_file = "/workspace/user_input_files/The_Religious_Experience_of_Nihilism.docx"
    output_file = "/workspace/docs/religious_experience_content.txt"
    
    # Ensure output directory exists
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    
    # Extract content
    result = extract_docx_content(input_file, output_file)
    
    if result["success"]:
        print(f"\n✅ EXTRACTION SUCCESSFUL")
        print(f"📄 Input: {input_file}")
        print(f"📝 Output: {output_file}")
        print(f"📊 Paragraphs: {result['paragraph_count']}")
        print(f"📏 Characters: {result['character_count']:,}")
        print(f"🏗️ Sections: {result['sections_found']}")
    else:
        print(f"\n❌ EXTRACTION FAILED")
        print(f"🚫 Error: {result['error']}")
    
    return result

if __name__ == "__main__":
    main()
