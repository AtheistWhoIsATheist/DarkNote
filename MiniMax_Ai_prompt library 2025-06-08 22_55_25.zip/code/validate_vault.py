"""
GCN Knowledge Graph Validation Script
Validates the complete structure and integrity of the knowledge graph
"""

import os
import json
import yaml
from pathlib import Path
from collections import defaultdict
import re

class VaultValidator:
    def __init__(self, vault_path: str):
        self.vault_path = Path(vault_path)
        self.errors = []
        self.warnings = []
        self.stats = {}
        
    def validate_all(self):
        """Run complete validation suite"""
        print("🔍 Starting GCN Knowledge Graph Validation...")
        
        self.validate_directory_structure()
        self.validate_file_count()
        self.validate_yaml_frontmatter()
        self.validate_content_structure()
        self.validate_links()
        self.validate_exports()
        
        self.print_results()
        return len(self.errors) == 0
    
    def validate_directory_structure(self):
        """Validate directory structure exists"""
        required_dirs = [
            "00_System",
            "01_Main",
            "01_Main/1_Sub", "01_Main/2_Sub", "01_Main/3_Sub", "01_Main/4_Sub", "01_Main/5_Sub",
            "01_Main/1_Detail", "01_Main/2_Detail", "01_Main/3_Detail", "01_Main/4_Detail", "01_Main/5_Detail",
            "02_Export"
        ]
        
        for dir_path in required_dirs:
            full_path = self.vault_path / dir_path
            if not full_path.exists():
                self.errors.append(f"Missing directory: {dir_path}")
            elif not full_path.is_dir():
                self.errors.append(f"Not a directory: {dir_path}")
        
        print("✅ Directory structure validation complete")
    
    def validate_file_count(self):
        """Validate correct number of files"""
        # Count markdown files in each section
        main_files = list((self.vault_path / "01_Main").glob("*.md"))
        
        sub_files = []
        detail_files = []
        for i in range(1, 6):
            sub_files.extend(list((self.vault_path / f"01_Main/{i}_Sub").glob("*.md")))
            detail_files.extend(list((self.vault_path / f"01_Main/{i}_Detail").glob("*.md")))
        
        # Expected counts
        expected = {
            "main": 5,
            "sub": 25, 
            "detail": 125  # 5 per sub-topic × 25 sub-topics = 125
        }
        
        actual = {
            "main": len(main_files),
            "sub": len(sub_files),
            "detail": len(detail_files)
        }
        
        self.stats["file_counts"] = actual
        
        for category, expected_count in expected.items():
            if actual[category] != expected_count:
                self.errors.append(f"Incorrect {category} file count: expected {expected_count}, got {actual[category]}")
        
        total_content_files = sum(actual.values())
        if total_content_files == 125:
            print(f"✅ File count validation complete: {total_content_files}/125 files")
        else:
            print(f"❌ File count validation failed: {total_content_files}/125 files")
    
    def validate_yaml_frontmatter(self):
        """Validate YAML frontmatter in all files"""
        required_fields = ["id", "title", "level", "parent", "children", "tags", "alias", "created", "updated"]
        files_checked = 0
        
        for md_file in self.vault_path.rglob("*.md"):
            if md_file.parent.name in ["00_System", "02_Export"] or md_file.name == "README.md":
                continue  # Skip system, export files, and README
                
            try:
                with open(md_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Extract YAML frontmatter
                if content.startswith('---'):
                    yaml_end = content.find('---', 3)
                    if yaml_end != -1:
                        yaml_content = content[3:yaml_end].strip()
                        try:
                            frontmatter = yaml.safe_load(yaml_content)
                            
                            # Check required fields
                            for field in required_fields:
                                if field not in frontmatter:
                                    self.errors.append(f"Missing YAML field '{field}' in {md_file.name}")
                            
                            # Validate field types
                            if "level" in frontmatter and not isinstance(frontmatter["level"], int):
                                self.errors.append(f"Invalid level type in {md_file.name}")
                            
                            if "tags" in frontmatter and not isinstance(frontmatter["tags"], list):
                                self.errors.append(f"Invalid tags type in {md_file.name}")
                            
                            files_checked += 1
                            
                        except yaml.YAMLError as e:
                            self.errors.append(f"Invalid YAML in {md_file.name}: {e}")
                    else:
                        self.errors.append(f"Incomplete YAML frontmatter in {md_file.name}")
                else:
                    self.errors.append(f"Missing YAML frontmatter in {md_file.name}")
                    
            except Exception as e:
                self.errors.append(f"Error reading {md_file.name}: {e}")
        
        print(f"✅ YAML frontmatter validation complete: {files_checked} files checked")
    
    def validate_content_structure(self):
        """Validate content structure in all files"""
        required_sections = [
            "❶ Definition",
            "❷ Semantic Core", 
            "❸ Parent Reference",
            "❹ Sibling Links",
            "❺ Cousin Reference",
            "❻ Transversal Insight",
            "❼ Vault Traceback"
        ]
        
        files_checked = 0
        
        for md_file in self.vault_path.rglob("*.md"):
            if md_file.parent.name in ["00_System", "02_Export"] or md_file.name == "README.md":
                continue
                
            try:
                with open(md_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                for section in required_sections:
                    if section not in content:
                        self.warnings.append(f"Missing section '{section}' in {md_file.name}")
                
                files_checked += 1
                
            except Exception as e:
                self.errors.append(f"Error reading {md_file.name}: {e}")
        
        print(f"✅ Content structure validation complete: {files_checked} files checked")
    
    def validate_links(self):
        """Validate internal links"""
        all_node_ids = set()
        all_links = defaultdict(list)
        
        # First pass: collect all node IDs
        for md_file in self.vault_path.rglob("*.md"):
            if md_file.parent.name in ["00_System", "02_Export"] or md_file.name == "README.md":
                continue
                
            try:
                with open(md_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Extract node ID from YAML
                yaml_match = re.search(r'---\n(.*?)\n---', content, re.DOTALL)
                if yaml_match:
                    frontmatter = yaml.safe_load(yaml_match.group(1))
                    if "id" in frontmatter:
                        all_node_ids.add(frontmatter["id"])
                        
                        # Extract links
                        links = re.findall(r'\[\[([^\]]+)\]\]', content)
                        all_links[frontmatter["id"]] = links
            
            except Exception as e:
                self.errors.append(f"Error processing links in {md_file.name}: {e}")
        
        # Second pass: validate link targets
        broken_links = 0
        orphan_nodes = 0
        
        for node_id, links in all_links.items():
            # Check for broken links
            for link in links:
                if link not in all_node_ids:
                    self.warnings.append(f"Broken link in {node_id}: [[{link}]]")
                    broken_links += 1
            
            # Check for orphan nodes (no incoming links)
            if node_id != "1" and node_id != "2" and node_id != "3" and node_id != "4" and node_id != "5":
                has_incoming = False
                for other_node, other_links in all_links.items():
                    if node_id in other_links:
                        has_incoming = True
                        break
                if not has_incoming and "." in node_id:  # Only check non-main nodes
                    orphan_nodes += 1
                    self.warnings.append(f"Potential orphan node: {node_id}")
        
        self.stats["total_nodes"] = len(all_node_ids)
        self.stats["total_links"] = sum(len(links) for links in all_links.values())
        self.stats["broken_links"] = broken_links
        self.stats["orphan_nodes"] = orphan_nodes
        
        print(f"✅ Link validation complete: {self.stats['total_nodes']} nodes, {self.stats['total_links']} links")
    
    def validate_exports(self):
        """Validate export files exist and are valid"""
        export_files = [
            "graph_structure.json",
            "graph.graphml", 
            "mindmap.markmap.md",
            "index.html",
            "vault_structure.ipynb"
        ]
        
        export_dir = self.vault_path / "02_Export"
        
        for export_file in export_files:
            file_path = export_dir / export_file
            if not file_path.exists():
                self.errors.append(f"Missing export file: {export_file}")
            elif file_path.stat().st_size == 0:
                self.errors.append(f"Empty export file: {export_file}")
        
        # Validate JSON structure
        json_file = export_dir / "graph_structure.json"
        if json_file.exists():
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                required_keys = ["metadata", "nodes", "links"]
                for key in required_keys:
                    if key not in data:
                        self.errors.append(f"Missing key '{key}' in graph_structure.json")
                
            except json.JSONDecodeError as e:
                self.errors.append(f"Invalid JSON in graph_structure.json: {e}")
        
        print("✅ Export validation complete")
    
    def print_results(self):
        """Print validation results"""
        print("\n" + "="*60)
        print("🎯 GCN KNOWLEDGE GRAPH VALIDATION RESULTS")
        print("="*60)
        
        print(f"\n📊 STATISTICS:")
        for key, value in self.stats.items():
            print(f"  {key}: {value}")
        
        if self.errors:
            print(f"\n❌ ERRORS ({len(self.errors)}):")
            for error in self.errors:
                print(f"  • {error}")
        
        if self.warnings:
            print(f"\n⚠️  WARNINGS ({len(self.warnings)}):")
            for warning in self.warnings[:10]:  # Limit to first 10 warnings
                print(f"  • {warning}")
            if len(self.warnings) > 10:
                print(f"  ... and {len(self.warnings) - 10} more warnings")
        
        print(f"\n🎯 OVERALL STATUS:")
        if len(self.errors) == 0:
            print("  ✅ VALIDATION PASSED - Knowledge graph is ready for deployment!")
        else:
            print(f"  ❌ VALIDATION FAILED - {len(self.errors)} errors need to be fixed")
        
        print("="*60)

if __name__ == "__main__":
    validator = VaultValidator("/workspace/GCN_Knowledge_Graph")
    success = validator.validate_all()
    exit(0 if success else 1)
