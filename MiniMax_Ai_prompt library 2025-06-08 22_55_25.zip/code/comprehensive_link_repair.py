#!/usr/bin/env python3
"""
Comprehensive Link Repair and 4-Dimensional Linking Implementation
Fix all broken links and implement complete 4-dimensional linking strategy.
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple, Any
import random

class ComprehensiveLinkRepairer:
    def __init__(self, vault_path: str):
        self.vault_path = Path(vault_path)
        self.main_path = self.vault_path / "01_Main"
        
        # Node database
        self.all_nodes = {}  # id -> file_path
        self.node_metadata = {}  # id -> {title, level, parent, children, tags}
        self.main_topics = {}  # main_id -> [sub_ids]
        self.sub_topics = {}  # sub_id -> [detail_ids]
        
        # Linking strategy
        self.parent_child_links = {}  # child_id -> parent_id
        self.child_parent_links = {}  # parent_id -> [child_ids]
        self.sibling_groups = {}  # parent_id -> [sibling_ids]
        self.cousin_groups = {}  # main_topic -> [all_sub_ids]
        self.transversal_links = {}  # cross-topic connections
        
    def scan_all_nodes(self):
        """Scan all files and build comprehensive node database."""
        print("🔍 Scanning all nodes and building database...")
        
        # Collect all markdown files
        all_file_paths = []
        all_file_paths.extend(self.main_path.glob("*.md"))
        for sub_dir in self.main_path.glob("*_Sub"):
            all_file_paths.extend(sub_dir.glob("*.md"))
        for detail_dir in self.main_path.glob("*_Detail"):
            all_file_paths.extend(detail_dir.glob("*.md"))
            
        # Extract metadata from each file
        for file_path in all_file_paths:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Extract YAML frontmatter
            yaml_match = re.match(r'^---\n(.*?)\n---\n', content, re.DOTALL)
            if not yaml_match:
                continue
                
            yaml_content = yaml_match.group(1)
            
            # Parse YAML fields
            node_id = self._extract_yaml_field(yaml_content, 'id')
            title = self._extract_yaml_field(yaml_content, 'title')
            level = self._extract_yaml_field(yaml_content, 'level')
            parent = self._extract_yaml_field(yaml_content, 'parent')
            children = self._extract_yaml_list(yaml_content, 'children')
            tags = self._extract_yaml_list(yaml_content, 'tags')
            
            if node_id:
                self.all_nodes[node_id] = file_path
                self.node_metadata[node_id] = {
                    'title': title,
                    'level': int(level) if level else 0,
                    'parent': parent,
                    'children': children,
                    'tags': tags,
                    'file_path': file_path
                }
                
        print(f"✅ Found {len(self.all_nodes)} nodes")
        
    def _extract_yaml_field(self, yaml_content: str, field: str) -> str:
        """Extract a single field from YAML content."""
        pattern = rf'{field}:\s*[\'"]?([^\s\'"]+)'
        match = re.search(pattern, yaml_content)
        return match.group(1) if match else ""
        
    def _extract_yaml_list(self, yaml_content: str, field: str) -> List[str]:
        """Extract a list field from YAML content."""
        pattern = rf'{field}:\s*\[(.*?)\]'
        match = re.search(pattern, yaml_content, re.DOTALL)
        if match:
            list_content = match.group(1)
            items = re.findall(r'[\'"]?([^\s\'"]+)', list_content)
            return [item.strip('\'"') for item in items if item]
        return []
        
    def build_relationship_maps(self):
        """Build comprehensive relationship maps for all linking dimensions."""
        print("🔗 Building relationship maps...")
        
        # 1. Parent-Child relationships
        for node_id, metadata in self.node_metadata.items():
            if metadata['parent']:
                self.parent_child_links[node_id] = metadata['parent']
                
            if metadata['children']:
                self.child_parent_links[node_id] = metadata['children']
                
        # 2. Sibling relationships (same parent)
        for parent_id, children in self.child_parent_links.items():
            if len(children) > 1:
                self.sibling_groups[parent_id] = children
                
        # 3. Cousin relationships (same main topic, different sub-topics)
        for node_id, metadata in self.node_metadata.items():
            if metadata['level'] == 1:  # Main topics
                self.main_topics[node_id] = []
            elif metadata['level'] == 2:  # Sub-topics
                main_topic = node_id.split('.')[0]
                if main_topic not in self.main_topics:
                    self.main_topics[main_topic] = []
                self.main_topics[main_topic].append(node_id)
                
        # Build cousin groups
        for main_id, sub_ids in self.main_topics.items():
            self.cousin_groups[main_id] = sub_ids
            
        # 4. Transversal relationships (cross-topic connections)
        self._build_transversal_connections()
        
        print(f"✅ Built relationships for {len(self.all_nodes)} nodes")
        
    def _build_transversal_connections(self):
        """Build intelligent cross-topic transversal connections."""
        # Define conceptual connections between different main topics
        transversal_map = {
            # Topic 1 (Foundations) connects to...
            "1": ["2", "3", "4"],  # Attention, Training, Advanced
            "1.1": ["2.1", "4.1", "4.2"],  # Core concepts -> Attention basics, BERT, GPT
            "1.2": ["2.1", "2.2", "3.1"],  # Self-attention -> Scaled attention, Multi-head, Pre-training
            "1.3": ["2.5", "4.4"],  # Positional encoding -> Positioning, ViT
            "1.4": ["2.2", "2.3"],  # Multi-head -> Variants, Cross-attention
            "1.5": ["3.5", "4.5"],  # Feed-forward -> Regularization, Efficient
            
            # Topic 2 (Attention) connects to...
            "2": ["1", "3", "4"],
            "2.1": ["1.2", "3.3", "4.1"],  # Scaled attention -> Self-attention, Loss functions, BERT
            "2.2": ["1.4", "3.2", "4.5"],  # Multi-head variants -> Multi-head design, Fine-tuning, Efficient
            "2.3": ["1.1", "4.3", "5.1"],  # Cross-attention -> Core concepts, T5, NLP
            "2.4": ["3.4", "4.5", "5.2"],  # Sparse attention -> Optimization, Efficient, Vision
            "2.5": ["1.3", "4.4", "5.3"],  # Positioning -> Positional encoding, ViT, Multimodal
            
            # Topic 3 (Training) connects to...
            "3": ["1", "2", "4", "5"],
            "3.1": ["4.1", "4.2", "5.1"],  # Pre-training -> BERT, GPT, NLP
            "3.2": ["4.1", "4.3", "5.4"],  # Fine-tuning -> BERT, T5, Scientific
            "3.3": ["2.1", "4.2", "5.5"],  # Loss functions -> Scaled attention, GPT, Industry
            "3.4": ["2.4", "4.5", "5.5"],  # Optimization -> Sparse attention, Efficient, Industry
            "3.5": ["1.5", "4.5", "5.2"],  # Regularization -> Feed-forward, Efficient, Vision
            
            # Topic 4 (Advanced) connects to...
            "4": ["1", "2", "3", "5"],
            "4.1": ["1.2", "3.1", "5.1"],  # BERT -> Self-attention, Pre-training, NLP
            "4.2": ["1.1", "3.1", "5.1"],  # GPT -> Core concepts, Pre-training, NLP
            "4.3": ["2.3", "3.2", "5.1"],  # T5 -> Cross-attention, Fine-tuning, NLP
            "4.4": ["1.3", "2.5", "5.2"],  # ViT -> Positional encoding, Positioning, Vision
            "4.5": ["2.4", "3.4", "5.5"],  # Efficient -> Sparse attention, Optimization, Industry
            
            # Topic 5 (Applications) connects to...
            "5": ["1", "2", "3", "4"],
            "5.1": ["4.1", "4.2", "4.3"],  # NLP -> BERT, GPT, T5
            "5.2": ["4.4", "2.5", "1.3"],  # Vision -> ViT, Positioning, Positional encoding
            "5.3": ["2.3", "4.3", "3.2"],  # Multimodal -> Cross-attention, T5, Fine-tuning
            "5.4": ["3.1", "4.1", "4.3"],  # Scientific -> Pre-training, BERT, T5
            "5.5": ["3.4", "4.5", "2.4"],  # Industry -> Optimization, Efficient, Sparse attention
        }
        
        self.transversal_links = transversal_map
        
    def repair_single_file(self, node_id: str):
        """Repair linking structure for a single file."""
        if node_id not in self.all_nodes:
            return
            
        file_path = self.all_nodes[node_id]
        metadata = self.node_metadata[node_id]
        
        # Read current file
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Split into sections
        sections = content.split('\n## ')
        yaml_and_title = sections[0]
        
        # Preserve Definition and Semantic Core
        definition_section = ""
        semantic_section = ""
        
        for section in sections[1:]:
            if section.startswith('❶ Definition'):
                definition_section = '\n## ' + section
            elif section.startswith('❷ Semantic Core'):
                semantic_section = '\n## ' + section
                
        # Build new linking sections
        parent_section = self._build_parent_section(node_id, metadata)
        sibling_section = self._build_sibling_section(node_id, metadata)
        cousin_section = self._build_cousin_section(node_id, metadata)
        transversal_section = self._build_transversal_section(node_id, metadata)
        vault_section = self._build_vault_section(node_id)
        
        # Reconstruct file
        new_content = (yaml_and_title + 
                      definition_section + 
                      semantic_section +
                      parent_section +
                      sibling_section +
                      cousin_section +
                      transversal_section +
                      vault_section)
        
        # Write repaired file
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
            
        print(f"✅ Repaired: {node_id}")
        
    def _build_parent_section(self, node_id: str, metadata: Dict) -> str:
        """Build parent reference section."""
        parent_id = metadata.get('parent')
        if parent_id and parent_id in self.all_nodes:
            return f"\n\n## ❸ Parent Reference\n- [[{parent_id}]]"
        else:
            return f"\n\n## ❸ Parent Reference\n"
            
    def _build_sibling_section(self, node_id: str, metadata: Dict) -> str:
        """Build sibling links section."""
        parent_id = metadata.get('parent')
        siblings = []
        
        if parent_id and parent_id in self.child_parent_links:
            all_children = self.child_parent_links[parent_id]
            siblings = [child for child in all_children if child != node_id and child in self.all_nodes]
            
        if siblings:
            sibling_links = '\n'.join([f"- [[{sibling}]]" for sibling in siblings[:3]])  # Limit to 3
            return f"\n\n## ❹ Sibling Links\n{sibling_links}"
        else:
            return f"\n\n## ❹ Sibling Links\n"
            
    def _build_cousin_section(self, node_id: str, metadata: Dict) -> str:
        """Build cousin reference section."""
        level = metadata.get('level', 0)
        cousins = []
        
        if level == 2:  # Sub-topic
            main_topic = node_id.split('.')[0]
            if main_topic in self.cousin_groups:
                cousins = [cousin for cousin in self.cousin_groups[main_topic] 
                          if cousin != node_id and cousin in self.all_nodes]
        elif level == 3:  # Detail node
            # Find cousins in same main topic but different sub-topics
            parts = node_id.split('.')
            if len(parts) >= 2:
                main_topic = parts[0]
                current_sub = f"{parts[0]}.{parts[1]}"
                
                # Find other sub-topics in same main topic
                other_subs = [sub_id for sub_id in self.cousin_groups.get(main_topic, []) 
                             if sub_id != current_sub]
                
                # Pick detail nodes from other sub-topics
                for other_sub in other_subs[:2]:  # Limit to 2 sub-topics
                    if other_sub in self.child_parent_links:
                        detail_nodes = self.child_parent_links[other_sub]
                        if detail_nodes:
                            cousins.append(detail_nodes[0])  # Take first detail node
                            
        if cousins:
            cousin_links = '\n'.join([f"- [[{cousin}]]" for cousin in cousins[:2]])  # Limit to 2
            return f"\n\n## ❺ Cousin Reference\n{cousin_links}"
        else:
            return f"\n\n## ❺ Cousin Reference\n"
            
    def _build_transversal_section(self, node_id: str, metadata: Dict) -> str:
        """Build transversal insight section."""
        transversals = self.transversal_links.get(node_id, [])
        
        # Filter to existing nodes
        valid_transversals = [t for t in transversals if t in self.all_nodes]
        
        if valid_transversals:
            transversal_links = '\n'.join([f"- [[{trans}]]" for trans in valid_transversals[:2]])  # Limit to 2
            return f"\n\n## ❻ Transversal Insight\n{transversal_links}"
        else:
            # Find any cross-topic connection as fallback
            level = metadata.get('level', 0)
            main_topic = node_id.split('.')[0]
            
            # Find nodes from different main topics
            fallback_transversals = []
            for other_node_id in self.all_nodes:
                other_main = other_node_id.split('.')[0]
                other_level = self.node_metadata.get(other_node_id, {}).get('level', 0)
                
                if (other_main != main_topic and 
                    other_level == level and 
                    len(fallback_transversals) < 2):
                    fallback_transversals.append(other_node_id)
                    
            if fallback_transversals:
                transversal_links = '\n'.join([f"- [[{trans}]]" for trans in fallback_transversals])
                return f"\n\n## ❻ Transversal Insight\n{transversal_links}"
            else:
                return f"\n\n## ❻ Transversal Insight\n"
                
    def _build_vault_section(self, node_id: str) -> str:
        """Build vault traceback section."""
        return f"""
## ❼ Vault Traceback
```dataview
TABLE id, file.name
WHERE contains(tags, "Transformer") AND id = "{node_id}"
```"""

    def repair_all_links(self):
        """Repair all broken links and implement 4-dimensional linking."""
        print("🛠️ Starting comprehensive link repair...")
        
        # Scan and build database
        self.scan_all_nodes()
        self.build_relationship_maps()
        
        # Repair each file
        total_files = len(self.all_nodes)
        for i, node_id in enumerate(self.all_nodes.keys()):
            self.repair_single_file(node_id)
            if (i + 1) % 25 == 0:
                print(f"Progress: {i + 1}/{total_files} files repaired")
                
        print(f"✅ All {total_files} files repaired with 4-dimensional linking")
        
    def validate_repairs(self) -> Dict[str, Any]:
        """Validate that all repairs were successful."""
        print("\n🔍 Validating repair results...")
        
        results = {
            "total_links": 0,
            "valid_links": 0,
            "broken_links": 0,
            "files_with_complete_linking": 0,
            "orphan_nodes": 0
        }
        
        all_referenced_nodes = set()
        
        # Check each file
        for node_id, file_path in self.all_nodes.items():
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Check for complete linking structure
            has_parent = "❸ Parent Reference" in content
            has_sibling = "❹ Sibling Links" in content
            has_cousin = "❺ Cousin Reference" in content
            has_transversal = "❻ Transversal Insight" in content
            has_vault = "❼ Vault Traceback" in content
            
            if all([has_parent, has_sibling, has_cousin, has_transversal, has_vault]):
                results["files_with_complete_linking"] += 1
                
            # Count and validate links
            links = re.findall(r'\[\[([^\]]+)\]\]', content)
            for link in links:
                results["total_links"] += 1
                clean_link = link.strip('\'"')
                if clean_link in self.all_nodes:
                    results["valid_links"] += 1
                    all_referenced_nodes.add(clean_link)
                else:
                    results["broken_links"] += 1
                    
        # Count orphan nodes
        orphans = set(self.all_nodes.keys()) - all_referenced_nodes
        results["orphan_nodes"] = len(orphans)
        
        print(f"✅ Complete linking structure: {results['files_with_complete_linking']}/{len(self.all_nodes)} files")
        print(f"✅ Valid links: {results['valid_links']}/{results['total_links']}")
        print(f"❌ Broken links: {results['broken_links']}")
        print(f"⚠️  Orphan nodes: {results['orphan_nodes']}")
        
        return results

def main():
    vault_path = "/workspace/Transformer_Knowledge_Graph"
    repairer = ComprehensiveLinkRepairer(vault_path)
    
    # Execute comprehensive repair
    repairer.repair_all_links()
    
    # Validate results
    results = repairer.validate_repairs()
    
    # Report final status
    if results["broken_links"] == 0 and results["orphan_nodes"] == 0:
        print("\n🎉 LINK REPAIR COMPLETE - GOD-LEVEL REQUIREMENTS MET!")
        print("✅ Zero broken links")
        print("✅ Zero orphan nodes") 
        print("✅ 4-dimensional linking implemented")
    else:
        print(f"\n⚠️  Additional work needed:")
        print(f"   - Broken links: {results['broken_links']}")
        print(f"   - Orphan nodes: {results['orphan_nodes']}")

if __name__ == "__main__":
    main()
