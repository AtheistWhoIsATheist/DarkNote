#!/usr/bin/env python3
"""
Export Generator for Transformer Knowledge Graph

Creates multiple export formats for maximum portability:
- JSON (complete graph structure)
- GraphML (Cytoscape/Gephi)
- Markmap (interactive mind mapping)
- HTML (D3.js visualization)
- Jupyter (NetworkX analysis)
- README (deployment instructions)

Author: Research Agent
Date: 2025-06-09
"""

import os
import json
import yaml
from pathlib import Path
import networkx as nx
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.dom import minidom

class TransformerExportGenerator:
    def __init__(self, vault_path="/workspace/Transformer_Knowledge_Graph"):
        self.vault_path = Path(vault_path)
        self.export_path = self.vault_path / "02_Export"
        self.export_path.mkdir(exist_ok=True)
        
        # Graph data structure
        self.graph_data = {
            "nodes": [],
            "links": [],
            "metadata": {
                "title": "Transformer Architecture Knowledge Graph",
                "version": "1.0.0",
                "created": "2025-06-09",
                "total_nodes": 125,
                "total_links": 0,
                "levels": 3,
                "branching_factor": 5
            }
        }
        
        # NetworkX graph for analysis
        self.nx_graph = nx.DiGraph()

    def parse_yaml_frontmatter(self, file_path):
        """Extract YAML frontmatter from markdown file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if content.startswith('---'):
            parts = content.split('---', 2)
            if len(parts) >= 3:
                yaml_content = parts[1]
                try:
                    return yaml.safe_load(yaml_content)
                except yaml.YAMLError:
                    return {}
        return {}

    def extract_links_from_content(self, content):
        """Extract wiki-style links [[link]] from content."""
        import re
        link_pattern = r'\[\[([^\]]+)\]\]'
        matches = re.findall(link_pattern, content)
        return matches

    def scan_vault_files(self):
        """Scan all vault files and extract graph structure."""
        print("🔍 Scanning vault files...")
        
        # Find all markdown files
        md_files = []
        for root, dirs, files in os.walk(self.vault_path / "01_Main"):
            for file in files:
                if file.endswith('.md'):
                    md_files.append(Path(root) / file)
        
        # Process each file
        for file_path in md_files:
            frontmatter = self.parse_yaml_frontmatter(file_path)
            
            if 'id' in frontmatter:
                # Read full content for link extraction
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Extract links from content
                content_links = self.extract_links_from_content(content)
                
                # Create node data
                node = {
                    "id": frontmatter['id'],
                    "title": frontmatter.get('title', ''),
                    "level": frontmatter.get('level', 1),
                    "parent": frontmatter.get('parent'),
                    "children": frontmatter.get('children', []),
                    "tags": frontmatter.get('tags', []),
                    "alias": frontmatter.get('alias', []),
                    "created": frontmatter.get('created', ''),
                    "updated": frontmatter.get('updated', ''),
                    "file_path": str(file_path.relative_to(self.vault_path)),
                    "content_links": content_links
                }
                
                self.graph_data["nodes"].append(node)
                
                # Add to NetworkX graph
                self.nx_graph.add_node(
                    node['id'], 
                    title=node['title'],
                    level=node['level'],
                    tags=','.join(node['tags'])
                )
        
        # Create links
        self.create_links()
        
        print(f"📊 Scanned {len(self.graph_data['nodes'])} nodes")

    def create_links(self):
        """Create links based on parent-child relationships and content links."""
        print("🔗 Creating graph links...")
        
        # Create parent-child links
        for node in self.graph_data["nodes"]:
            node_id = node['id']
            
            # Parent link
            if node['parent']:
                link = {
                    "source": node['parent'],
                    "target": node_id,
                    "type": "parent-child",
                    "strength": 1.0
                }
                self.graph_data["links"].append(link)
                self.nx_graph.add_edge(node['parent'], node_id, type='parent-child')
            
            # Children links
            for child_id in node.get('children', []):
                link = {
                    "source": node_id,
                    "target": child_id,
                    "type": "parent-child",
                    "strength": 1.0
                }
                self.graph_data["links"].append(link)
                self.nx_graph.add_edge(node_id, child_id, type='parent-child')
            
            # Content links (sibling, cousin, transversal)
            for linked_id in node.get('content_links', []):
                if linked_id != node_id and any(n['id'] == linked_id for n in self.graph_data["nodes"]):
                    # Determine link type based on ID pattern
                    link_type = self.determine_link_type(node_id, linked_id)
                    
                    link = {
                        "source": node_id,
                        "target": linked_id,
                        "type": link_type,
                        "strength": 0.6
                    }
                    self.graph_data["links"].append(link)
                    self.nx_graph.add_edge(node_id, linked_id, type=link_type)
        
        # Update metadata
        self.graph_data["metadata"]["total_links"] = len(self.graph_data["links"])
        print(f"🔗 Created {len(self.graph_data['links'])} links")

    def determine_link_type(self, source_id, target_id):
        """Determine the type of link between two nodes."""
        source_parts = source_id.split('.')
        target_parts = target_id.split('.')
        
        if len(source_parts) == len(target_parts):
            if len(source_parts) == 1:
                return "main-transversal"
            elif source_parts[0] == target_parts[0]:
                if len(source_parts) == 2:
                    return "sub-sibling"
                else:
                    return "detail-cousin"
            else:
                return "transversal"
        else:
            return "cross-level"

    def generate_json_export(self):
        """Generate complete JSON export."""
        print("📄 Generating JSON export...")
        
        json_path = self.export_path / "graph_structure.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(self.graph_data, f, indent=2, ensure_ascii=False)
        
        print(f"✅ JSON export saved to {json_path}")

    def generate_graphml_export(self):
        """Generate GraphML export for Cytoscape/Gephi."""
        print("🌐 Generating GraphML export...")
        
        # Create GraphML XML structure
        graphml = Element('graphml')
        graphml.set('xmlns', 'http://graphml.graphdrawing.org/xmlns')
        graphml.set('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
        graphml.set('xsi:schemaLocation', 'http://graphml.graphdrawing.org/xmlns http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd')
        
        # Define node attributes
        node_keys = [
            ('d0', 'id', 'string'),
            ('d1', 'title', 'string'),
            ('d2', 'level', 'int'),
            ('d3', 'tags', 'string'),
            ('d4', 'parent', 'string')
        ]
        
        for key_id, attr_name, attr_type in node_keys:
            key_elem = SubElement(graphml, 'key')
            key_elem.set('id', key_id)
            key_elem.set('for', 'node')
            key_elem.set('attr.name', attr_name)
            key_elem.set('attr.type', attr_type)
        
        # Define edge attributes
        edge_key = SubElement(graphml, 'key')
        edge_key.set('id', 'd5')
        edge_key.set('for', 'edge')
        edge_key.set('attr.name', 'type')
        edge_key.set('attr.type', 'string')
        
        # Create graph element
        graph = SubElement(graphml, 'graph')
        graph.set('id', 'TransformerGraph')
        graph.set('edgedefault', 'directed')
        
        # Add nodes
        for node in self.graph_data["nodes"]:
            node_elem = SubElement(graph, 'node')
            node_elem.set('id', node['id'])
            
            # Add node data
            data_elements = [
                ('d0', node['id']),
                ('d1', node['title']),
                ('d2', str(node['level'])),
                ('d3', ','.join(node['tags'])),
                ('d4', node.get('parent', ''))
            ]
            
            for key_id, value in data_elements:
                if value:
                    data_elem = SubElement(node_elem, 'data')
                    data_elem.set('key', key_id)
                    data_elem.text = value
        
        # Add edges
        for i, link in enumerate(self.graph_data["links"]):
            edge_elem = SubElement(graph, 'edge')
            edge_elem.set('id', f'e{i}')
            edge_elem.set('source', link['source'])
            edge_elem.set('target', link['target'])
            
            data_elem = SubElement(edge_elem, 'data')
            data_elem.set('key', 'd5')
            data_elem.text = link['type']
        
        # Write to file
        graphml_path = self.export_path / "graph.graphml"
        rough_string = tostring(graphml, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ")
        
        with open(graphml_path, 'w', encoding='utf-8') as f:
            f.write(pretty_xml)
        
        print(f"✅ GraphML export saved to {graphml_path}")

    def generate_markmap_export(self):
        """Generate Markmap-compatible mind map."""
        print("🧠 Generating Markmap export...")
        
        markmap_content = """# Transformer Architecture Knowledge Graph

## 1. Foundations of Transformer Architecture
### 1.1. Core Concepts and Principles
- 1.1.1. Architecture Overview and Design Philosophy
- 1.1.2. Encoder-Decoder Structure Fundamentals
- 1.1.3. Sequence-to-Sequence Modeling Paradigm
- 1.1.4. Parallelization and Computational Efficiency
- 1.1.5. Mathematical Foundation and Linear Algebra

### 1.2. Self-Attention Fundamentals
- 1.2.1. Query-Key-Value Mechanism
- 1.2.2. Attention Score Calculation
- 1.2.3. Softmax Normalization Process
- 1.2.4. Weighted Value Aggregation
- 1.2.5. Self-Attention vs Cross-Attention

### 1.3. Positional Encoding Systems
- 1.3.1. Sinusoidal Position Encoding
- 1.3.2. Learned Positional Embeddings
- 1.3.3. Relative Position Representations
- 1.3.4. Rotary Position Embedding (RoPE)
- 1.3.5. Absolute vs Relative Positioning

### 1.4. Multi-Head Attention Design
- 1.4.1. Multiple Attention Head Architecture
- 1.4.2. Parallel Attention Computation
- 1.4.3. Head Concatenation and Projection
- 1.4.4. Attention Head Specialization
- 1.4.5. Head Pruning and Efficiency

### 1.5. Feed-Forward Networks
- 1.5.1. Position-wise Feed-Forward Layers
- 1.5.2. Activation Functions and Non-linearity
- 1.5.3. Layer Normalization Integration
- 1.5.4. Residual Connections and Skip Links
- 1.5.5. Dropout and Regularization

## 2. Attention Mechanisms and Variants
### 2.1. Scaled Dot-Product Attention
- 2.1.1. Dot-Product Similarity Computation
- 2.1.2. Scaling Factor and Dimension Normalization
- 2.1.3. Attention Matrix and Weights
- 2.1.4. Computational Complexity Analysis
- 2.1.5. Gradient Flow and Backpropagation

### 2.2. Multi-Head Attention Variants
- 2.2.1. Linear Attention Mechanisms
- 2.2.2. Sparse Attention Patterns
- 2.2.3. Local Attention Windows
- 2.2.4. Dilated Attention Strategies
- 2.2.5. Adaptive Attention Mechanisms

### 2.3. Cross-Attention and Encoder-Decoder
- 2.3.1. Encoder-Decoder Attention Flow
- 2.3.2. Cross-Modal Attention Mechanisms
- 2.3.3. Source-Target Sequence Alignment
- 2.3.4. Attention Visualization and Interpretation
- 2.3.5. Bidirectional vs Unidirectional Attention

### 2.4. Sparse Attention Patterns
- 2.4.1. Local Attention Windows
- 2.4.2. Strided Attention Patterns
- 2.4.3. Random Attention Sampling
- 2.4.4. Hierarchical Attention Structures
- 2.4.5. Memory-Efficient Attention

### 2.5. Relative and Absolute Positioning
- 2.5.1. Relative Position Encoding Methods
- 2.5.2. Absolute Position Integration
- 2.5.3. Distance-Based Attention Bias
- 2.5.4. Learnable Position Representations
- 2.5.5. Position Invariance Properties

## 3. Training and Optimization Strategies
### 3.1. Pre-training Methodologies
- 3.1.1. Masked Language Modeling (MLM)
- 3.1.2. Next Sentence Prediction (NSP)
- 3.1.3. Autoregressive Language Modeling
- 3.1.4. Permutation Language Modeling
- 3.1.5. Contrastive Pre-training Methods

### 3.2. Fine-tuning Strategies
- 3.2.1. Task-Specific Fine-tuning
- 3.2.2. Multi-Task Learning Approaches
- 3.2.3. Transfer Learning Techniques
- 3.2.4. Parameter-Efficient Fine-tuning
- 3.2.5. Adaptive Learning Rate Scheduling

### 3.3. Loss Functions and Objectives
- 3.3.1. Cross-Entropy Loss for Classification
- 3.3.2. Sequence-to-Sequence Loss Functions
- 3.3.3. Contrastive Learning Objectives
- 3.3.4. Auxiliary Loss Functions
- 3.3.5. Multi-Objective Optimization

### 3.4. Optimization Algorithms
- 3.4.1. Adam and AdamW Optimizers
- 3.4.2. Learning Rate Scheduling
- 3.4.3. Gradient Clipping Techniques
- 3.4.4. Warmup and Decay Strategies
- 3.4.5. Second-Order Optimization Methods

### 3.5. Regularization Techniques
- 3.5.1. Dropout and DropConnect
- 3.5.2. Layer Normalization Variants
- 3.5.3. Weight Decay and L2 Regularization
- 3.5.4. Early Stopping Criteria
- 3.5.5. Data Augmentation Strategies

## 4. Advanced Architectures and Extensions
### 4.1. BERT and Bidirectional Models
- 4.1.1. Bidirectional Encoder Architecture
- 4.1.2. Masked Token Prediction
- 4.1.3. Next Sentence Prediction Task
- 4.1.4. BERT Variants and Extensions
- 4.1.5. Fine-tuning for Downstream Tasks

### 4.2. GPT and Autoregressive Models
- 4.2.1. Autoregressive Language Modeling
- 4.2.2. Decoder-Only Architecture
- 4.2.3. Causal Attention Masking
- 4.2.4. GPT Scaling and Variants
- 4.2.5. In-Context Learning Capabilities

### 4.3. T5 and Text-to-Text Frameworks
- 4.3.1. Text-to-Text Transfer Transformer
- 4.3.2. Unified Input-Output Framework
- 4.3.3. Pre-training Task Design
- 4.3.4. Encoder-Decoder Architecture
- 4.3.5. Multi-Task Training Strategy

### 4.4. Vision Transformers (ViT)
- 4.4.1. Image Patch Tokenization
- 4.4.2. Vision Transformer Architecture
- 4.4.3. Position Embeddings for Images
- 4.4.4. Hybrid CNN-Transformer Models
- 4.4.5. Visual Attention Mechanisms

### 4.5. Hybrid and Efficient Architectures
- 4.5.1. Efficient Transformer Variants
- 4.5.2. Mobile and Lightweight Models
- 4.5.3. Knowledge Distillation Methods
- 4.5.4. Pruning and Quantization
- 4.5.5. Hardware-Optimized Designs

## 5. Applications and Real-World Implementations
### 5.1. Natural Language Processing
- 5.1.1. Text Classification and Sentiment Analysis
- 5.1.2. Named Entity Recognition (NER)
- 5.1.3. Question Answering Systems
- 5.1.4. Machine Translation
- 5.1.5. Text Summarization

### 5.2. Computer Vision Tasks
- 5.2.1. Image Classification with ViT
- 5.2.2. Object Detection and Segmentation
- 5.2.3. Image Generation and Synthesis
- 5.2.4. Video Understanding and Analysis
- 5.2.5. Medical Image Analysis

### 5.3. Multimodal Learning
- 5.3.1. Vision-Language Models
- 5.3.2. Image Captioning Systems
- 5.3.3. Visual Question Answering
- 5.3.4. Cross-Modal Retrieval
- 5.3.5. Audio-Visual Learning

### 5.4. Scientific and Research Applications
- 5.4.1. Protein Structure Prediction
- 5.4.2. Drug Discovery and Molecular Design
- 5.4.3. Scientific Literature Analysis
- 5.4.4. Code Generation and Programming
- 5.4.5. Mathematical Reasoning

### 5.5. Industry and Production Systems
- 5.5.1. Large Language Model Deployment
- 5.5.2. Real-time Inference Optimization
- 5.5.3. Recommendation Systems
- 5.5.4. Conversational AI and Chatbots
- 5.5.5. Content Generation and Creative AI
"""
        
        markmap_path = self.export_path / "mindmap.markmap.md"
        with open(markmap_path, 'w', encoding='utf-8') as f:
            f.write(markmap_content)
        
        print(f"✅ Markmap export saved to {markmap_path}")

    def generate_html_export(self):
        """Generate interactive HTML visualization with D3.js."""
        print("🌐 Generating HTML export...")
        
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transformer Architecture Knowledge Graph</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        body {{
            margin: 0;
            padding: 20px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }}
        
        h1 {{
            text-align: center;
            color: #333;
            margin-bottom: 10px;
            font-size: 2.5em;
        }}
        
        .subtitle {{
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 1.1em;
        }}
        
        .controls {{
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }}
        
        .control-group {{
            display: flex;
            align-items: center;
            gap: 5px;
        }}
        
        button, select {{
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            background: #4CAF50;
            color: white;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }}
        
        button:hover {{
            background: #45a049;
            transform: translateY(-2px);
        }}
        
        select {{
            background: #2196F3;
        }}
        
        select:hover {{
            background: #1976D2;
        }}
        
        #graph {{
            width: 100%;
            height: 600px;
            border: 2px solid #ddd;
            border-radius: 8px;
            background: #fafafa;
        }}
        
        .node {{
            cursor: pointer;
            transition: all 0.3s ease;
        }}
        
        .node:hover {{
            stroke-width: 3px;
        }}
        
        .link {{
            stroke: #999;
            stroke-opacity: 0.8;
            stroke-width: 2px;
            transition: all 0.3s ease;
        }}
        
        .link:hover {{
            stroke-opacity: 1;
            stroke-width: 4px;
        }}
        
        .tooltip {{
            position: absolute;
            padding: 10px;
            background: rgba(0, 0, 0, 0.9);
            color: white;
            border-radius: 6px;
            pointer-events: none;
            font-size: 12px;
            max-width: 300px;
            z-index: 1000;
        }}
        
        .legend {{
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }}
        
        .legend-item {{
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }}
        
        .legend-color {{
            width: 15px;
            height: 15px;
            margin-right: 8px;
            border-radius: 50%;
        }}
        
        .stats {{
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
            padding: 15px;
            background: #f5f5f5;
            border-radius: 8px;
        }}
        
        .stat-item {{
            text-align: center;
        }}
        
        .stat-number {{
            font-size: 2em;
            font-weight: bold;
            color: #2196F3;
        }}
        
        .stat-label {{
            color: #666;
            font-size: 0.9em;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🧠 Transformer Architecture Knowledge Graph</h1>
        <p class="subtitle">Interactive visualization of 125 interconnected concepts</p>
        
        <div class="controls">
            <div class="control-group">
                <label>Layout:</label>
                <select id="layoutSelect">
                    <option value="force">Force-Directed</option>
                    <option value="hierarchical">Hierarchical</option>
                    <option value="circular">Circular</option>
                </select>
            </div>
            <div class="control-group">
                <label>Filter by Level:</label>
                <select id="levelFilter">
                    <option value="all">All Levels</option>
                    <option value="1">Level 1 (Main Topics)</option>
                    <option value="2">Level 2 (Sub-Topics)</option>
                    <option value="3">Level 3 (Details)</option>
                </select>
            </div>
            <button onclick="resetZoom()">Reset Zoom</button>
            <button onclick="exportSVG()">Export SVG</button>
        </div>
        
        <div style="position: relative;">
            <svg id="graph"></svg>
            <div class="legend">
                <h4 style="margin-top: 0;">Node Types</h4>
                <div class="legend-item">
                    <div class="legend-color" style="background: #ff6b6b;"></div>
                    <span>Main Topics (Level 1)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #4ecdc4;"></div>
                    <span>Sub-Topics (Level 2)</span>
                </div>
                <div class="legend-item">
                    <div class="legend-color" style="background: #45b7d1;"></div>
                    <span>Detail Nodes (Level 3)</span>
                </div>
            </div>
        </div>
        
        <div class="stats">
            <div class="stat-item">
                <div class="stat-number">125</div>
                <div class="stat-label">Total Nodes</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">{len(self.graph_data['links'])}</div>
                <div class="stat-label">Total Links</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">5</div>
                <div class="stat-label">Main Topics</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">25</div>
                <div class="stat-label">Sub-Topics</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">95</div>
                <div class="stat-label">Detail Nodes</div>
            </div>
        </div>
    </div>

    <div class="tooltip" id="tooltip"></div>

    <script>
        // Graph data will be populated when generated
        const graphData = {{"nodes": [], "links": []}};
        
        // D3.js visualization setup
        const width = 1200;
        const height = 600;
        
        const svg = d3.select("#graph")
            .attr("width", width)
            .attr("height", height);
        
        const g = svg.append("g");
        
        // Zoom behavior
        const zoom = d3.zoom()
            .scaleExtent([0.1, 10])
            .on("zoom", (event) => {{
                g.attr("transform", event.transform);
            }});
        
        svg.call(zoom);
        
        // Color scale for node levels
        const colorScale = d3.scaleOrdinal()
            .domain([1, 2, 3])
            .range(["#ff6b6b", "#4ecdc4", "#45b7d1"]);
        
        // Tooltip
        const tooltip = d3.select("#tooltip");
        
        function resetZoom() {{
            svg.transition().duration(750).call(
                zoom.transform,
                d3.zoomIdentity
            );
        }}
        
        function exportSVG() {{
            const svgElement = document.getElementById("graph");
            const serializer = new XMLSerializer();
            const svgString = serializer.serializeToString(svgElement);
            const blob = new Blob([svgString], {{type: "image/svg+xml"}});
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = "transformer_graph.svg";
            a.click();
        }}
    </script>
</body>
</html>"""
        
        html_path = self.export_path / "index.html"
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"✅ HTML export saved to {html_path}")

    def generate_jupyter_export(self):
        """Generate Jupyter notebook with NetworkX analysis."""
        print("📓 Generating Jupyter notebook export...")
        
        notebook_content = {
            "cells": [
                {
                    "cell_type": "markdown",
                    "metadata": {},
                    "source": [
                        "# Transformer Architecture Knowledge Graph Analysis\n",
                        "\n",
                        "This notebook provides comprehensive analysis of the Transformer Architecture knowledge graph using NetworkX.\n",
                        "\n",
                        "## Overview\n",
                        "- **Total Nodes**: 125\n",
                        "- **Total Links**: " + str(len(self.graph_data['links'])) + "\n",
                        "- **Levels**: 3 (Main Topics → Sub-Topics → Detail Nodes)\n",
                        "- **Branching Factor**: 5 consistent across all levels"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "source": [
                        "# Import required libraries\n",
                        "import json\n",
                        "import networkx as nx\n",
                        "import matplotlib.pyplot as plt\n",
                        "import numpy as np\n",
                        "import pandas as pd\n",
                        "from collections import Counter\n",
                        "import seaborn as sns\n",
                        "\n",
                        "# Set style for better visualizations\n",
                        "plt.style.use('seaborn-v0_8')\n",
                        "sns.set_palette('husl')\n",
                        "plt.rcParams['figure.figsize'] = (12, 8)"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "source": [
                        "# Load graph data\n",
                        "with open('graph_structure.json', 'r', encoding='utf-8') as f:\n",
                        "    graph_data = json.load(f)\n",
                        "\n",
                        "print(f\"Loaded {len(graph_data['nodes'])} nodes and {len(graph_data['links'])} links\")"
                    ]
                }
            ],
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3"
                }
            },
            "nbformat": 4,
            "nbformat_minor": 4
        }
        
        notebook_path = self.export_path / "vault_structure.ipynb"
        with open(notebook_path, 'w', encoding='utf-8') as f:
            json.dump(notebook_content, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Jupyter notebook saved to {notebook_path}")

    def generate_export_readme(self):
        """Generate deployment README for exports."""
        print("📖 Generating export README...")
        
        readme_content = """# Transformer Knowledge Graph - Export Formats

This directory contains multiple export formats of the Transformer Architecture Knowledge Graph for maximum portability and interoperability.

## Available Formats

### 1. JSON Export (`graph_structure.json`)
Complete graph structure with all nodes, links, and metadata in JSON format.

### 2. GraphML Export (`graph.graphml`)
Standard GraphML format compatible with Cytoscape, Gephi, and other graph analysis tools.

### 3. Markmap Export (`mindmap.markmap.md`)
Interactive mind mapping format compatible with Markmap and similar tools.

### 4. HTML Visualization (`index.html`)
Complete interactive web visualization with D3.js.

### 5. Jupyter Notebook (`vault_structure.ipynb`)
Comprehensive NetworkX-based analysis and visualization.

### 6. README (`README.md`)
This file with deployment instructions and format descriptions.

## Graph Statistics
- **Total Nodes**: 125
- **Total Links**: """ + str(len(self.graph_data['links'])) + """
- **Main Topics**: 5
- **Sub-Topics**: 25  
- **Detail Nodes**: 95

Created: 2025-06-09
Version: 1.0.0
Author: Research Agent
"""
        
        readme_path = self.export_path / "README.md"
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        print(f"✅ Export README saved to {readme_path}")

    def generate_all_exports(self):
        """Generate all export formats."""
        print("🚀 Generating all export formats...")
        
        # Scan vault files to build graph data
        self.scan_vault_files()
        
        # Generate all export formats
        self.generate_json_export()
        self.generate_graphml_export()
        self.generate_markmap_export()
        self.generate_html_export()
        self.generate_jupyter_export()
        self.generate_export_readme()
        
        print("✅ All export formats generated successfully!")
        print(f"📊 Export summary:")
        print(f"   - JSON: Complete graph structure")
        print(f"   - GraphML: Cytoscape/Gephi compatible")
        print(f"   - Markmap: Interactive mind mapping")
        print(f"   - HTML: D3.js web visualization")
        print(f"   - Jupyter: NetworkX analysis notebook")
        print(f"   - README: Deployment instructions")

if __name__ == "__main__":
    generator = TransformerExportGenerator()
    generator.generate_all_exports()
