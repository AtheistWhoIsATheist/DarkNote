"""
GCN Knowledge Graph Vault Generator
Creates complete 125-node knowledge graph with proper linking structure
"""

import os
import json
from typing import Dict, List, Tuple
from pathlib import Path
import yaml

class GCNVaultGenerator:
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.nodes = {}
        self.links = []
        
        # Define the complete hierarchical structure
        self.main_topics = {
            "1": "Foundations of Graph Convolutional Networks",
            "2": "GCN Architectures and Variants", 
            "3": "Learning and Optimization",
            "4": "Challenges and Limitations",
            "5": "Applications and Use Cases"
        }
        
        self.sub_topics = {
            # Foundations
            "1.1": "Introduction to Graph Structures",
            "1.2": "Basics of GCNs", 
            "1.3": "Historical Evolution",
            "1.4": "Core Terminology",
            "1.5": "GCN vs Traditional CNN",
            
            # Architectures
            "2.1": "Basic GCN Layer",
            "2.2": "GraphSAGE",
            "2.3": "Graph Attention Networks (GATs)",
            "2.4": "Spectral GCNs", 
            "2.5": "Advanced Architectures",
            
            # Optimization
            "3.1": "Training Strategies",
            "3.2": "Loss Functions",
            "3.3": "Optimization Methods",
            "3.4": "Model Tuning",
            "3.5": "Evaluation Metrics",
            
            # Challenges
            "4.1": "Over-Smoothing",
            "4.2": "Scalability Issues", 
            "4.3": "Interpretability",
            "4.4": "Heterophily",
            "4.5": "Generalization Limits",
            
            # Applications
            "5.1": "Node Classification",
            "5.2": "Link Prediction",
            "5.3": "Graph Classification", 
            "5.4": "Recommendation Systems",
            "5.5": "Scientific and Industrial Use"
        }
        
        self.detail_nodes = self._generate_detail_nodes()
        
    def _generate_detail_nodes(self) -> Dict[str, str]:
        """Generate all 95 detail nodes (5 per sub-topic)"""
        detail_mapping = {
            # 1.1 Introduction to Graph Structures
            "1.1.1": "Graph Composition",
            "1.1.2": "Pairwise Relations", 
            "1.1.3": "Graph Types",
            "1.1.4": "Common Examples",
            "1.1.5": "Relational Modeling",
            
            # 1.2 Basics of GCNs
            "1.2.1": "Message Passing Framework",
            "1.2.2": "Aggregation Functions",
            "1.2.3": "Node Feature Updates",
            "1.2.4": "Graph Convolution Definition",
            "1.2.5": "Neighborhood Sampling",
            
            # 1.3 Historical Evolution
            "1.3.1": "Early Graph Methods",
            "1.3.2": "Spectral Graph Theory",
            "1.3.3": "Deep Learning Integration",
            "1.3.4": "Modern GCN Development",
            "1.3.5": "Timeline of Innovations",
            
            # 1.4 Core Terminology
            "1.4.1": "Graph Terminology",
            "1.4.2": "Neural Network Terms",
            "1.4.3": "Convolution Concepts",
            "1.4.4": "Learning Paradigms",
            "1.4.5": "Evaluation Vocabulary",
            
            # 1.5 GCN vs Traditional CNN
            "1.5.1": "Structural Differences",
            "1.5.2": "Data Representation",
            "1.5.3": "Convolution Operations",
            "1.5.4": "Application Domains",
            "1.5.5": "Performance Characteristics",
            
            # 2.1 Basic GCN Layer
            "2.1.1": "Layer Architecture",
            "2.1.2": "Weight Matrices",
            "2.1.3": "Activation Functions",
            "2.1.4": "Normalization Techniques",
            "2.1.5": "Implementation Details",
            
            # 2.2 GraphSAGE
            "2.2.1": "Sampling Strategy",
            "2.2.2": "Aggregator Functions",
            "2.2.3": "Inductive Learning",
            "2.2.4": "Scalability Features",
            "2.2.5": "Algorithm Variants",
            
            # 2.3 Graph Attention Networks (GATs)
            "2.3.1": "Attention Mechanism",
            "2.3.2": "Multi-Head Attention",
            "2.3.3": "Attention Weights",
            "2.3.4": "Node Importance",
            "2.3.5": "Performance Benefits",
            
            # 2.4 Spectral GCNs
            "2.4.1": "Fourier Transform on Graphs",
            "2.4.2": "Spectral Filters",
            "2.4.3": "Chebyshev Polynomials",
            "2.4.4": "Eigenvalue Analysis",
            "2.4.5": "Computational Complexity",
            
            # 2.5 Advanced Architectures
            "2.5.1": "Graph Transformer",
            "2.5.2": "Graph Isomorphism Networks",
            "2.5.3": "Graph Residual Networks",
            "2.5.4": "Hierarchical GCNs", 
            "2.5.5": "Hybrid Architectures",
            
            # 3.1 Training Strategies
            "3.1.1": "Mini-Batch Training",
            "3.1.2": "Full-Batch Training",
            "3.1.3": "Sampling Techniques",
            "3.1.4": "Curriculum Learning",
            "3.1.5": "Transfer Learning",
            
            # 3.2 Loss Functions
            "3.2.1": "Classification Loss",
            "3.2.2": "Regression Loss",
            "3.2.3": "Contrastive Loss",
            "3.2.4": "Graph-Level Loss",
            "3.2.5": "Regularization Terms",
            
            # 3.3 Optimization Methods
            "3.3.1": "Gradient Descent Variants",
            "3.3.2": "Adaptive Learning Rates",
            "3.3.3": "Momentum Techniques",
            "3.3.4": "Second-Order Methods",
            "3.3.5": "Graph-Specific Optimizers",
            
            # 3.4 Model Tuning
            "3.4.1": "Hyperparameter Selection",
            "3.4.2": "Architecture Search",
            "3.4.3": "Cross-Validation",
            "3.4.4": "Grid Search",
            "3.4.5": "Bayesian Optimization",
            
            # 3.5 Evaluation Metrics
            "3.5.1": "Node-Level Metrics",
            "3.5.2": "Graph-Level Metrics",
            "3.5.3": "Link Prediction Metrics",
            "3.5.4": "Clustering Metrics",
            "3.5.5": "Robustness Measures",
            
            # 4.1 Over-Smoothing
            "4.1.1": "Feature Homogenization",
            "4.1.2": "Deep Layer Problems",
            "4.1.3": "Information Loss",
            "4.1.4": "Mitigation Strategies",
            "4.1.5": "Theoretical Analysis",
            
            # 4.2 Scalability Issues
            "4.2.1": "Memory Complexity",
            "4.2.2": "Computational Bottlenecks",
            "4.2.3": "Large Graph Challenges",
            "4.2.4": "Distributed Computing",
            "4.2.5": "Approximation Methods",
            
            # 4.3 Interpretability
            "4.3.1": "Feature Attribution",
            "4.3.2": "Attention Visualization",
            "4.3.3": "Graph Explanation",
            "4.3.4": "Model Transparency",
            "4.3.5": "Causal Analysis",
            
            # 4.4 Heterophily
            "4.4.1": "Heterophilic Graphs",
            "4.4.2": "Neighborhood Diversity", 
            "4.4.3": "Adaptive Aggregation",
            "4.4.4": "Performance Degradation",
            "4.4.5": "Specialized Architectures",
            
            # 4.5 Generalization Limits
            "4.5.1": "Domain Adaptation",
            "4.5.2": "Graph Distribution Shift",
            "4.5.3": "Size Generalization",
            "4.5.4": "Structure Invariance",
            "4.5.5": "Robustness Testing",
            
            # 5.1 Node Classification
            "5.1.1": "Semi-Supervised Learning",
            "5.1.2": "Social Network Analysis",
            "5.1.3": "Citation Networks",
            "5.1.4": "Biological Networks",
            "5.1.5": "Knowledge Graphs",
            
            # 5.2 Link Prediction
            "5.2.1": "Graph Completion",
            "5.2.2": "Recommendation Engines",
            "5.2.3": "Drug Discovery",
            "5.2.4": "Social Link Prediction",
            "5.2.5": "Knowledge Base Completion",
            
            # 5.3 Graph Classification
            "5.3.1": "Molecular Property Prediction",
            "5.3.2": "Chemical Compound Analysis",
            "5.3.3": "Social Network Classification",
            "5.3.4": "Program Analysis",
            "5.3.5": "Image Scene Understanding",
            
            # 5.4 Recommendation Systems
            "5.4.1": "Collaborative Filtering",
            "5.4.2": "Content-Based Filtering",
            "5.4.3": "Hybrid Approaches",
            "5.4.4": "Session-Based Recommendations",
            "5.4.5": "Multi-Stakeholder Systems",
            
            # 5.5 Scientific and Industrial Use
            "5.5.1": "Materials Science",
            "5.5.2": "Transportation Networks",
            "5.5.3": "Financial Networks",
            "5.5.4": "Computer Vision",
            "5.5.5": "Natural Language Processing"
        }
        
        return detail_mapping
    
    def _get_node_info(self, node_id: str) -> Tuple[str, int, str, List[str]]:
        """Get node title, level, parent, and children for a given ID"""
        if "." not in node_id:
            # Main topic
            title = self.main_topics[node_id]
            level = 1
            parent = ""
            children = [f"{node_id}.{i}" for i in range(1, 6)]
        elif node_id.count(".") == 1:
            # Sub-topic
            title = self.sub_topics[node_id]
            level = 2
            parent = node_id.split(".")[0]
            children = [f"{node_id}.{i}" for i in range(1, 6)]
        else:
            # Detail node
            title = self.detail_nodes[node_id]
            level = 3
            parent = ".".join(node_id.split(".")[:-1])
            children = []
            
        return title, level, parent, children
    
    def _get_siblings(self, node_id: str) -> List[str]:
        """Get sibling nodes (same parent, same level)"""
        if "." not in node_id:
            # Main topics are siblings
            return [id for id in self.main_topics.keys() if id != node_id]
        elif node_id.count(".") == 1:
            # Sub-topics with same main topic
            main = node_id.split(".")[0]
            return [id for id in self.sub_topics.keys() if id.startswith(main + ".") and id != node_id]
        else:
            # Detail nodes with same sub-topic
            sub = ".".join(node_id.split(".")[:-1])
            return [id for id in self.detail_nodes.keys() if id.startswith(sub + ".") and id != node_id]
    
    def _get_cousins(self, node_id: str) -> List[str]:
        """Get cousin nodes (same main topic but different sub-topic)"""
        if "." not in node_id or node_id.count(".") == 1:
            return []  # No cousins for main or sub topics
        
        main = node_id.split(".")[0]
        sub = ".".join(node_id.split(".")[:-1])
        
        cousins = []
        for id in self.detail_nodes.keys():
            if id.startswith(main + ".") and not id.startswith(sub + "."):
                cousins.append(id)
        return cousins[:3]  # Limit to 3 cousins
    
    def _get_transversals(self, node_id: str) -> List[str]:
        """Get transversal nodes (different main topic)"""
        if "." not in node_id:
            main = node_id
        else:
            main = node_id.split(".")[0]
        
        # Find nodes in different main topics
        transversals = []
        for other_main in self.main_topics.keys():
            if other_main != main:
                # Add one from each other main topic
                if node_id.count(".") == 0:
                    transversals.append(other_main)
                elif node_id.count(".") == 1:
                    transversals.append(f"{other_main}.1")
                else:
                    transversals.append(f"{other_main}.1.1")
                    
        return transversals[:2]  # Limit to 2 transversals
    
    def _create_yaml_frontmatter(self, node_id: str) -> str:
        """Create YAML frontmatter for a node"""
        title, level, parent, children = self._get_node_info(node_id)
        
        # Generate tags
        tags = ["GCN", f"Level{level}"]
        main_topic = node_id.split(".")[0]
        topic_tags = {
            "1": "foundations",
            "2": "architectures", 
            "3": "optimization",
            "4": "challenges",
            "5": "applications"
        }
        tags.append(topic_tags[main_topic])
        
        frontmatter = f"""---
id: "{node_id}"
title: "{title}"
level: {level}
parent: "{parent}"
children: {json.dumps(children)}
tags: {json.dumps(tags)}
alias: ["{title}"]
created: "2025-06-09"
updated: "2025-06-09"
---"""
        return frontmatter
    
    def _create_content_sections(self, node_id: str) -> str:
        """Create the main content sections for a node"""
        title, level, parent, children = self._get_node_info(node_id)
        siblings = self._get_siblings(node_id)
        cousins = self._get_cousins(node_id)
        transversals = self._get_transversals(node_id)
        
        # Generate semantic content based on the node
        definition = self._get_definition(node_id, title)
        semantic_core = self._get_semantic_core(node_id, title)
        
        content = f"""
# {title}

## ❶ Definition
{definition}

## ❷ Semantic Core
{semantic_core}

## ❸ Parent Reference
{f"- [[{parent}]]" if parent else "- Root level node"}

## ❹ Sibling Links
{chr(10).join([f"- [[{sib}]]" for sib in siblings[:3]])}

## ❺ Cousin Reference
{chr(10).join([f"- [[{cousin}]]" for cousin in cousins]) if cousins else "- No cousins at this level"}

## ❻ Transversal Insight
{chr(10).join([f"- [[{trans}]]" for trans in transversals])}

## ❼ Vault Traceback
```dataview
TABLE id, file.name
WHERE contains(tags, "GCN") AND id = "{node_id}"
```
"""
        return content
    
    def _get_definition(self, node_id: str, title: str) -> str:
        """Generate appropriate definition for the node"""
        definitions = {
            # Main topics
            "1": "Graph Convolutional Networks (GCNs) represent a fundamental paradigm in deep learning that extends convolutional neural networks to non-Euclidean graph-structured data, enabling the processing of relationships and dependencies in complex networked systems.",
            "2": "GCN architectures encompass various neural network designs that implement graph convolution operations through different mathematical formulations, aggregation strategies, and attention mechanisms to learn effective node and graph representations.",
            "3": "Learning and optimization in GCNs involves specialized training procedures, loss functions, and optimization techniques adapted for graph-structured data, addressing unique challenges in gradient propagation and parameter updates across irregular graph topologies.",
            "4": "Challenges and limitations of GCNs include fundamental issues such as over-smoothing, scalability constraints, interpretability concerns, and performance degradation on heterophilic graphs that limit their effectiveness in certain domains.",
            "5": "Applications and use cases of GCNs span diverse domains including node classification, link prediction, graph classification, and recommendation systems, demonstrating their versatility in solving real-world problems involving relational data.",
            
            # Sample definitions for other levels - the actual implementation would have all 125
            "1.1": "Graph structures are mathematical representations of relational data consisting of nodes (vertices) and edges that capture pairwise relationships between entities, forming the foundational data representation for graph neural networks.",
            "1.2": "The basics of GCNs encompass the fundamental concepts of message passing, neighborhood aggregation, and feature transformation that enable neural networks to process and learn from graph-structured data effectively.",
        }
        
        # Return specific definition if available, otherwise generate generic one
        if node_id in definitions:
            return definitions[node_id]
        else:
            return f"{title} represents a key concept in Graph Convolutional Networks, contributing to the understanding and implementation of deep learning methods for graph-structured data."
    
    def _get_semantic_core(self, node_id: str, title: str) -> str:
        """Generate semantic core points for the node"""
        # This would be expanded to include specific semantic core for each node
        level = len(node_id.split("."))
        if level == 1:
            return "- Fundamental paradigm for graph-based deep learning\n- Extends CNN principles to irregular graph structures\n- Enables learning from relational and networked data\n- Foundation for numerous specialized architectures"
        elif level == 2:
            return f"- Key component of {title.lower()}\n- Essential for understanding GCN fundamentals\n- Practical applications in real-world scenarios\n- Technical foundation for advanced concepts"
        else:
            return f"- Specific aspect of {title.lower()}\n- Detailed implementation considerations\n- Technical nuances and best practices\n- Connection to broader GCN principles"
    
    def generate_all_files(self):
        """Generate all 125 markdown files with proper structure"""
        print("Generating GCN Knowledge Graph files...")
        
        # Create all node files
        all_nodes = {}
        all_nodes.update(self.main_topics)
        all_nodes.update(self.sub_topics) 
        all_nodes.update(self.detail_nodes)
        
        for node_id, title in all_nodes.items():
            # Determine file path
            level = len(node_id.split("."))
            if level == 1:
                file_path = self.base_path / "01_Main" / f"{node_id}_{title.replace(' ', '_').replace('(', '').replace(')', '')}.md"
            elif level == 2:
                main_id = node_id.split(".")[0]
                file_path = self.base_path / "01_Main" / f"{main_id}_Sub" / f"{node_id}_{title.replace(' ', '_').replace('(', '').replace(')', '')}.md"
            else:
                main_id = node_id.split(".")[0]
                file_path = self.base_path / "01_Main" / f"{main_id}_Detail" / f"{node_id}_{title.replace(' ', '_').replace('(', '').replace(')', '')}.md"
            
            # Create directory if it doesn't exist
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Generate file content
            frontmatter = self._create_yaml_frontmatter(node_id)
            content = self._create_content_sections(node_id)
            
            full_content = frontmatter + content
            
            # Write file
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(full_content)
            
            print(f"Created: {file_path}")
        
        print(f"Successfully generated {len(all_nodes)} node files!")

if __name__ == "__main__":
    generator = GCNVaultGenerator("/workspace/GCN_Knowledge_Graph")
    generator.generate_all_files()
