#!/usr/bin/env python3
"""
Orphan Node Elimination System
Ensure every node has incoming links to achieve ZERO orphan nodes.
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple

class OrphanNodeEliminator:
    def __init__(self, vault_path: str):
        self.vault_path = Path(vault_path)
        self.main_path = self.vault_path / "01_Main"
        
        self.all_nodes = {}  # id -> file_path
        self.node_metadata = {}  # id -> metadata
        self.incoming_links = {}  # node_id -> set of nodes linking to it
        self.outgoing_links = {}  # node_id -> set of nodes it links to
        
    def scan_current_links(self):
        """Scan all files to build current link map."""
        print("🔍 Scanning current link structure...")
        
        # Initialize link tracking
        for node_id in self.all_nodes:
            self.incoming_links[node_id] = set()
            self.outgoing_links[node_id] = set()
        
        # Scan all files for links
        for node_id, file_path in self.all_nodes.items():
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Find all outgoing links from this node
            links = re.findall(r'\[\[([^\]]+)\]\]', content)
            for link in links:
                clean_link = link.strip('\'"')
                if clean_link in self.all_nodes:
                    self.outgoing_links[node_id].add(clean_link)
                    self.incoming_links[clean_link].add(node_id)
                    
        print(f"✅ Scanned links for {len(self.all_nodes)} nodes")
        
    def find_orphan_nodes(self) -> Set[str]:
        """Find all nodes with no incoming links."""
        orphans = set()
        for node_id in self.all_nodes:
            if len(self.incoming_links[node_id]) == 0:
                orphans.add(node_id)
        return orphans
        
    def create_incoming_links_for_orphans(self, orphans: Set[str]):
        """Create strategic incoming links for orphan nodes."""
        print(f"🔗 Creating incoming links for {len(orphans)} orphan nodes...")
        
        for orphan_id in orphans:
            self._create_incoming_links_for_node(orphan_id)
            
    def _create_incoming_links_for_node(self, orphan_id: str):
        """Create incoming links for a specific orphan node."""
        orphan_metadata = self.node_metadata.get(orphan_id, {})
        orphan_level = orphan_metadata.get('level', 0)
        
        # Strategy 1: Add to parent's content if it's a child node
        parent_id = orphan_metadata.get('parent')
        if parent_id and parent_id in self.all_nodes:
            self._add_link_to_node(parent_id, orphan_id, "child_reference")
            
        # Strategy 2: Add to sibling nodes
        if parent_id and parent_id in self.all_nodes:
            parent_metadata = self.node_metadata.get(parent_id, {})
            siblings = parent_metadata.get('children', [])
            for sibling_id in siblings[:2]:  # Add to first 2 siblings
                if sibling_id != orphan_id and sibling_id in self.all_nodes:
                    self._add_link_to_node(sibling_id, orphan_id, "sibling_reference")
                    
        # Strategy 3: Add to related nodes in same main topic
        main_topic = orphan_id.split('.')[0]
        related_nodes = [node_id for node_id in self.all_nodes 
                        if node_id.startswith(main_topic) and node_id != orphan_id]
        
        # Add to 2 related nodes at most
        for related_id in related_nodes[:2]:
            if len(self.incoming_links[orphan_id]) < 3:  # Don't over-link
                self._add_link_to_node(related_id, orphan_id, "related_reference")
                
        # Strategy 4: Cross-topic transversal links
        if len(self.incoming_links[orphan_id]) == 0:
            # Find nodes from other topics with same level
            for other_node_id in self.all_nodes:
                other_main = other_node_id.split('.')[0]
                other_level = self.node_metadata.get(other_node_id, {}).get('level', 0)
                
                if (other_main != main_topic and 
                    other_level == orphan_level and
                    len(self.incoming_links[orphan_id]) < 2):
                    self._add_link_to_node(other_node_id, orphan_id, "transversal_reference")
                    
        print(f"✅ Created links for orphan: {orphan_id}")
        
    def _add_link_to_node(self, source_node_id: str, target_node_id: str, link_type: str):
        """Add a link from source to target node in the appropriate section."""
        source_file = self.all_nodes[source_node_id]
        
        with open(source_file, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Determine where to add the link based on type
        if link_type == "child_reference":
            # Add to semantic core or a new subsection
            if "## ❷ Semantic Core" in content:
                pattern = r'(## ❷ Semantic Core\n(?:- .*\n)*)'
                replacement = rf'\1- Related concept: [[{target_node_id}]]\n'
                content = re.sub(pattern, replacement, content)
        
        elif link_type == "sibling_reference":
            # Add to sibling links section
            if "## ❹ Sibling Links" in content:
                pattern = r'(## ❹ Sibling Links\n(?:- .*\n)*)'
                replacement = rf'\1- [[{target_node_id}]]\n'
                content = re.sub(pattern, replacement, content)
                
        elif link_type == "related_reference":
            # Add to cousin reference section
            if "## ❺ Cousin Reference" in content:
                pattern = r'(## ❺ Cousin Reference\n(?:- .*\n)*)'
                replacement = rf'\1- [[{target_node_id}]]\n'
                content = re.sub(pattern, replacement, content)
                
        elif link_type == "transversal_reference":
            # Add to transversal insight section
            if "## ❻ Transversal Insight" in content:
                pattern = r'(## ❻ Transversal Insight\n(?:- .*\n)*)'
                replacement = rf'\1- [[{target_node_id}]]\n'
                content = re.sub(pattern, replacement, content)
                
        # Write updated content
        with open(source_file, 'w', encoding='utf-8') as f:
            f.write(content)
            
        # Update tracking
        self.outgoing_links[source_node_id].add(target_node_id)
        self.incoming_links[target_node_id].add(source_node_id)
        
    def scan_all_nodes(self):
        """Scan all nodes and build metadata database."""
        print("🔍 Scanning all nodes...")
        
        # Collect all markdown files
        all_file_paths = []
        all_file_paths.extend(self.main_path.glob("*.md"))
        for sub_dir in self.main_path.glob("*_Sub"):
            all_file_paths.extend(sub_dir.glob("*.md"))
        for detail_dir in self.main_path.glob("*_Detail"):
            all_file_paths.extend(detail_dir.glob("*.md"))
            
        # Extract metadata from each file
        for file_path in all_file_paths:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Extract YAML frontmatter
            yaml_match = re.match(r'^---\n(.*?)\n---\n', content, re.DOTALL)
            if not yaml_match:
                continue
                
            yaml_content = yaml_match.group(1)
            
            # Parse YAML fields
            node_id = self._extract_yaml_field(yaml_content, 'id')
            title = self._extract_yaml_field(yaml_content, 'title')
            level = self._extract_yaml_field(yaml_content, 'level')
            parent = self._extract_yaml_field(yaml_content, 'parent')
            children = self._extract_yaml_list(yaml_content, 'children')
            
            if node_id:
                self.all_nodes[node_id] = file_path
                self.node_metadata[node_id] = {
                    'title': title,
                    'level': int(level) if level else 0,
                    'parent': parent,
                    'children': children,
                    'file_path': file_path
                }
                
        print(f"✅ Found {len(self.all_nodes)} nodes")
        
    def _extract_yaml_field(self, yaml_content: str, field: str) -> str:
        """Extract a single field from YAML content."""
        pattern = rf'{field}:\s*[\'"]?([^\s\'"]+)'
        match = re.search(pattern, yaml_content)
        return match.group(1) if match else ""
        
    def _extract_yaml_list(self, yaml_content: str, field: str) -> List[str]:
        """Extract a list field from YAML content."""
        pattern = rf'{field}:\s*\[(.*?)\]'
        match = re.search(pattern, yaml_content, re.DOTALL)
        if match:
            list_content = match.group(1)
            items = re.findall(r'[\'"]?([^\s\'"]+)', list_content)
            return [item.strip('\'"') for item in items if item]
        return []
        
    def eliminate_all_orphans(self):
        """Complete orphan elimination process."""
        print("🎯 Starting orphan elimination process...")
        
        # Scan nodes and current links
        self.scan_all_nodes()
        self.scan_current_links()
        
        # Find orphans
        orphans = self.find_orphan_nodes()
        print(f"📊 Found {len(orphans)} orphan nodes")
        
        if orphans:
            # Create incoming links
            self.create_incoming_links_for_orphans(orphans)
            
            # Re-scan to verify
            self.incoming_links = {node_id: set() for node_id in self.all_nodes}
            self.outgoing_links = {node_id: set() for node_id in self.all_nodes}
            self.scan_current_links()
            
            remaining_orphans = self.find_orphan_nodes()
            print(f"📊 Remaining orphans after first pass: {len(remaining_orphans)}")
            
            # Second pass for stubborn orphans
            if remaining_orphans:
                print("🔄 Running second elimination pass...")
                self._aggressive_orphan_elimination(remaining_orphans)
                
                # Final verification
                self.incoming_links = {node_id: set() for node_id in self.all_nodes}
                self.outgoing_links = {node_id: set() for node_id in self.all_nodes}
                self.scan_current_links()
                final_orphans = self.find_orphan_nodes()
                
                print(f"📊 Final orphan count: {len(final_orphans)}")
                
                if len(final_orphans) == 0:
                    print("🎉 SUCCESS: All orphan nodes eliminated!")
                else:
                    print(f"⚠️  {len(final_orphans)} orphans remaining")
                    
        else:
            print("🎉 No orphans found - system already optimal!")
            
    def _aggressive_orphan_elimination(self, stubborn_orphans: Set[str]):
        """Aggressive second-pass orphan elimination."""
        print(f"🔥 Aggressive elimination for {len(stubborn_orphans)} stubborn orphans...")
        
        # Find the most connected nodes to use as link sources
        most_connected = sorted(self.all_nodes.keys(), 
                              key=lambda x: len(self.outgoing_links[x]), 
                              reverse=True)
        
        for orphan_id in stubborn_orphans:
            # Add orphan to top 3 most connected nodes
            for source_id in most_connected[:3]:
                if source_id != orphan_id:
                    self._add_link_to_node(source_id, orphan_id, "emergency_reference")
                    if len(self.incoming_links[orphan_id]) >= 2:
                        break  # Enough incoming links
                        
        print("✅ Aggressive elimination complete")

def main():
    vault_path = "/workspace/Transformer_Knowledge_Graph"
    eliminator = OrphanNodeEliminator(vault_path)
    eliminator.eliminate_all_orphans()

if __name__ == "__main__":
    main()
