"""
GCN Knowledge Graph Export Generator
Creates all 5 required export formats for the knowledge graph
"""

import json
import xml.etree.ElementTree as ET
from pathlib import Path
import networkx as nx
from typing import Dict, List
import re

class ExportGenerator:
    def __init__(self, vault_path: str):
        self.vault_path = Path(vault_path)
        self.nodes = {}
        self.links = []
        self._load_graph_data()
    
    def _load_graph_data(self):
        """Load all node data from the vault files"""
        # Define the structure
        main_topics = {
            "1": "Foundations of Graph Convolutional Networks",
            "2": "GCN Architectures and Variants", 
            "3": "Learning and Optimization",
            "4": "Challenges and Limitations",
            "5": "Applications and Use Cases"
        }
        
        sub_topics = {
            "1.1": "Introduction to Graph Structures", "1.2": "Basics of GCNs", 
            "1.3": "Historical Evolution", "1.4": "Core Terminology", "1.5": "GCN vs Traditional CNN",
            "2.1": "Basic GCN Layer", "2.2": "GraphSAGE", "2.3": "Graph Attention Networks (GATs)",
            "2.4": "Spectral GCNs", "2.5": "Advanced Architectures",
            "3.1": "Training Strategies", "3.2": "Loss Functions", "3.3": "Optimization Methods",
            "3.4": "Model Tuning", "3.5": "Evaluation Metrics",
            "4.1": "Over-Smoothing", "4.2": "Scalability Issues", "4.3": "Interpretability",
            "4.4": "Heterophily", "4.5": "Generalization Limits",
            "5.1": "Node Classification", "5.2": "Link Prediction", "5.3": "Graph Classification", 
            "5.4": "Recommendation Systems", "5.5": "Scientific and Industrial Use"
        }
        
        # Generate all detail nodes
        detail_nodes = {}
        detail_topics = [
            # 1.1.x
            ["Graph Composition", "Pairwise Relations", "Graph Types", "Common Examples", "Relational Modeling"],
            # 1.2.x  
            ["Message Passing Framework", "Aggregation Functions", "Node Feature Updates", "Graph Convolution Definition", "Neighborhood Sampling"],
            # 1.3.x
            ["Early Graph Methods", "Spectral Graph Theory", "Deep Learning Integration", "Modern GCN Development", "Timeline of Innovations"],
            # 1.4.x
            ["Graph Terminology", "Neural Network Terms", "Convolution Concepts", "Learning Paradigms", "Evaluation Vocabulary"],
            # 1.5.x
            ["Structural Differences", "Data Representation", "Convolution Operations", "Application Domains", "Performance Characteristics"],
            # 2.1.x
            ["Layer Architecture", "Weight Matrices", "Activation Functions", "Normalization Techniques", "Implementation Details"],
            # 2.2.x
            ["Sampling Strategy", "Aggregator Functions", "Inductive Learning", "Scalability Features", "Algorithm Variants"],
            # 2.3.x
            ["Attention Mechanism", "Multi-Head Attention", "Attention Weights", "Node Importance", "Performance Benefits"],
            # 2.4.x
            ["Fourier Transform on Graphs", "Spectral Filters", "Chebyshev Polynomials", "Eigenvalue Analysis", "Computational Complexity"],
            # 2.5.x
            ["Graph Transformer", "Graph Isomorphism Networks", "Graph Residual Networks", "Hierarchical GCNs", "Hybrid Architectures"],
            # 3.1.x
            ["Mini-Batch Training", "Full-Batch Training", "Sampling Techniques", "Curriculum Learning", "Transfer Learning"],
            # 3.2.x
            ["Classification Loss", "Regression Loss", "Contrastive Loss", "Graph-Level Loss", "Regularization Terms"],
            # 3.3.x
            ["Gradient Descent Variants", "Adaptive Learning Rates", "Momentum Techniques", "Second-Order Methods", "Graph-Specific Optimizers"],
            # 3.4.x
            ["Hyperparameter Selection", "Architecture Search", "Cross-Validation", "Grid Search", "Bayesian Optimization"],
            # 3.5.x
            ["Node-Level Metrics", "Graph-Level Metrics", "Link Prediction Metrics", "Clustering Metrics", "Robustness Measures"],
            # 4.1.x
            ["Feature Homogenization", "Deep Layer Problems", "Information Loss", "Mitigation Strategies", "Theoretical Analysis"],
            # 4.2.x
            ["Memory Complexity", "Computational Bottlenecks", "Large Graph Challenges", "Distributed Computing", "Approximation Methods"],
            # 4.3.x
            ["Feature Attribution", "Attention Visualization", "Graph Explanation", "Model Transparency", "Causal Analysis"],
            # 4.4.x
            ["Heterophilic Graphs", "Neighborhood Diversity", "Adaptive Aggregation", "Performance Degradation", "Specialized Architectures"],
            # 4.5.x
            ["Domain Adaptation", "Graph Distribution Shift", "Size Generalization", "Structure Invariance", "Robustness Testing"],
            # 5.1.x
            ["Semi-Supervised Learning", "Social Network Analysis", "Citation Networks", "Biological Networks", "Knowledge Graphs"],
            # 5.2.x
            ["Graph Completion", "Recommendation Engines", "Drug Discovery", "Social Link Prediction", "Knowledge Base Completion"],
            # 5.3.x
            ["Molecular Property Prediction", "Chemical Compound Analysis", "Social Network Classification", "Program Analysis", "Image Scene Understanding"],
            # 5.4.x
            ["Collaborative Filtering", "Content-Based Filtering", "Hybrid Approaches", "Session-Based Recommendations", "Multi-Stakeholder Systems"],
            # 5.5.x
            ["Materials Science", "Transportation Networks", "Financial Networks", "Computer Vision", "Natural Language Processing"]
        ]
        
        # Build detail nodes dictionary
        idx = 0
        for main in range(1, 6):
            for sub in range(1, 6):
                for detail in range(1, 6):
                    node_id = f"{main}.{sub}.{detail}"
                    detail_nodes[node_id] = detail_topics[idx][detail-1]
                idx += 1
        
        # Combine all nodes
        all_nodes = {}
        all_nodes.update(main_topics)
        all_nodes.update(sub_topics)
        all_nodes.update(detail_nodes)
        
        # Create node data structure
        for node_id, title in all_nodes.items():
            level = len(node_id.split("."))
            parent = ""
            children = []
            
            if level == 1:
                children = [f"{node_id}.{i}" for i in range(1, 6)]
            elif level == 2:
                parent = node_id.split(".")[0]
                children = [f"{node_id}.{i}" for i in range(1, 6)]
            else:
                parent = ".".join(node_id.split(".")[:-1])
            
            # Generate tags
            tags = ["GCN", f"Level{level}"]
            main_topic = node_id.split(".")[0]
            topic_tags = {"1": "foundations", "2": "architectures", "3": "optimization", "4": "challenges", "5": "applications"}
            tags.append(topic_tags[main_topic])
            
            self.nodes[node_id] = {
                "id": node_id,
                "title": title,
                "level": level,
                "parent": parent,
                "children": children,
                "tags": tags,
                "alias": [title]
            }
        
        # Generate links based on relationships
        self._generate_links()
    
    def _generate_links(self):
        """Generate all links between nodes"""
        for node_id, node_data in self.nodes.items():
            # Parent-child links
            if node_data["parent"]:
                self.links.append({
                    "source": node_data["parent"],
                    "target": node_id,
                    "type": "parent-child"
                })
            
            # Sibling links
            siblings = self._get_siblings(node_id)
            for sibling in siblings[:2]:  # Limit to 2 siblings per node
                self.links.append({
                    "source": node_id,
                    "target": sibling,
                    "type": "sibling"
                })
            
            # Cousin links
            cousins = self._get_cousins(node_id)
            for cousin in cousins[:1]:  # Limit to 1 cousin per node
                self.links.append({
                    "source": node_id,
                    "target": cousin,
                    "type": "cousin"
                })
            
            # Transversal links
            transversals = self._get_transversals(node_id)
            for transversal in transversals[:1]:  # Limit to 1 transversal per node
                self.links.append({
                    "source": node_id,
                    "target": transversal,
                    "type": "transversal"
                })
    
    def _get_siblings(self, node_id: str) -> List[str]:
        """Get sibling nodes"""
        if "." not in node_id:
            return [id for id in self.nodes.keys() if "." not in id and id != node_id]
        elif node_id.count(".") == 1:
            main = node_id.split(".")[0]
            return [id for id in self.nodes.keys() if id.startswith(main + ".") and id.count(".") == 1 and id != node_id]
        else:
            sub = ".".join(node_id.split(".")[:-1])
            return [id for id in self.nodes.keys() if id.startswith(sub + ".") and id.count(".") == 2 and id != node_id]
    
    def _get_cousins(self, node_id: str) -> List[str]:
        """Get cousin nodes"""
        if node_id.count(".") != 2:
            return []
        
        main = node_id.split(".")[0]
        sub = ".".join(node_id.split(".")[:-1])
        
        cousins = []
        for id in self.nodes.keys():
            if id.startswith(main + ".") and not id.startswith(sub + ".") and id.count(".") == 2:
                cousins.append(id)
        return cousins[:3]
    
    def _get_transversals(self, node_id: str) -> List[str]:
        """Get transversal nodes"""
        main = node_id.split(".")[0]
        
        transversals = []
        for other_main in ["1", "2", "3", "4", "5"]:
            if other_main != main:
                if node_id.count(".") == 0:
                    transversals.append(other_main)
                elif node_id.count(".") == 1:
                    transversals.append(f"{other_main}.1")
                else:
                    transversals.append(f"{other_main}.1.1")
                    
        return transversals[:2]
    
    def export_json(self):
        """Export to JSON format"""
        output = {
            "metadata": {
                "title": "GCN Knowledge Graph",
                "total_nodes": len(self.nodes),
                "total_links": len(self.links),
                "created": "2025-06-09",
                "version": "1.0"
            },
            "nodes": list(self.nodes.values()),
            "links": self.links
        }
        
        output_path = self.vault_path / "02_Export" / "graph_structure.json"
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2, ensure_ascii=False)
        
        print(f"JSON export created: {output_path}")
        return output_path
    
    def export_graphml(self):
        """Export to GraphML format"""
        # Create NetworkX graph
        G = nx.DiGraph()
        
        # Add nodes
        for node_id, node_data in self.nodes.items():
            G.add_node(node_id, 
                      title=node_data["title"],
                      level=node_data["level"],
                      tags=",".join(node_data["tags"]))
        
        # Add edges
        for link in self.links:
            G.add_edge(link["source"], link["target"], type=link["type"])
        
        # Export to GraphML
        output_path = self.vault_path / "02_Export" / "graph.graphml"
        nx.write_graphml(G, output_path)
        
        print(f"GraphML export created: {output_path}")
        return output_path
    
    def export_markmap(self):
        """Export to Markmap format"""
        markmap_content = "# GCN Knowledge Graph\n\n"
        
        # Build hierarchical structure
        for main_id in ["1", "2", "3", "4", "5"]:
            main_node = self.nodes[main_id]
            markmap_content += f"## {main_node['title']}\n\n"
            
            for sub_id in [f"{main_id}.{i}" for i in range(1, 6)]:
                sub_node = self.nodes[sub_id]
                markmap_content += f"### {sub_node['title']}\n\n"
                
                for detail_id in [f"{sub_id}.{i}" for i in range(1, 6)]:
                    detail_node = self.nodes[detail_id]
                    markmap_content += f"- {detail_node['title']}\n"
                
                markmap_content += "\n"
        
        output_path = self.vault_path / "02_Export" / "mindmap.markmap.md"
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(markmap_content)
        
        print(f"Markmap export created: {output_path}")
        return output_path
    
    def export_html(self):
        """Export to HTML with D3.js visualization"""
        html_content = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCN Knowledge Graph</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; }
        #graph { width: 100vw; height: 100vh; }
        .node { cursor: pointer; }
        .node circle { fill: #69b3a2; stroke: #fff; stroke-width: 1.5px; }
        .node.level1 circle { fill: #e74c3c; r: 12; }
        .node.level2 circle { fill: #3498db; r: 8; }
        .node.level3 circle { fill: #2ecc71; r: 6; }
        .node text { fill: #333; font-size: 10px; text-anchor: middle; }
        .link { stroke: #999; stroke-opacity: 0.6; stroke-width: 1.5px; }
        .link.parent-child { stroke: #e74c3c; }
        .link.sibling { stroke: #3498db; }
        .link.cousin { stroke: #f39c12; }
        .link.transversal { stroke: #9b59b6; }
        #info { position: absolute; top: 10px; left: 10px; background: rgba(255,255,255,0.9); padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <div id="info">
        <h3>GCN Knowledge Graph</h3>
        <p>Nodes: ''' + str(len(self.nodes)) + '''</p>
        <p>Links: ''' + str(len(self.links)) + '''</p>
        <p>Click nodes to explore</p>
    </div>
    <div id="graph"></div>
    
    <script>
        const data = ''' + json.dumps({"nodes": list(self.nodes.values()), "links": self.links}) + ''';
        
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        const svg = d3.select("#graph")
            .append("svg")
            .attr("width", width)
            .attr("height", height);
        
        const simulation = d3.forceSimulation(data.nodes)
            .force("link", d3.forceLink(data.links).id(d => d.id).distance(50))
            .force("charge", d3.forceManyBody().strength(-100))
            .force("center", d3.forceCenter(width / 2, height / 2));
        
        const link = svg.append("g")
            .selectAll("line")
            .data(data.links)
            .enter().append("line")
            .attr("class", d => `link ${d.type}`);
        
        const node = svg.append("g")
            .selectAll(".node")
            .data(data.nodes)
            .enter().append("g")
            .attr("class", d => `node level${d.level}`)
            .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));
        
        node.append("circle");
        
        node.append("text")
            .text(d => d.title.length > 20 ? d.title.substring(0, 20) + "..." : d.title)
            .attr("dy", -15);
        
        node.on("click", function(event, d) {
            alert(`Node: ${d.title}\\nID: ${d.id}\\nLevel: ${d.level}\\nTags: ${d.tags.join(", ")}`);
        });
        
        simulation.on("tick", () => {
            link
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);
            
            node
                .attr("transform", d => `translate(${d.x},${d.y})`);
        });
        
        function dragstarted(event, d) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }
        
        function dragged(event, d) {
            d.fx = event.x;
            d.fy = event.y;
        }
        
        function dragended(event, d) {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }
    </script>
</body>
</html>'''
        
        output_path = self.vault_path / "02_Export" / "index.html"
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"HTML export created: {output_path}")
        return output_path
    
    def export_jupyter(self):
        """Export to Jupyter notebook format"""
        notebook_content = {
            "cells": [
                {
                    "cell_type": "markdown",
                    "metadata": {},
                    "source": ["# GCN Knowledge Graph Analysis\n\nThis notebook provides analysis and visualization of the GCN Knowledge Graph structure."]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "source": [
                        "import json\nimport networkx as nx\nimport matplotlib.pyplot as plt\nimport pandas as pd\nimport numpy as np\nfrom collections import Counter\n\n# Load graph data\nwith open('graph_structure.json', 'r') as f:\n    data = json.load(f)\n\nnodes = data['nodes']\nlinks = data['links']\n\nprint(f\"Total nodes: {len(nodes)}\")\nprint(f\"Total links: {len(links)}\")"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "source": [
                        "# Create NetworkX graph\nG = nx.DiGraph()\n\n# Add nodes\nfor node in nodes:\n    G.add_node(node['id'], **node)\n\n# Add edges\nfor link in links:\n    G.add_edge(link['source'], link['target'], type=link['type'])\n\nprint(f\"Graph created with {G.number_of_nodes()} nodes and {G.number_of_edges()} edges\")"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "source": [
                        "# Analyze graph structure\nprint(\"Graph Analysis:\")\nprint(f\"- Density: {nx.density(G):.4f}\")\nprint(f\"- Average degree: {sum(dict(G.degree()).values()) / G.number_of_nodes():.2f}\")\n\n# Level distribution\nlevel_counts = Counter([node['level'] for node in nodes])\nprint(f\"\\nLevel distribution:\")\nfor level, count in sorted(level_counts.items()):\n    print(f\"  Level {level}: {count} nodes\")"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "source": [
                        "# Visualize graph\nplt.figure(figsize=(15, 10))\npos = nx.spring_layout(G, k=1, iterations=50)\n\n# Color nodes by level\ncolors = {1: 'red', 2: 'blue', 3: 'green'}\nnode_colors = [colors[G.nodes[node]['level']] for node in G.nodes()]\nnode_sizes = [300 if G.nodes[node]['level'] == 1 else 150 if G.nodes[node]['level'] == 2 else 50 for node in G.nodes()]\n\nnx.draw(G, pos, node_color=node_colors, node_size=node_sizes, \n        with_labels=False, alpha=0.7, edge_color='gray', arrows=True)\n\nplt.title('GCN Knowledge Graph Visualization')\nplt.axis('off')\nplt.tight_layout()\nplt.show()"
                    ]
                },
                {
                    "cell_type": "code",
                    "execution_count": None,
                    "metadata": {},
                    "source": [
                        "# Create DataFrame for analysis\ndf_nodes = pd.DataFrame(nodes)\ndf_links = pd.DataFrame(links)\n\nprint(\"Node DataFrame:\")\nprint(df_nodes.head())\n\nprint(\"\\nLink DataFrame:\")\nprint(df_links.head())\n\nprint(\"\\nLink type distribution:\")\nprint(df_links['type'].value_counts())"
                    ]
                }
            ],
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3"
                },
                "language_info": {
                    "name": "python",
                    "version": "3.8.0"
                }
            },
            "nbformat": 4,
            "nbformat_minor": 4
        }
        
        output_path = self.vault_path / "02_Export" / "vault_structure.ipynb"
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(notebook_content, f, indent=2)
        
        print(f"Jupyter notebook created: {output_path}")
        return output_path
    
    def export_all(self):
        """Export all formats"""
        print("Generating all export formats...")
        self.export_json()
        self.export_graphml()
        self.export_markmap()
        self.export_html()
        self.export_jupyter()
        print("All exports completed!")

if __name__ == "__main__":
    exporter = ExportGenerator("/workspace/GCN_Knowledge_Graph")
    exporter.export_all()
