# Node Templates

## Main Topic Template
```yaml
---
id: "{id}"
title: "{title}"
level: 1
parent: null
children: ["{id}.1", "{id}.2", "{id}.3", "{id}.4", "{id}.5"]
tags: ["Transformer", "Level1", "MainTopic"]
alias: []
created: "2025-06-09"
updated: "2025-06-09"
---
```

## Sub-Topic Template
```yaml
---
id: "{id}"
title: "{title}"
level: 2
parent: "{parent_id}"
children: ["{id}.1", "{id}.2", "{id}.3", "{id}.4", "{id}.5"]
tags: ["Transformer", "Level2", "SubTopic"]
alias: []
created: "2025-06-09"
updated: "2025-06-09"
---
```

## Detail Node Template
```yaml
---
id: "{id}"
title: "{title}"
level: 3
parent: "{parent_id}"
children: []
tags: ["Transformer", "Level3", "DetailNode"]
alias: []
created: "2025-06-09"
updated: "2025-06-09"
---
```
