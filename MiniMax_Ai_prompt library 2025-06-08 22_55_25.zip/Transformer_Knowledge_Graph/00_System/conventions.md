# Vault Conventions

## File Naming
- Main topics: `{id}_{title}.md`
- Sub-topics: `{id}_{title}.md` in `{main}_Sub/`
- Detail nodes: `{id}_{title}.md` in `{main}_Detail/`

## ID Format
- Main: `{1-5}`
- Sub: `{main}.{1-5}`
- Detail: `{main}.{sub}.{1-5}`

## YAML Frontmatter
Required fields: id, title, level, parent, children, tags, alias, created, updated

## Content Structure
1. Definition
2. Semantic Core
3. Parent Reference
4. Sibling Links
5. Cousin Reference
6. Transversal Insight
7. Vault Traceback

## Linking Strategy
- Minimum 3 links per node
- 4-dimensional link types
- No orphan nodes allowed
