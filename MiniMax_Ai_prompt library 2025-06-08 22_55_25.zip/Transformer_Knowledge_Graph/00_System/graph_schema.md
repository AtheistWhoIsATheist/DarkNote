# Graph Schema

## Node Structure
- **Level 1**: Main Topics (5 nodes)
- **Level 2**: Sub-Topics (25 nodes, 5 per main)
- **Level 3**: Detail Nodes (95 nodes, 5 per sub-topic)

## Link Types
1. **Parent-Child**: Hierarchical relationships
2. **Sibling**: Same-level, same-parent relationships
3. **Cousin**: Same-level, same-main-topic relationships
4. **Transversal**: Cross-main-topic relationships

## Total Statistics
- **Nodes**: 125 total
- **Links**: 375+ total (average 3+ per node)
- **Depth**: 3 levels
- **Branching Factor**: 5 consistent across all levels
