# Transformer Knowledge Graph - Export Formats

This directory contains multiple export formats of the Transformer Architecture Knowledge Graph for maximum portability and interoperability.

## Available Formats

### 1. JSON Export (`graph_structure.json`)
Complete graph structure with all nodes, links, and metadata in JSON format.

### 2. GraphML Export (`graph.graphml`)
Standard GraphML format compatible with Cytoscape, Gephi, and other graph analysis tools.

### 3. Markmap Export (`mindmap.markmap.md`)
Interactive mind mapping format compatible with Markmap and similar tools.

### 4. HTML Visualization (`index.html`)
Complete interactive web visualization with D3.js.

### 5. Jupyter Notebook (`vault_structure.ipynb`)
Comprehensive NetworkX-based analysis and visualization.

### 6. README (`README.md`)
This file with deployment instructions and format descriptions.

## Graph Statistics
- **Total Nodes**: 125
- **Total Links**: 1173
- **Main Topics**: 5
- **Sub-Topics**: 25  
- **Detail Nodes**: 95

Created: 2025-06-09
Version: 1.0.0
Author: Research Agent
