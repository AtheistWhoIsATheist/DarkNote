# GCN Knowledge Graph Schema

## Node Hierarchy
```
Level 1: Main Topics (5 nodes)
├─ Level 2: Sub-Topics (25 nodes, 5 per main)
   └─ Level 3: Detail Nodes (95 nodes, 5 per sub-topic)
```

## ID Structure
- Main: "1", "2", "3", "4", "5"
- Sub: "1.1", "1.2", ..., "5.5"
- Detail: "1.1.1", "1.1.2", ..., "5.5.5"

## Linking Requirements
- Every node MUST have: 1 parent + ≥1 sibling + ≥1 cousin + ≥1 transversal
- Total edges target: ≥375 across 125 nodes
- Zero orphan nodes allowed

## Content Standards
- YAML frontmatter required for all files
- 7-section content structure mandatory
- Semantic coherence across all levels
- Factual accuracy about GCN concepts

## Export Formats
1. graph_structure.json - Complete graph data
2. graph.graphml - Network analysis format
3. mindmap.markmap.md - Hierarchical visualization
4. index.html - Interactive web visualization
5. vault_structure.ipynb - Jupyter analysis notebook
