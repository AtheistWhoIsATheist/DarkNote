# GCN Knowledge Graph Templates

## Node Creation Template

### YAML Frontmatter
```yaml
---
id: "{node_id}"
title: "{exact_title}"
level: {1|2|3}
parent: "{parent_id}"
children: ["{child_id1}", "{child_id2}"]
tags: [GCN, Level{1|2|3}, {topic_tag}]
alias: ["{alternative_name}"]
created: "2025-06-09"
updated: "2025-06-09"
---
```

### Content Structure
```markdown
# {Node Title}

## ❶ Definition
{Precise technical definition of the concept}

## ❷ Semantic Core
- {Key point 1}
- {Key point 2}
- {Key point 3}
- {Key point 4}

## ❸ Parent Reference
- [[{parent_id}]]

## ❹ Sibling Links
- [[{sibling_1}]]
- [[{sibling_2}]]
- [[{sibling_3}]]

## ❺ Cousin Reference
- [[{cousin_1}]]
- [[{cousin_2}]]

## ❻ Transversal Insight
- [[{transversal_1}]]
- [[{transversal_2}]]

## ❼ Vault Traceback
```dataview
TABLE id, file.name
WHERE contains(tags, "GCN") AND id = "{current_id}"
```
```

## Link Type Definitions

### Parent-Child Links
- **Purpose**: Hierarchical relationships
- **Direction**: Bidirectional (parent ↔ child)
- **Requirement**: Every non-root node has exactly 1 parent

### Sibling Links
- **Purpose**: Horizontal relationships at same level
- **Direction**: Undirected (sibling ↔ sibling)
- **Requirement**: Every node has ≥1 sibling connection

### Cousin Links
- **Purpose**: Cross-sub-topic relationships within same main topic
- **Direction**: Undirected (cousin ↔ cousin)
- **Requirement**: Detail nodes should have ≥1 cousin connection

### Transversal Links
- **Purpose**: Cross-domain knowledge connections
- **Direction**: Undirected (transversal ↔ transversal)
- **Requirement**: Every node should have ≥1 transversal connection

## Naming Conventions

### File Names
- Main topics: `{id}_{Title_Words_Separated}.md`
- Sub-topics: `{id}_{Title_Words_Separated}.md`
- Detail nodes: `{id}_{Title_Words_Separated}.md`

### Special Characters
- Replace spaces with underscores
- Remove parentheses and special symbols
- Maintain readability and system compatibility

### Directory Structure
```
01_Main/
├── {main_files}
├── {main_id}_Sub/
│   └── {sub_files}
└── {main_id}_Detail/
    └── {detail_files}
```

## Tag System

### Required Tags
- `GCN`: Universal identifier
- `Level{1|2|3}`: Hierarchical level indicator
- `{topic}`: Domain-specific tag

### Topic Tags
- `foundations`: Core concepts and theory
- `architectures`: Network designs and variants
- `optimization`: Training and tuning methods
- `challenges`: Limitations and problems
- `applications`: Real-world use cases

### Optional Tags
- `theory`: Theoretical concepts
- `practical`: Implementation details
- `advanced`: Complex topics
- `basic`: Fundamental concepts
