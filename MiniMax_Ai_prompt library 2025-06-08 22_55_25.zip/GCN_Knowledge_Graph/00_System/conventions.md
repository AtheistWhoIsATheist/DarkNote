# GCN Knowledge Graph Conventions

## File Naming
- Main topics: `{id}_{Title}.md` (e.g., "1_Foundations.md")
- Sub-topics: `{id}_{Title}.md` (e.g., "1.1_Intro_Graph_Structures.md")
- Detail nodes: `{id}_{Title}.md` (e.g., "1.1.1_Graph_Composition.md")

## YAML Frontmatter Template
```yaml
id: "{node_id}"
title: "{exact_title}"
level: {1|2|3}
parent: "{parent_id}"
children: ["{child_id1}", "{child_id2}"]
tags: [GCN, Level{1|2|3}, {topic_tag}]
alias: ["{alternative_name}"]
created: "2025-06-09"
updated: "2025-06-09"
```

## Content Structure Sections
1. ❶ Definition - Precise definition of the concept
2. ❷ Semantic Core - Key points (3-5 bullets)
3. ❸ Parent Reference - Link to parent node
4. ❹ Sibling Links - Links to sibling nodes
5. ❺ Cousin Reference - Links to cousins in same main topic
6. ❻ Transversal Insight - Links across different main topics
7. ❼ Vault Traceback - Dataview query for validation

## Linking Strategy
- **Parent**: Direct hierarchical parent
- **Siblings**: Nodes at same level with same parent
- **Cousins**: Nodes in same main topic but different sub-topic
- **Transversal**: Nodes in completely different main topics

## Tag Categories
- Level tags: Level1, Level2, Level3
- Topic tags: foundations, architectures, optimization, challenges, applications
- Concept tags: theory, practical, advanced, basic
