import React from 'react';
import { useNotesDispatch } from '../../../context/NotesContext';

const Header = () => {
  const { dispatch } = useNotesDispatch();
  return (
    <header className="app-header">
      <h1>QuickNote</h1>
      <button onClick={() => dispatch({ type: 'SELECT_NOTE', payload: null })}>New Note</button>
    </header>
  );
};

export default Header;