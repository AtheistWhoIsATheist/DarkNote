import React, { useState, useEffect } from 'react';
import { useNotesDispatch } from '../../../context/NotesContext';
import { parseWikiLinks } from '../../../lib/linkParser';

const InputArea = ({ noteToEdit }) => {
  const { addNote } = useNotesDispatch();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState([]);
  const [currentTag, setCurrentTag] = useState('');
  const isEditing = Boolean(noteToEdit);

  useEffect(() => {
    if (isEditing) {
      setTitle(noteToEdit.title);
      setContent(noteToEdit.content);
      setTags(noteToEdit.tags || []);
    } else {
      setTitle('');
      setContent('');
      setTags([]);
    }
  }, [noteToEdit]);

  const handleTagInput = e => {
    if (['Enter', ',', ' '].includes(e.key) && currentTag.trim()) {
      e.preventDefault();
      const newTag = currentTag.trim().toLowerCase();
      if (!tags.includes(newTag)) setTags([...tags, newTag]);
      setCurrentTag('');
    }
  };

  const save = async () => {
    if (!title.trim() && !content.trim()) return alert('Title or content required');
    const { linkedNoteIds } = parseWikiLinks(content);
    await addNote({ title: title.trim() || 'Untitled', content, tags, linkedNoteIds });
    if (!isEditing) setTitle(''), setContent(''), setTags([]);
  };

  return (
    <div className="input-area">
      <h3>{isEditing ? 'Edit Note' : 'Create New Note'}</h3>
      <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" />
      <textarea value={content} onChange={e => setContent(e.target.value)} rows={10} />
      <div className="tags">
        {tags.map(t => (
          <span key={t} onClick={() => setTags(tags.filter(x => x !== t))}>
            {t} ×
          </span>
        ))}
      </div>
      <input
        value={currentTag}
        onChange={e => setCurrentTag(e.target.value)}
        onKeyDown={handleTagInput}
        placeholder="Add tags"
      />
      <button onClick={save}>{isEditing ? 'Save Changes' : 'Add Note'}</button>
    </div>
  );
};

export default InputArea;