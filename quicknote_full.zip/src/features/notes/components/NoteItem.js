import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useNotesDispatch } from '../../../context/NotesContext';
import { exportNoteToFile } from '../../../lib/exportUtils';

const NoteItem = React.memo(({ note, style }) => {
  const { dispatch } = useNotesDispatch();
  const select = () => dispatch({ type: 'SELECT_NOTE', payload: note.id });
  const remove = e => {
    e.stopPropagation();
    alert('Delete placeholder');
  };
  const exp = e => {
    e.stopPropagation();
    exportNoteToFile(note);
  };

  return (
    <div className="note-item" style={style} onClick={select}>
      <h4>{note.title}</h4>
      <ReactMarkdown remarkPlugins={[remarkGfm]}>
        {note.content.slice(0, 100) + (note.content.length > 100 ? '...' : '')}
      </ReactMarkdown>
      <div className="actions">
        <button onClick={exp}>Export</button>
        <button onClick={remove}>Delete</button>
      </div>
      <small>{new Date(note.modified).toLocaleDateString()}</small>
    </div>
  );
});

export default NoteItem;