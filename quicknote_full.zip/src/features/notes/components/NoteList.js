import React from 'react';
import { FixedSizeList as List } from 'react-window';
import NoteItem from './NoteItem';
import { useNotesState } from '../../../context/NotesContext';

const NoteList = () => {
  const { notes, isLoading, error } = useNotesState();
  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  if (!notes.length) return <p>No notes</p>;
  return (
    <List height={600} itemCount={notes.length} itemSize={120} width="100%">
      {({ index, style }) => <NoteItem key={notes[index].id} note={notes[index]} style={style} />}
    </List>
  );
};

export default NoteList;