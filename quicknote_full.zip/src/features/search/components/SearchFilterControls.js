import React, { useState, useEffect } from 'react';

const SearchFilterControls = () => {
  const [localSearch, setLocalSearch] = useState('');
  const [selectedTags, setSelectedTags] = useState([]);
  const availableTags = ['react', 'pkm', 'javascript', 'indexeddb'];

  useEffect(() => {
    const handler = setTimeout(() => {
      console.log('Filtering notes by', localSearch, selectedTags);
    }, 300);
    return () => clearTimeout(handler);
  }, [localSearch, selectedTags]);

  const toggleTag = tag =>
    setSelectedTags(prev => (prev.includes(tag) ? prev.filter(x => x !== tag) : [...prev, tag]));

  return (
    <div className="search-filter-controls">
      <input
        type="search"
        placeholder="Search notes..."
        value={localSearch}
        onChange={e => setLocalSearch(e.target.value)}
      />
      <div>
        {availableTags.map(tag => (
          <button
            key={tag}
            onClick={() => toggleTag(tag)}
            className={selectedTags.includes(tag) ? 'active' : ''}
          >
            {tag}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SearchFilterControls;