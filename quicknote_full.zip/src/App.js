import React from 'react';
import { NotesProvider } from './context/NotesContext';
import Header from './features/layout/components/Header';
import SearchFilterControls from './features/search/components/SearchFilterControls';
import NoteList from './features/notes/components/NoteList';
import InputArea from './features/input/components/InputArea';
import { useNotesState } from './context/NotesContext';
import './styles/index.css';

const MainPanel = () => {
  const { selectedNoteId, notes } = useNotesState();
  const selectedNote = selectedNoteId ? notes.find(n => n.id === selectedNoteId) : null;
  return <InputArea key={selectedNoteId || 'new'} noteToEdit={selectedNote} />;
};

function App() {
  return (
    <NotesProvider>
      <div className="app-container">
        <Header />
        <main className="app-main">
          <div className="app-left-panel">
            <SearchFilterControls />
            <NoteList />
          </div>
          <div className="app-right-panel">
            <MainPanel />
          </div>
        </main>
      </div>
    </NotesProvider>
  );
}

export default App;