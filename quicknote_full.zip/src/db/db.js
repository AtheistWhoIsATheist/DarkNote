import Dexie from 'dexie';

export const db = new Dexie('QuickNoteDB');
db.version(1).stores({
  notes: '++id, title, *tags, modified, *linkedNoteIds',
  tags: '++id, &name'
});
db.open().catch(err => console.error(`Failed to open db: ${err.stack || err}`));