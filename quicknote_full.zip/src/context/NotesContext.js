import React, { createContext, useReducer, useContext, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '../db/db';

const NotesStateContext = createContext();
const NotesDispatchContext = createContext();

const initialNotesState = {
  notes: [],
  selectedNoteId: null,
  isLoading: true,
  error: null
};

function notesReducer(state, action) {
  switch (action.type) {
    case 'SET_NOTES_SUCCESS':
      return { ...state, notes: action.payload, isLoading: false, error: null };
    case 'SET_NOTES_ERROR':
      return { ...state, isLoading: false, error: action.payload };
    case 'SELECT_NOTE':
      return { ...state, selectedNoteId: action.payload };
    default:
      throw new Error(`Unknown action: ${action.type}`);
  }
}

export const NotesProvider = ({ children }) => {
  const [state, dispatch] = useReducer(notesReducer, initialNotesState);
  const liveNotes = useLiveQuery(() => db.notes.orderBy('modified').reverse().toArray(), []);
  
  useEffect(() => {
    if (liveNotes) dispatch({ type: 'SET_NOTES_SUCCESS', payload: liveNotes });
  }, [liveNotes]);

  const addNote = async noteData => {
    try {
      return await db.notes.add({ ...noteData, created: new Date(), modified: new Date() });
    } catch (error) {
      dispatch({ type: 'SET_NOTES_ERROR', payload: 'Failed to add note' });
    }
  };

  return (
    <NotesStateContext.Provider value={state}>
      <NotesDispatchContext.Provider value={{ dispatch, addNote }}>
        {children}
      </NotesDispatchContext.Provider>
    </NotesStateContext.Provider>
  );
};

export const useNotesState = () => {
  const context = useContext(NotesStateContext);
  if (!context) throw new Error('useNotesState must be used within NotesProvider');
  return context;
};

export const useNotesDispatch = () => {
  const context = useContext(NotesDispatchContext);
  if (!context) throw new Error('useNotesDispatch must be used within NotesProvider');
  return context;
};