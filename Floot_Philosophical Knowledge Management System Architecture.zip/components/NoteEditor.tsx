import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Input } from './Input';
import { Textarea } from './Textarea';
import { Button } from './Button';
import { Spinner } from './Spinner';
import styles from './NoteEditor.module.css';

const noteSchema = z.object({
  title: z.string().min(1, 'Title is required.'),
  content: z.string().min(1, 'Content cannot be empty.'),
  category: z.string().optional(),
});

type NoteFormData = z.infer<typeof noteSchema>;

interface NoteEditorProps {
  onSave: (data: NoteFormData) => void;
  onCancel: () => void;
  isSaving: boolean;
  initialData?: Partial<NoteFormData>;
  className?: string;
}

export const NoteEditor: React.FC<NoteEditorProps> = ({
  onSave,
  onCancel,
  isSaving,
  initialData = {},
  className,
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors, isDirty },
  } = useForm<NoteFormData>({
    resolver: zodResolver(noteSchema),
    defaultValues: {
      title: initialData.title || '',
      content: initialData.content || '',
      category: initialData.category || '',
    },
  });

  return (
    <form onSubmit={handleSubmit(onSave)} className={`${styles.editorForm} ${className || ''}`}>
      <div className={styles.field}>
        <Controller
          name="title"
          control={control}
          render={({ field }) => (
            <Input
              {...field}
              placeholder="Note Title"
              className={styles.titleInput}
              aria-invalid={!!errors.title}
            />
          )}
        />
        {errors.title && <p className={styles.error}>{errors.title.message}</p>}
      </div>

      <div className={styles.field}>
        <Controller
          name="content"
          control={control}
          render={({ field }) => (
            <Textarea
              {...field}
              placeholder="Begin your thoughts here..."
              className={styles.contentInput}
              rows={10}
              aria-invalid={!!errors.content}
            />
          )}
        />
        {errors.content && <p className={styles.error}>{errors.content.message}</p>}
      </div>

      <div className={styles.actions}>
        <Button type="button" variant="ghost" onClick={onCancel} disabled={isSaving}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSaving || !isDirty}>
          {isSaving && <Spinner size="sm" />}
          {isSaving ? 'Saving...' : 'Save Note'}
        </Button>
      </div>
    </form>
  );
};