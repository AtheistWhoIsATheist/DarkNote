import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import styles from './SharedLayout.module.css';
import { BookOpenCheck } from 'lucide-react';

interface SharedLayoutProps {
  children: React.ReactNode;
}

export const SharedLayout: React.FC<SharedLayoutProps> = ({ children }) => {
  return (
    <div className={styles.layout}>
      <header className={styles.header}>
        <div className={styles.headerContent}>
          <Link to="/" className={styles.logo}>
            <BookOpenCheck size={24} />
            <span>NIHILTHEOS</span>
          </Link>
          <nav className={styles.nav}>
            <NavLink
              to="/"
              className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
              end
            >
              Home
            </NavLink>
            <NavLink
              to="/vault"
              className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ''}`}
            >
              The Vault
            </NavLink>
          </nav>
        </div>
      </header>
      <main className={styles.main}>
        {children}
      </main>
      <footer className={styles.footer}>
        <p>&copy; {new Date().getFullYear()} NIHILTHEOS Protocol. All rights reserved.</p>
      </footer>
    </div>
  );
};