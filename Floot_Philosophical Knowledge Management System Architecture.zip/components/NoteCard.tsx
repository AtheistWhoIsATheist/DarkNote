import React, { useState } from 'react';
import type { Selectable } from 'kysely';
import type { Notes } from '../helpers/schema';
import { useAnalyzeNoteMutation, useTransformNoteMutation } from '../helpers/notesApi';
import { analysisTypes, AnalysisType } from '../endpoints/notes/analyze_POST.schema';
import { transformationTypes, TransformationType } from '../endpoints/notes/transform_POST.schema';
import { Button } from './Button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './Dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './Tabs';
import { Spinner } from './Spinner';
import { BrainCircuit, PenTool, Sparkles } from 'lucide-react';
import styles from './NoteCard.module.css';

interface NoteCardProps {
  note: Selectable<Notes>;
}

export const NoteCard: React.FC<NoteCardProps> = ({ note }) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('analysis');

  const analyzeMutation = useAnalyzeNoteMutation();
  const transformMutation = useTransformNoteMutation();

  const handleAnalysis = (analysisType: AnalysisType) => {
    analyzeMutation.mutate({ noteId: note.id, analysisType });
  };

  const handleTransform = (transformationType: TransformationType) => {
    transformMutation.mutate({ noteId: note.id, transformationType }, {
      onSuccess: () => setIsDialogOpen(false)
    });
  };

  const analysisTools = [
    { type: 'phenomenologicalDescription', label: 'Describe Phenomenon' },
    { type: 'uncoverAssumptions', label: 'Uncover Assumptions' },
    { type: 'existentialAnalysis', label: 'Existential Analysis' },
  ];

  const engineeringTools = [
    { type: 'refineClarity', label: 'Refine Clarity' },
    { type: 'addNuance', label: 'Add Nuance' },
    { type: 'socraticInquiry', label: 'Reframe as Socratic Inquiry' },
  ];

  return (
    <>
      <div className={styles.card}>
        <div className={styles.cardContent}>
          <h3 className={styles.cardTitle}>{note.title}</h3>
          <p className={styles.cardText}>{note.content}</p>
        </div>
        <div className={styles.cardFooter}>
          <span className={styles.date}>
            {new Date(note.updatedAt || note.createdAt!).toLocaleDateString()}
          </span>
          <Button variant="ghost" size="sm" onClick={() => setIsDialogOpen(true)}>
            <Sparkles size={16} />
            AI Tools
          </Button>
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className={styles.dialogContent}>
          <DialogHeader>
            <DialogTitle>AI Workbench</DialogTitle>
            <DialogDescription>
              Apply AI-powered analysis and transformations to your note: "{note.title}"
            </DialogDescription>
          </DialogHeader>
          <Tabs value={activeTab} onValueChange={setActiveTab} className={styles.tabs}>
            <TabsList>
              <TabsTrigger value="analysis"><BrainCircuit size={16} /> Analysis Suite</TabsTrigger>
              <TabsTrigger value="engineering"><PenTool size={16} /> Engineering Suite</TabsTrigger>
            </TabsList>
            <TabsContent value="analysis" className={styles.tabContent}>
              <p className={styles.toolDescription}>Generate a new analysis based on the note. The result will appear below.</p>
              <div className={styles.toolGrid}>
                {analysisTypes.map((type) => (
                  <Button
                    key={type}
                    variant="secondary"
                    onClick={() => handleAnalysis(type)}
                    disabled={analyzeMutation.isPending}
                  >
                    {analysisTools.find(t => t.type === type)?.label}
                  </Button>
                ))}
              </div>
              {analyzeMutation.isPending && <div className={styles.loadingOverlay}><Spinner /> <p>Analyzing...</p></div>}
              {analyzeMutation.isError && <p className={styles.errorText}>Analysis failed: {analyzeMutation.error.message}</p>}
              {analyzeMutation.data && (
                <div className={styles.analysisResult}>
                  <h4>Analysis Result:</h4>
                  <p>{analyzeMutation.data.analysis}</p>
                </div>
              )}
            </TabsContent>
            <TabsContent value="engineering" className={styles.tabContent}>
              <p className={styles.toolDescription}>Create a new, refined note based on the current one. This action is irreversible and preserves the original.</p>
              <div className={styles.toolGrid}>
                {transformationTypes.map((type) => (
                  <Button
                    key={type}
                    variant="secondary"
                    onClick={() => handleTransform(type)}
                    disabled={transformMutation.isPending}
                  >
                    {engineeringTools.find(t => t.type === type)?.label}
                  </Button>
                ))}
              </div>
              {transformMutation.isPending && <div className={styles.loadingOverlay}><Spinner /> <p>Transforming note...</p></div>}
              {transformMutation.isError && <p className={styles.errorText}>Transformation failed: {transformMutation.error.message}</p>}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  );
};