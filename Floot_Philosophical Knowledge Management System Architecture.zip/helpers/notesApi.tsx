import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getNotes } from "../endpoints/notes_GET.schema";
import { postNotes, InputType as CreateNoteInput } from "../endpoints/notes_POST.schema";
import { postNotesAnalyze, InputType as AnalyzeNoteInput } from "../endpoints/notes/analyze_POST.schema";
import { postNotesTransform, InputType as TransformNoteInput } from "../endpoints/notes/transform_POST.schema";
import { toast } from "sonner";

export const useNotesQuery = () => {
  return useQuery({
    queryKey: ['notes'],
    queryFn: () => getNotes(),
  });
};

export const useCreateNoteMutation = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (newNote: CreateNoteInput) => postNotes(newNote),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      toast.success("Note created successfully.");
    },
    onError: (error) => {
      toast.error(`Failed to create note: ${error.message}`);
    },
  });
};

export const useAnalyzeNoteMutation = () => {
  return useMutation({
    mutationFn: (input: AnalyzeNoteInput) => postNotesAnalyze(input),
    onSuccess: () => {
      toast.success("Analysis complete.");
    },
    onError: (error) => {
      toast.error(`Analysis failed: ${error.message}`);
    },
  });
};

export const useTransformNoteMutation = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: TransformNoteInput) => postNotesTransform(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notes'] });
      toast.success("Note transformed successfully. A new note has been created.");
    },
    onError: (error) => {
      toast.error(`Transformation failed: ${error.message}`);
    },
  });
};