import type { Selectable } from "kysely";
import type { Notes } from "../helpers/schema";
import superjson from 'superjson';

// Note: do not define zod schema for output type - just define the type directly
export type OutputType = Selectable<Notes>[];

export const getNotes = async (init?: RequestInit): Promise<OutputType> => {
  const result = await fetch(`/_api/notes`, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text());
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};