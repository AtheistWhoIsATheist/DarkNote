import { db } from "../../helpers/db";
import { schema, OutputType, TransformationType } from "./transform_POST.schema";
import superjson from 'superjson';
import { nanoid } from "nanoid";
import { Transaction } from "kysely";
import { DB } from "../../helpers/schema";

const getTransformationPrompt = (transformationType: TransformationType, content: string): string => {
  switch (transformationType) {
    case 'refineClarity':
      return `As a philosophical editor, refine the following text for maximum clarity and precision without losing its original meaning. Focus on improving sentence structure, word choice, and logical flow. Text:\n\n"${content}"`;
    case 'addNuance':
      return `As a philosopher, expand upon the following text by adding nuance, considering counterarguments, and exploring subtle implications. Deepen the original thought without contradicting it. Text:\n\n"${content}"`;
    case 'socraticInquiry':
      return `As a philosopher in the Socratic tradition, reframe the core statements in the following text as a series of probing questions. The goal is to stimulate deeper inquiry and reveal underlying assumptions. Text:\n\n"${content}"`;
    default:
      throw new Error("Invalid transformation type");
  }
};

async function callGemini(prompt: string, apiKey: string): Promise<string> {
  const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`;
  
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    console.error("Gemini API Error:", errorBody);
    throw new Error(`Gemini API request failed with status ${response.status}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!text) {
    console.error("Invalid Gemini API response structure:", data);
    throw new Error("Failed to extract text from Gemini response.");
  }

  return text;
}

async function createTransformedNote(
  trx: Transaction<DB>,
  originalNoteId: string,
  transformationType: TransformationType,
  newContent: string
) {
  const originalNote = await trx
    .selectFrom('notes')
    .select(['title', 'category'])
    .where('id', '=', originalNoteId)
    .executeTakeFirstOrThrow();

  const newNote = await trx
    .insertInto('notes')
    .values({
      id: nanoid(),
      title: `[${transformationType}] ${originalNote.title}`,
      content: newContent,
      category: originalNote.category,
      createdAt: new Date(),
      updatedAt: new Date(),
    })
    .returningAll()
    .executeTakeFirstOrThrow();

  await trx
    .insertInto('noteLineages')
    .values({
      id: nanoid(),
      originalNoteId: originalNoteId,
      derivedNoteId: newNote.id,
      transformationType: transformationType,
      createdAt: new Date(),
    })
    .execute();

  return newNote;
}

export async function handle(request: Request) {
  const apiKey = process.env.GOOGLE_GEMINI_API_KEY;
  if (!apiKey) {
    console.error("GOOGLE_GEMINI_API_KEY is not set.");
    return new Response(superjson.stringify({ error: "Server configuration error: Missing API key." }), { status: 500 });
  }

  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const originalNote = await db
      .selectFrom('notes')
      .select('content')
      .where('id', '=', input.noteId)
      .executeTakeFirst();

    if (!originalNote) {
      return new Response(superjson.stringify({ error: "Note not found." }), { status: 404 });
    }

    const prompt = getTransformationPrompt(input.transformationType, originalNote.content);
    const transformedContent = await callGemini(prompt, apiKey);

    const newNote = await db.transaction().execute(async (trx) => {
      return createTransformedNote(trx, input.noteId, input.transformationType, transformedContent);
    });

    return new Response(superjson.stringify(newNote satisfies OutputType), {
      status: 201,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error("Error during note transformation:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: `Failed to transform note: ${errorMessage}` }), { status: 400 });
  }
}