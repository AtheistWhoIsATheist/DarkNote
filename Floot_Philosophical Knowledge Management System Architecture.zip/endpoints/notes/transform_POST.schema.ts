import { z } from "zod";
import superjson from 'superjson';
import type { Selectable } from "kysely";
import type { Notes } from "../../helpers/schema";

export const transformationTypes = [
  'refineClarity',
  'addNuance',
  'socraticInquiry'
] as const;
export type TransformationType = typeof transformationTypes[number];

export const schema = z.object({
  noteId: z.string(),
  transformationType: z.enum(transformationTypes),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = Selectable<Notes>;

export const postNotesTransform = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/notes/transform`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text());
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};