import { z } from "zod";
import superjson from 'superjson';

export const analysisTypes = [
  'phenomenologicalDescription',
  'uncoverAssumptions',
  'existentialAnalysis'
] as const;
export type AnalysisType = typeof analysisTypes[number];

export const schema = z.object({
  noteId: z.string(),
  analysisType: z.enum(analysisTypes),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  analysis: string;
};

export const postNotesAnalyze = async (body: InputType, init?: RequestInit): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/notes/analyze`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse(await result.text());
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};