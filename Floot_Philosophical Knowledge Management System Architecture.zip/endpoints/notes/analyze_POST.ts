import { db } from "../../helpers/db";
import { schema, OutputType, AnalysisType } from "./analyze_POST.schema";
import superjson from 'superjson';

const getAnalysisPrompt = (analysisType: AnalysisType, content: string): string => {
  switch (analysisType) {
    case 'phenomenologicalDescription':
      return `As a philosopher specializing in phenomenology, provide a detailed, first-person, pre-theoretical description of the core experience or phenomenon presented in the following text. Focus on the "what it is like" aspect, avoiding jargon and abstract analysis. Text:\n\n"${content}"`;
    case 'uncoverAssumptions':
      return `As a philosopher skilled in deconstruction, critically analyze the following text to uncover its underlying assumptions, biases, and presuppositions. Identify what the text takes for granted, both explicitly and implicitly. Text:\n\n"${content}"`;
    case 'existentialAnalysis':
      return `As an existential philosopher, analyze the following text through the core concepts of existentialism. Examine themes of Being-in-the-world, thrownness, Angst, freedom, authenticity, and the absurd as they appear in the text. Text:\n\n"${content}"`;
    default:
      throw new Error("Invalid analysis type");
  }
};

async function callGemini(prompt: string, apiKey: string): Promise<string> {
  const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`;
  
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    console.error("Gemini API Error:", errorBody);
    throw new Error(`Gemini API request failed with status ${response.status}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!text) {
    console.error("Invalid Gemini API response structure:", data);
    throw new Error("Failed to extract text from Gemini response.");
  }

  return text;
}

export async function handle(request: Request) {
  const apiKey = process.env.GOOGLE_GEMINI_API_KEY;
  if (!apiKey) {
    console.error("GOOGLE_GEMINI_API_KEY is not set.");
    return new Response(superjson.stringify({ error: "Server configuration error: Missing API key." }), { status: 500 });
  }

  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const note = await db
      .selectFrom('notes')
      .select('content')
      .where('id', '=', input.noteId)
      .executeTakeFirst();

    if (!note) {
      return new Response(superjson.stringify({ error: "Note not found." }), { status: 404 });
    }

    const prompt = getAnalysisPrompt(input.analysisType, note.content);
    const analysisResult = await callGemini(prompt, apiKey);

    const response: OutputType = { analysis: analysisResult };
    return new Response(superjson.stringify(response), {
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error("Error during note analysis:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: `Failed to analyze note: ${errorMessage}` }), { status: 400 });
  }
}