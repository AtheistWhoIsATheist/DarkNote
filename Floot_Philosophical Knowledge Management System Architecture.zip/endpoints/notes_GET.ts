import { db } from "../helpers/db";
import { OutputType } from "./notes_GET.schema";
import superjson from 'superjson';

export async function handle(request: Request) {
  try {
    const notes = await db
      .selectFrom('notes')
      .selectAll()
      .orderBy('updatedAt', 'desc')
      .execute();

    return new Response(superjson.stringify(notes satisfies OutputType), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error("Error fetching notes:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return new Response(superjson.stringify({ error: `Failed to fetch notes: ${errorMessage}` }), { status: 500 });
  }
}