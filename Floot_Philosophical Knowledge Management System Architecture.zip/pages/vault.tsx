import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNotesQuery, useCreateNoteMutation } from '../helpers/notesApi';
import { NoteCard } from '../components/NoteCard';
import { NoteEditor } from '../components/NoteEditor';
import { Button } from '../components/Button';
import { Skeleton } from '../components/Skeleton';
import { PlusCircle, AlertTriangle } from 'lucide-react';
import styles from './vault.module.css';
import type { Selectable } from 'kysely';
import type { Notes } from '../helpers/schema';

const VaultPage = () => {
  const [isCreating, setIsCreating] = useState(false);
  const { data: notes, isFetching, error } = useNotesQuery();
  const createNoteMutation = useCreateNoteMutation();

  const handleCreateNew = () => {
    setIsCreating(true);
  };

  const handleCancelCreate = () => {
    setIsCreating(false);
  };

  const handleSaveNewNote = (note: { title: string; content: string; category?: string }) => {
    createNoteMutation.mutate(note, {
      onSuccess: () => {
        setIsCreating(false);
      },
    });
  };

  const renderContent = () => {
    if (isFetching && !notes) {
      return (
        <div className={styles.notesGrid}>
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className={styles.skeletonCard}>
              <Skeleton style={{ height: '1.5rem', width: '70%', marginBottom: 'var(--spacing-2)' }} />
              <Skeleton style={{ height: '1rem', width: '40%', marginBottom: 'var(--spacing-4)' }} />
              <Skeleton style={{ height: '1rem', width: '90%' }} />
              <Skeleton style={{ height: '1rem', width: '95%' }} />
              <Skeleton style={{ height: '1rem', width: '85%' }} />
            </div>
          ))}
        </div>
      );
    }

    if (error) {
      return (
        <div className={styles.errorState}>
          <AlertTriangle size={48} className={styles.errorIcon} />
          <h2 className={styles.errorTitle}>Failed to load notes</h2>
          <p className={styles.errorMessage}>
            {error instanceof Error ? error.message : 'An unknown error occurred.'}
          </p>
        </div>
      );
    }

    if (!notes || notes.length === 0) {
      return (
        <div className={styles.emptyState}>
          <h2 className={styles.emptyTitle}>The Vault is empty.</h2>
          <p className={styles.emptyText}>
            Begin your intellectual journey by creating your first note.
          </p>
          <Button onClick={handleCreateNew}>
            <PlusCircle size={16} />
            Create First Note
          </Button>
        </div>
      );
    }

    return (
      <div className={styles.notesGrid}>
        {notes.map((note: Selectable<Notes>) => (
          <NoteCard key={note.id} note={note} />
        ))}
      </div>
    );
  };

  return (
    <>
      <Helmet>
        <title>The Vault | NIHILTHEOS Protocol</title>
        <meta name="description" content="Manage and analyze your philosophical insights in The Vault." />
      </Helmet>
      <div className={styles.pageContainer}>
        <header className={styles.pageHeader}>
          <h1 className={styles.pageTitle}>The Vault</h1>
          {!isCreating && (
            <Button onClick={handleCreateNew}>
              <PlusCircle size={16} />
              New Note
            </Button>
          )}
        </header>
        <main className={styles.mainContent}>
          {isCreating && (
            <div className={styles.editorContainer}>
              <NoteEditor
                onSave={handleSaveNewNote}
                onCancel={handleCancelCreate}
                isSaving={createNoteMutation.isPending}
              />
            </div>
          )}
          {renderContent()}
        </main>
      </div>
    </>
  );
};

export default VaultPage;