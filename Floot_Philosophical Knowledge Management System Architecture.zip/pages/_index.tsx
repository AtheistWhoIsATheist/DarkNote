import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '../components/Button';
import { ArrowRight, BrainCircuit, Library, PenTool, Sparkles } from 'lucide-react';
import styles from './_index.module.css';

const IndexPage = () => {
  const features = [
    {
      icon: <Library size={24} />,
      title: 'The Vault',
      description: 'A permanent, structured repository for your crystallized philosophical insights. Preserve your intellectual lineage with clarity and permanence.',
    },
    {
      icon: <BrainCircuit size={24} />,
      title: 'AI Workbench',
      description: 'A dynamic space for intellectual transformation. Engage with your ideas, challenge assumptions, and refine your thoughts with AI-assisted analysis.',
    },
    {
      icon: <Sparkles size={24} />,
      title: 'Analysis Suite',
      description: 'Uncover hidden assumptions, perform phenomenological descriptions, and conduct deep existential analysis on your notes with specialized AI tools.',
    },
    {
      icon: <PenTool size={24} />,
      title: 'Engineering Suite',
      description: 'Transform your writing by refining clarity, adding nuance, or reframing arguments as Socratic inquiries, all while preserving the original thought.',
    },
  ];

  return (
    <>
      <Helmet>
        <title>NIHILTHEOS Protocol | AI-Assisted Philosophical Research</title>
        <meta
          name="description"
          content="A revolutionary integration of AI-assisted philosophical research and personal knowledge management. Enter the new era of contemplative and active intellectual work."
        />
      </Helmet>
      <div className={styles.pageContainer}>
        <main>
          <section className={styles.hero}>
            <div className={styles.heroContent}>
              <h1 className={styles.heroTitle}>
                The NIHILTHEOS Protocol
              </h1>
              <p className={styles.heroSubtitle}>
                A revolutionary integration of AI-assisted philosophical research and personal knowledge management.
              </p>
              <div className={styles.heroActions}>
                <Button asChild size="lg">
                  <Link to="/vault">
                    Enter The Vault <ArrowRight size={20} />
                  </Link>
                </Button>
              </div>
            </div>
          </section>

          <section className={styles.featuresSection}>
            <div className={styles.featuresGrid}>
              {features.map((feature) => (
                <div key={feature.title} className={styles.featureCard}>
                  <div className={styles.featureIcon}>{feature.icon}</div>
                  <h3 className={styles.featureTitle}>{feature.title}</h3>
                  <p className={styles.featureDescription}>{feature.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section className={styles.ctaSection}>
            <div className={styles.ctaContent}>
              <h2 className={styles.ctaTitle}>Begin Your Inquiry.</h2>
              <p className={styles.ctaText}>
                Step into a new paradigm of philosophical exploration where technology serves contemplation.
              </p>
              <Button asChild size="lg" variant="secondary">
                <Link to="/vault">
                  Start Your Work <ArrowRight size={20} />
                </Link>
              </Button>
            </div>
          </section>
        </main>
      </div>
    </>
  );
};

export default IndexPage;