
export enum Sender {
  User = "user",
  AI = "ai",
  System = "system",
}

export interface Message {
  id: string;
  sender: Sender;
  content: string;
}

export interface RitualStage {
    name: string;
    desc: string;
    duration: number;
}