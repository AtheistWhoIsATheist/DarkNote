
import { GoogleGenAI, Chat } from "@google/genai";
import type { MutableRefObject } from 'react';
import { FULL_SYSTEM_PROMPT } from '../constants';

if (!process.env.API_KEY) {
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

function createChatSession(): Chat {
  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: FULL_SYSTEM_PROMPT,
    },
  });
}

export async function* streamResponse(
  prompt: string, 
  chatRef: MutableRefObject<Chat | null>
): AsyncGenerator<string, void, undefined> {

  if (!process.env.API_KEY) {
      throw new Error("API key not found. Please ensure the API_KEY environment variable is set.");
  }
  
  if (!chatRef.current) {
    chatRef.current = createChatSession();
  }

  const chat = chatRef.current;
  
  try {
    const result = await chat.sendMessageStream({ message: prompt });
    for await (const chunk of result) {
        yield chunk.text;
    }
  } catch(e) {
    console.error("Error in sendMessageStream:", e);
    // In case of certain errors (like safety), the chat session might become invalid.
    // Resetting it for the next attempt.
    chatRef.current = null; 
    throw e;
  }
}