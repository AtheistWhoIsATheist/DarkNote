
import { useState, useCallback, useRef } from 'react';
import { Message, Sender } from '../types';
import { streamResponse } from '../services/geminiService';
import { Chat } from '@google/genai';

export const useChat = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: 'initial', sender: Sender.System, content: 'Awaiting transmission. The recursive loop is live.' }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const chatRef = useRef<Chat | null>(null);

  const sendMessage = useCallback(async (prompt: string, context: string) => {
    if (isLoading) return;

    setIsLoading(true);

    const userMessage: Message = { id: crypto.randomUUID(), sender: Sender.User, content: prompt };
    
    // Add user message and a placeholder for AI response
    setMessages(prev => [...prev, userMessage, { id: crypto.randomUUID(), sender: Sender.AI, content: '...' }]);

    try {
      const fullPrompt = context 
        ? `${prompt}\n\n--- REFERENCE CONTEXT ---\n${context}\n--- END CONTEXT ---` 
        : prompt;

      let accumulatedText = '';
      for await (const chunk of streamResponse(fullPrompt, chatRef)) {
        accumulatedText += chunk;
        setMessages(prev =>
          prev.map((msg, index) =>
            index === prev.length - 1 ? { ...msg, content: accumulatedText } : msg
          )
        );
      }
    } catch (error) {
      const err = error instanceof Error ? error : new Error('An unknown error occurred');
      console.error("Gemini API Error:", err);
      const errorMessage = `Error: Could not reach the void. ${err.message}`;
      setMessages(prev =>
        prev.map((msg, index) =>
          index === prev.length - 1 ? { ...msg, sender: Sender.System, content: errorMessage } : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  }, [isLoading]);
  
  const addSystemMessage = useCallback((content: string) => {
    const systemMessage: Message = { id: crypto.randomUUID(), sender: Sender.System, content };
    setMessages(prev => [...prev, systemMessage]);
  }, []);

  return { messages, isLoading, sendMessage, addSystemMessage };
};