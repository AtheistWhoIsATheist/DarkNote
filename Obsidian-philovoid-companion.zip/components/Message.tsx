
import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message as MessageType, Sender } from '../types';
import { UserIcon, BrainCircuitIcon, SystemIcon } from './Icons';

interface MessageProps {
  message: MessageType;
}

const senderStyles = {
  [Sender.User]: 'justify-end',
  [Sender.AI]: 'justify-start',
  [Sender.System]: 'justify-center',
};

const contentStyles = {
  [Sender.User]: 'bg-[#1a1a1e] border border-[#2a2a30] rounded-br-sm',
  [Sender.AI]: 'bg-[#121214] border border-transparent border-l-2 border-l-[#7b61ff] rounded-bl-sm',
  [Sender.System]: 'bg-transparent text-[#777] text-center italic text-sm',
};

const icons = {
  [Sender.User]: <UserIcon className="w-6 h-6 text-[#c8c8d0]" />,
  [Sender.AI]: <BrainCircuitIcon className="w-6 h-6 text-[#7b61ff]" />,
  [Sender.System]: <SystemIcon className="w-5 h-5 text-[#777]" />,
}

export const Message: React.FC<MessageProps> = ({ message }) => {
  const { sender, content } = message;

  return (
    <div className={`flex items-start gap-4 ${senderStyles[sender]}`}>
      {sender === Sender.AI && icons[sender]}
      <div className={`flex flex-col ${sender === Sender.User ? 'items-end' : 'items-start'} max-w-[85%]`}>
        <div
          className={`px-4 py-3 rounded-xl ${contentStyles[sender]}`}
        >
          {content === '...' ? (
             <div className="flex items-center justify-center space-x-1">
                <span className="w-2 h-2 bg-[#7b61ff] rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                <span className="w-2 h-2 bg-[#7b61ff] rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                <span className="w-2 h-2 bg-[#7b61ff] rounded-full animate-pulse"></span>
            </div>
          ) : (
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              className="prose prose-invert prose-p:my-0 prose-pre:bg-black/20 prose-pre:font-mono"
              components={{
                p: ({node, ...props}) => <p className="text-[#c8c8d0]" {...props} />,
              }}
            >
              {content}
            </ReactMarkdown>
          )}
        </div>
      </div>
      {sender === Sender.User && icons[sender]}
      {sender === Sender.System && <div className="w-6 h-6 flex-shrink-0"></div> /* spacer */}
    </div>
  );
};