
import React from 'react';

interface ContextEditorProps {
  context: string;
  setContext: (context: string) => void;
  isEnabled: boolean;
  setIsEnabled: (enabled: boolean) => void;
}

export const ContextEditor: React.FC<ContextEditorProps> = ({ context, setContext, isEnabled, setIsEnabled }) => {
  return (
    <div className="flex flex-col h-full bg-[#121214] border border-[#2a2a30] rounded-lg overflow-hidden">
      <div className="p-3 border-b border-[#2a2a30] flex justify-between items-center">
        <h3 className="font-bold tracking-wide">Context Note</h3>
        <div className="flex items-center gap-2">
            <span className={`text-xs font-mono ${isEnabled ? 'text-[#7b61ff]' : 'text-gray-500'}`}>
                {isEnabled ? 'ENABLED' : 'DISABLED'}
            </span>
            <button
                onClick={() => setIsEnabled(!isEnabled)}
                className={`w-12 h-6 rounded-full p-1 transition-colors ${isEnabled ? 'bg-[#7b61ff]' : 'bg-[#2a2a30]'}`}
            >
                <div className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${isEnabled ? 'translate-x-6' : 'translate-x-0'}`}></div>
            </button>
        </div>
      </div>
      <textarea
        value={context}
        onChange={(e) => setContext(e.target.value)}
        placeholder="Paste reference context here. If enabled, this will be sent to PHILOVOID with your next message."
        className="w-full flex-grow bg-transparent p-3 text-[#c8c8d0] font-mono text-xs focus:outline-none resize-none"
      />
      <div className="p-2 border-t border-[#2a2a30] text-right text-xs text-gray-500 font-mono">
        {context.length} chars
      </div>
    </div>
  );
};