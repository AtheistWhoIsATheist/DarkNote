
import React from 'react';
import { SparklesIcon, ZapIcon } from './Icons';

interface ControlsProps {
    isRunning: boolean;
    onToggleRitual: () => void;
    onGenerateKoan: () => void;
}

export const Controls: React.FC<ControlsProps> = ({ isRunning, onToggleRitual, onGenerateKoan }) => {
  return (
    <div className="bg-[#121214] border border-[#2a2a30] rounded-lg p-3">
        <h3 className="font-bold tracking-wide mb-3">Commands</h3>
        <div className="space-y-2">
            <button 
                onClick={onGenerateKoan}
                className="w-full flex items-center gap-3 text-left p-2 rounded-md font-mono text-sm hover:bg-[#2a2a30] transition-colors"
            >
                <SparklesIcon className="w-5 h-5 text-[#7b61ff]" />
                Generate a Koan of the Void
            </button>
            <button 
                onClick={onToggleRitual}
                className="w-full flex items-center gap-3 text-left p-2 rounded-md font-mono text-sm hover:bg-[#2a2a30] transition-colors"
            >
                <ZapIcon className="w-5 h-5 text-[#7b61ff]" />
                {isRunning ? 'Suspend Liturgy' : 'Invoke Liturgy'}
            </button>
        </div>
    </div>
  );
};