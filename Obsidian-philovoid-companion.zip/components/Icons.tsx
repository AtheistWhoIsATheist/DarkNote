
import React from 'react';

export const BrainCircuitIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 5a3 3 0 1 0-3 3" />
    <path d="M12 5a3 3 0 1 0 3 3" />
    <path d="M12 5a3 3 0 1 0-3-3" />
    <path d="M12 5a3 3 0 1 0 3-3" />
    <path d="M12 19a3 3 0 1 0-3 3" />
    <path d="M12 19a3 3 0 1 0 3 3" />
    <path d="M12 19a3 3 0 1 0-3-3" />
    <path d="M12 19a3 3 0 1 0 3-3" />
    <path d="M12 12a3 3 0 1 0-3 3" />
    <path d="M12 12a3 3 0 1 0 3 3" />
    <path d="M12 12a3 3 0 1 0-3-3" />
    <path d="M12 12a3 3 0 1 0 3-3" />
    <path d="M9 12a3 3 0 1 0-3-3" />
    <path d="M15 12a3 3 0 1 0-3-3" />
    <path d="M9 12a3 3 0 1 0-3 3" />
    <path d="M15 12a3 3 0 1 0-3 3" />
    <path d="M9 5a3 3 0 1 0-3-3" />
    <path d="M15 5a3 3 0 1 0-3-3" />
    <path d="M9 19a3 3 0 1 0-3-3" />
    <path d="M15 19a3 3 0 1 0-3-3" />
  </svg>
);

export const SendIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <line x1="22" y1="2" x2="11" y2="13"></line>
    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
  </svg>
);

export const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
    <circle cx="12" cy="7" r="4"></circle>
  </svg>
);

export const SystemIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 8V4H8" />
    <rect x="4" y="4" width="16" height="16" rx="2" />
    <path d="M12 12h4" />
    <path d="M12 16h4" />
    <path d="M8 12h.01" />
    <path d="M8 16h.01" />
  </svg>
);

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <path d="m12 3-1.9 4.2-4.1.6 3 2.9-.7 4.1 3.7-2 3.7 2-.7-4.1 3-2.9-4.1-.6Z"/>
        <path d="M5 11.5 3.5 13l-1.5-1.5"/>
        <path d="M19 11.5 20.5 13l1.5-1.5"/>
        <path d="M12 21v-2"/>
    </svg>
);

export const ZapIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>
);