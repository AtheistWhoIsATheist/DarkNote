export const PHILOVOID_CHAT_VIEW_TYPE = "philovoid-chat-view";
export const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:streamGenerateContent?key=";
export const MAX_CONTEXT_CHARACTERS = 30000;