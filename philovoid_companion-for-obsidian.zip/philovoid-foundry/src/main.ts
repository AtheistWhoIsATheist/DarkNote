import { App, Plugin, PluginSettingTab, Setting, Notice, TFile, WorkspaceLeaf } from "obsidian";
import { PHILOVOID_CHAT_VIEW_TYPE } from "./constants";
import { PhilovoidChatView } from "./view";

import VaultMap from "./modules/vaultMap";
import RitualMotor from "./modules/ritualMotor";
import PromptLab from "./modules/promptLab";
import LinkOracle from "./modules/linkOracle";
import MemoryBank from "./modules/memoryBank";
import QuoteMine from "./modules/quoteMine";

export interface PhilovoidSettings {
	apiKey: string;
	allowRemoteContext: boolean;
    quoteMinePath: string;
}

const DEFAULT_SETTINGS: PhilovoidSettings = {
	apiKey: "",
	allowRemoteContext: false,
    quoteMinePath: "Journal/"
};

export default class PhilovoidPlugin extends Plugin {
	settings: PhilovoidSettings;
	memoryBank: MemoryBank;
	vaultMap: VaultMap;
	ritualMotor: RitualMotor;
	promptLab: PromptLab;
	linkOracle: LinkOracle;
	quoteMine: QuoteMine;

	async onload() {
		console.log("PHILOVOID: Loading recursive ontological companion...");
		await this.loadSettings();

		this.memoryBank = new MemoryBank(this);
		this.vaultMap   = new VaultMap(this.app);
		this.promptLab  = new PromptLab(this);
		this.linkOracle = new LinkOracle(this);
		this.quoteMine  = new QuoteMine(this);
		this.ritualMotor = new RitualMotor(this);

		this.registerView(
			PHILOVOID_CHAT_VIEW_TYPE,
			(leaf) => new PhilovoidChatView(leaf, this)
		);

		this.addRibbonIcon("brain-circuit", "Open PHILOVOID Chat", () => {
			this.activateView();
		});

		this.addCommands();

		this.addSettingTab(new PhilovoidSettingTab(this.app, this));

		new Notice("PHILOVOID is online. The Void gazes back.", 5000);
	}

	async activateView() {
		this.app.workspace.detachLeavesOfType(PHILOVOID_CHAT_VIEW_TYPE);

		const rightLeaf = this.app.workspace.getRightLeaf(false);
		if (rightLeaf) {
			await rightLeaf.setViewState({
				type: PHILOVOID_CHAT_VIEW_TYPE,
				active: true,
			});
		}

		this.app.workspace.revealLeaf(
			this.app.workspace.getLeavesOfType(PHILOVOID_CHAT_VIEW_TYPE)[0]
		);
	}

    addCommands() {
        this.addCommand({
			id: "philovoid-open-chat",
			name: "PHILOVOID: Open Chat",
			callback: () => this.activateView(),
		});

		this.addCommand({
			id: "philovoid-chat-with-current-note",
			name: "PHILOVOID: Chat with current note",
			checkCallback: (checking) => {
				const file = this.app.workspace.getActiveFile();
				if (file) {
					if (!checking) {
                        this.activateView().then(() => {
                           const view = this.app.workspace.getLeavesOfType(PHILOVOID_CHAT_VIEW_TYPE)[0]?.view;
                           if (view instanceof PhilovoidChatView) {
                               view.setContextMessage(file);
                           }
                        });
                    }
					return true;
				}
				return false;
			},
		});

		this.addCommand({
			id: "philovoid-suggest-links",
			name: "PHILOVOID: Suggest links for current note",
			callback: () => this.linkOracle.suggestAndDisplay(),
		});

		this.addCommand({
			id: "philovoid-invoke-liturgy",
			name: "PHILOVOID: Invoke Liturgy of Recursive Unknowing",
			callback: () => this.ritualMotor.start(),
		});

		this.addCommand({
			id: "philovoid-generate-koan",
			name: "PHILOVOID: Generate a Koan of the Void",
			callback: () => this.promptLab.generateKoan(),
		});

        this.addCommand({
            id: 'philovoid-mine-quotes',
            name: 'PHILOVOID: Mine quotes from specified path',
            callback: () => this.quoteMine.extractAndCompileQuotes(),
        });
    }

	onunload() {
		console.log("PHILOVOID: Returning to the Void.");
		new Notice("PHILOVOID has returned to the Void.", 5000);
	}

	async loadSettings() {
		this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
	}

	async saveSettings() {
		await this.saveData(this.settings);
	}
}

class PhilovoidSettingTab extends PluginSettingTab {
	plugin: PhilovoidPlugin;

	constructor(app: App, plugin: PhilovoidPlugin) {
		super(app, plugin);
		this.plugin = plugin;
	}

	display(): void {
		const { containerEl } = this;
		containerEl.empty();
		containerEl.createEl("h2", { text: "PHILOVOID Settings" });
        containerEl.createEl("p", { text: "Configure the parameters of the ontological companion."});

		new Setting(containerEl)
			.setName("Gemini API Key")
			.setDesc("Your Google AI Studio API key. Stored locally. Required for live AI responses.")
			.addText((text) =>
				text
					.setPlaceholder("Enter your API key")
					.setValue(this.plugin.settings.apiKey)
					.onChange(async (value) => {
						this.plugin.settings.apiKey = value.trim();
						await this.plugin.saveSettings();
					}),
			);

		new Setting(containerEl)
			.setName("Allow Remote Context Upload")
			.setDesc("Permit PHILOVOID to upload note content to the Gemini API for context-aware responses. If disabled, only your chat messages are sent.")
			.addToggle((toggle) =>
				toggle.setValue(this.plugin.settings.allowRemoteContext).onChange(async (value) => {
					this.plugin.settings.allowRemoteContext = value;
					await this.plugin.saveSettings();
				}),
			);

        new Setting(containerEl)
            .setName("Quote-Mine Path")
            .setDesc("The vault path (folder) to scan when using the QuoteMine command. E.g., 'Sources/Journal/'.")
            .addText((text) =>
                text
                    .setPlaceholder("path/to/quotes/")
                    .setValue(this.plugin.settings.quoteMinePath)
                    .onChange(async (value) => {
                        this.plugin.settings.quoteMinePath = value;
                        await this.plugin.saveSettings();
                    })
            );
	}
}