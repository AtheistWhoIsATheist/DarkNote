import { Notice, TFile, App } from "obsidian";
import PhilovoidPlugin from "../main";

const STOP_WORDS = new Set(['a', 'an', 'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'is', 'are', 'was', 'were', 'it', 'i', 'you', 'he', 'she', 'they', 'we', 'me', 'him', 'her', 'them', 'us', 'my', 'your', 'his', 'its', 'our', 'their']);

export default class LinkOracle {
    private plugin: PhilovoidPlugin;
    private app: App;

    constructor(plugin: PhilovoidPlugin) {
        this.plugin = plugin;
        this.app = plugin.app;
    }

    private getWords(text: string): Set<string> {
        const words = text
            .toLowerCase()
            .replace(/[^\w\s]/g, '')
            .split(/\s+/)
            .filter(word => word.length > 2 && !STOP_WORDS.has(word));
        return new Set(words);
    }

    public async suggestAndDisplay() {
        const activeFile = this.app.workspace.getActiveFile();
        if (!activeFile) {
            new Notice("No active file to analyze.");
            return;
        }

        new Notice("Link Oracle: Analyzing conceptual connections...", 3000);

        const targetInfo = this.plugin.vaultMap.getFileInfo(activeFile.path);
        if (!targetInfo) {
            new Notice("Could not read active file from VaultMap cache.");
            return;
        }

        const targetWords = this.getWords(targetInfo.content);
        const suggestions: { path: string; score: number }[] = [];

        for (const [path, fileInfo] of this.plugin.vaultMap.fileCache.entries()) {
            if (path === activeFile.path) continue;

            const candidateWords = this.getWords(fileInfo.content);
            const intersection = new Set([...targetWords].filter(word => candidateWords.has(word)));
            const score = intersection.size;

            if (score > 2) {
                suggestions.push({ path: fileInfo.path.replace(/\.md$/, ''), score });
            }
        }

        const sortedSuggestions = suggestions.sort((a, b) => b.score - a.score).slice(0, 5);

        if (sortedSuggestions.length === 0) {
            new Notice("Link Oracle: No strong connections found in the void.", 5000);
            return;
        }

        const suggestionText = sortedSuggestions
            .map(s => `[[ ${s.path} ]] (Score: ${s.score})`)
            .join("\n");

        new Notice(`Link Oracle Suggestions:\n${suggestionText}`, 15000);
    }
}