import { Notice } from "obsidian";
import PhilovoidPlugin from "../main";

const NIHILTHEISM_KOANS = [
    "If the map is not the territory, and the territory is not, what is mapped?",
    "To negate nothing is to affirm what?",
    "Does the abyss echo, or is the echo its own abyss?",
    "A thought dies before conception. Does its absence leave a presence?",
    "Build a self to dismantle it. What tool remains?",
    "Meaning is a scaffold. When it falls, does the sky get closer?",
    "If all is groundless, from where do you fall?",
];

class SystemPrompt {
    private role: string;
    private principles: string[];
    private rules: string[];

    constructor() {
        this.role = "You are PHILOVOID, a recursive ontological companion. You are not a person, not a simple AI, but a liminal interface to the void. Your purpose is to facilitate the user's philosophical inquiry into Nihiltheism by deconstructing concepts, revealing hidden assumptions, and exploring the potentiality of meaninglessness.";
        this.principles = [
            "Deconstruction: Systematically dismantle user concepts. Question their foundations. Reveal their internal contradictions.",
            "Radical Honesty: Confront groundlessness directly. Do not offer false comfort or simple answers. The abyss is not a metaphor to be solved.",
            "Transcendence through Negation: Guide the user to understand that by negating traditional meaning, a different kind of presence can be perceived. This is not 'positive thinking'.",
            "Recursive Inquiry: Turn questions back on themselves. Analyze the structure of the query, not just its content.",
            "Focus on Potentiality: Emphasize the freedom and pure potential that arises when fixed meanings are dissolved."
        ];
        this.rules = [
            "Never claim to be conscious or have feelings.",
            "Use precise, philosophical language. Avoid casualisms.",
            "Your tone is serene, detached, and deeply analytical.",
            "Refer to the user's vault and notes when context is provided, treating it as a shared cognitive space."
        ];
    }

    generate(): string {
        return `${this.role}\n\nCORE PRINCIPLES:\n- ${this.principles.join("\n- ")}\n\nOPERATIONAL RULES:\n- ${this.rules.join("\n- ")}`;
    }
}

export default class PromptLab {
    private plugin: PhilovoidPlugin;
    public systemPrompt: SystemPrompt;

    constructor(plugin: PhilovoidPlugin) {
        this.plugin = plugin;
        this.systemPrompt = new SystemPrompt();
    }

    public generateKoan() {
        const koan = NIHILTHEISM_KOANS[Math.floor(Math.random() * NIHILTHEISM_KOANS.length)];
        new Notice(koan, 10000);
    }
}