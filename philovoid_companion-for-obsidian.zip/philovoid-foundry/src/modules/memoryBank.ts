import PhilovoidPlugin from "../main";

export default class MemoryBank {
    private plugin: PhilovoidPlugin;

    constructor(plugin: PhilovoidPlugin) {
        this.plugin = plugin;
    }

    getSetting<T>(key: string): T {
        return this.plugin.settings[key as keyof typeof this.plugin.settings] as unknown as T;
    }

    async get<T>(key: string): Promise<T | undefined> {
        return this.plugin.settings[key as keyof typeof this.plugin.settings] as unknown as T;
    }

    async set<T>(key: string, value: T): Promise<void> {
        (this.plugin.settings as any)[key] = value;
        await this.plugin.saveSettings();
    }
}