import { App, TFile, CachedMetadata, parseFrontMatterTags } from "obsidian";

export interface FileInfo {
    path: string;
    content: string;
    links: string[];
    tags: string[];
    frontmatter: Record<string, any> | null;
}

export default class VaultMap {
    private app: App;
    public fileCache: Map<string, FileInfo> = new Map();

    constructor(app: App) {
        this.app = app;
        this.app.workspace.onLayoutReady(() => this.fullRefresh());
        window.setInterval(() => this.fullRefresh(), 5 * 60 * 1000);
        this.app.vault.on('modify', (file) => { if (file instanceof TFile) this.updateFile(file); });
        this.app.vault.on('delete', (file) => { if (file instanceof TFile) this.fileCache.delete(file.path); });
        this.app.vault.on('rename', (file, oldPath) => { if (file instanceof TFile) { this.fileCache.delete(oldPath); this.updateFile(file); } });
    }

    async fullRefresh() {
        console.log("VaultMap: Performing full vault re-crawl.");
        this.fileCache.clear();
        const files = this.app.vault.getMarkdownFiles();
        for (const file of files) {
            await this.updateFile(file);
        }
        console.log(`VaultMap: Crawl complete. Indexed ${this.fileCache.size} notes.`);
    }

    async updateFile(file: TFile) {
        const content = await this.app.vault.cachedRead(file);
        const metadata = this.app.metadataCache.getFileCache(file);
        const fileInfo: FileInfo = {
            path: file.path,
            content: content,
            links: metadata?.links?.map(l => l.link) ?? [],
            tags: this.getAllTags(metadata),
            frontmatter: metadata?.frontmatter ?? null
        };
        this.fileCache.set(file.path, fileInfo);
    }

    public getFileInfo(path: string): FileInfo | undefined {
        return this.fileCache.get(path);
    }

    getAllTags(cache: CachedMetadata | null): string[] {
        if (!cache) return [];
        const tags = new Set<string>();
        (cache.tags ?? []).forEach(t => tags.add(t.tag));
        (parseFrontMatterTags(cache.frontmatter) ?? []).forEach(t => tags.add(t));
        return Array.from(tags);
    }
}