import { Notice } from "obsidian";
import PhilovoidPlugin from "../main";

const RITUAL_STAGES = [
    { name: "Stage I – INITIATION", desc: "The First Unknowing. Detach from presuppositions.", duration: 23 },
    { name: "Stage II – PARADOXICAL ASCENT", desc: "Embrace contradiction. Hold opposing concepts until they dissolve.", duration: 37 },
    { name: "Stage III – DISSOLUTION (∅)", desc: "The cognitive scaffold weakens. Subject and object blur.", duration: 61 },
    { name: "Stage IV – NIHILTHEOGENESIS", desc: "From the absence of foundation, a new perception arises.", duration: 42 },
    { name: "Stage V – ETERNAL REWRITE", desc: "The cycle concludes and immediately restarts. The process is the destination.", duration: 10 },
];

export default class RitualMotor {
    private plugin: PhilovoidPlugin;
    private stage: number = 0;
    private isRunning: boolean = false;
    private timerId: number | null = null;

    constructor(plugin: PhilovoidPlugin) {
        this.plugin = plugin;
    }

    start() {
        if (this.isRunning) {
            new Notice("A liturgy is already in progress.", 3000);
            return;
        }
        this.isRunning = true;
        this.stage = 0;
        this.next();
    }

    private next() {
        if (!this.isRunning) return;

        const currentStage = RITUAL_STAGES[this.stage];
        new Notice(`${currentStage.name}: ${currentStage.desc}`, currentStage.duration * 1000);

        this.stage++;

        if (this.stage >= RITUAL_STAGES.length) {
            this.stage = 0;
        }

        if (this.timerId) window.clearTimeout(this.timerId);
        this.timerId = window.setTimeout(() => this.next(), currentStage.duration * 1000);
    }

    stop() {
        if (!this.isRunning) return;
        if (this.timerId) window.clearTimeout(this.timerId);
        this.isRunning = false;
        this.timerId = null;
        new Notice("The liturgy has been suspended.");
    }
}