export function truncateText(text: string, maxChars: number): string {
    if (text.length <= maxChars) {
        return text;
    }
    const half = Math.floor(maxChars / 2);
    const start = text.substring(0, half);
    const end = text.substring(text.length - half);
    return `${start}\n\n... [CONTENT TRUNCATED FOR BREVITY] ...\n\n${end}`;
}