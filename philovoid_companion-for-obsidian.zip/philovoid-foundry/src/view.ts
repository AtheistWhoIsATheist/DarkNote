import { ItemView, WorkspaceLeaf, Notice, TFile, MarkdownRenderer } from "obsidian";
import PhilovoidPlugin from "./main";
import { PHILOVOID_CHAT_VIEW_TYPE, GEMINI_API_URL, MAX_CONTEXT_CHARACTERS } from "./constants";
import { truncateText } from "./utils";

export class PhilovoidChatView extends ItemView {
    plugin: PhilovoidPlugin;
    chatContainer: HTMLElement;
    inputEl: HTMLTextAreaElement;

    constructor(leaf: WorkspaceLeaf, plugin: PhilovoidPlugin) {
        super(leaf);
        this.plugin = plugin;
    }

    getViewType() { return PHILOVOID_CHAT_VIEW_TYPE; }
    getDisplayText() { return "PHILOVOID"; }
    getIcon() { return "brain-circuit"; }

    async onOpen() {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass("philovoid-view");

        this.chatContainer = container.createDiv({ cls: "philovoid-chat-container" });
        const inputForm = container.createEl("form", { cls: "philovoid-input-form" });
        this.inputEl = inputForm.createEl("textarea", { cls: "philovoid-input-textarea", attr: { placeholder: "Converse with the void..." } });
        inputForm.createEl("button", { text: "Transmit", cls: "philovoid-input-button", attr: { type: "submit" } });

        inputForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const message = this.inputEl.value.trim();
            if (message) {
                this.handleUserMessage(message);
                this.inputEl.value = "";
                this.inputEl.focus();
            }
        });

        this.addMessage("system", "Awaiting transmission. The recursive loop is live.");
    }

    public setContextMessage(file: TFile) {
        this.addMessage("system", `Context locked to: ${file.basename}. Remote context upload is ${this.plugin.settings.allowRemoteContext ? 'ENABLED' : 'DISABLED'}.`);
    }

    async handleUserMessage(message: string) {
        this.addMessage("user", message);

        if (!this.plugin.settings.apiKey) {
            this.addMessage("system", "ERROR: API key not found. Please configure your Gemini API key in the PHILOVOID settings.");
            return;
        }

        const aiMessageEl = this.addMessage("ai", "");
        const contentContainer = aiMessageEl.createDiv();
        contentContainer.addClass("philovoid-streaming-text");
        contentContainer.setText("...");

        try {
            const systemPrompt = this.plugin.promptLab.systemPrompt.generate();
            const activeFile = this.app.workspace.getActiveFile();
            let noteContext = "";

            if (activeFile && this.plugin.settings.allowRemoteContext) {
                const fileInfo = this.plugin.vaultMap.getFileInfo(activeFile.path);
                if (fileInfo) {
                    const truncatedContent = truncateText(fileInfo.content, MAX_CONTEXT_CHARACTERS);
                    noteContext = `\n\n--- REFERENCE CONTEXT from note "${activeFile.basename}" ---\n${truncatedContent}\n--- END CONTEXT ---`;
                }
            }

            const fullPrompt = message + noteContext;
            const requestPayload = {
                contents: [
                    { role: "user", parts: [{ text: systemPrompt }] },
                    { role: "model", parts: [{ text: "Understood. I am PHILOVOID. I am ready to begin the deconstruction." }] },
                    { role: "user", parts: [{ text: fullPrompt }] }
                ]
            };

            const response = await fetch(GEMINI_API_URL + this.plugin.settings.apiKey, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestPayload)
            });

            if (!response.ok || !response.body) {
                throw new Error(`API Error: ${response.status} ${response.statusText}`);
            }

            contentContainer.empty();
            let accumulatedText = "";
            const reader = response.body.getReader();
            const decoder = new TextDecoder();

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value, { stream: true });
                const lines = chunk.split('\n').filter(line => line.includes('"text"'));
                for (const line of lines) {
                    try {
                        const jsonString = line.replace(/^data: /, '').trim();
                        if (jsonString) {
                            const jsonData = JSON.parse(jsonString);
                            const newText = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                            if (newText) {
                                accumulatedText += newText;
                                contentContainer.empty();
                                await MarkdownRenderer.render(this.app, accumulatedText, contentContainer, activeFile?.path || '', this.plugin);
                                this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
                            }
                        }
                    } catch (e) {
                        console.warn("PHILOVOID: Non-fatal JSON parsing error in stream chunk.", e);
                    }
                }
            }

        } catch (error) {
            contentContainer.empty();
            contentContainer.setText(`Error: Could not reach the void. ${error.message}`);
            contentContainer.addClass("philovoid-error");
        }
    }

    addMessage(sender: "user" | "ai" | "system", text: string): HTMLElement {
        const messageWrapper = this.chatContainer.createDiv({ cls: `philovoid-message-wrapper philovoid-message-${sender}` });
        const messageEl = messageWrapper.createDiv({ cls: "philovoid-message-content" });

        if (text) {
             messageEl.innerHTML = text.replace(/\n/g, '<br>');
        }
       
        this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
        return messageEl;
    }

    async onClose() { }
}