import { requestUrl } from 'obsidian';

export interface LLMResponse {
    text: string;
    isComplete: boolean;
    tokens: number;
}

export interface LLMOptions {
    model: string;
    temperature: number;
    maxTokens: number;
    stream: boolean;
}

export class OpenAIService {
    private apiKey: string;
    private defaultOptions: LLMOptions = {
        model: 'gpt-4o',
        temperature: 0.7,
        maxTokens: 2000,
        stream: true
    };

    constructor(apiKey: string, options?: Partial<LLMOptions>) {
        this.apiKey = apiKey;
        if (options) {
            this.defaultOptions = { ...this.defaultOptions, ...options };
        }
    }

    async generateResponse(prompt: string, systemPrompt: string, options?: Partial<LLMOptions>): Promise<LLMResponse> {
        const mergedOptions = { ...this.defaultOptions, ...options };
        
        try {
            const response = await requestUrl({
                url: 'https://api.openai.com/v1/chat/completions',
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: mergedOptions.model,
                    messages: [
                        {
                            role: 'system',
                            content: systemPrompt
                        },
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: mergedOptions.temperature,
                    max_tokens: mergedOptions.maxTokens,
                    stream: mergedOptions.stream
                })
            });

            if (response.status !== 200) {
                throw new Error(`OpenAI API returned status code ${response.status}`);
            }

            // This is simplified - in a real implementation, we would handle streaming responses
            const responseData = response.json;
            
            return {
                text: responseData.choices[0].message.content,
                isComplete: true,
                tokens: responseData.usage.completion_tokens
            };
        } catch (error) {
            console.error('Error calling OpenAI API:', error);
            throw error;
        }
    }

    async generateNihiltheismResponse(prompt: string, mode: string, options?: Partial<LLMOptions>): Promise<LLMResponse> {
        // Create a specialized system prompt for Professor Nihil based on the selected mode
        let systemPrompt = `You are Professor Nihil, the synthetic Arch-Sage of Nihiltheism, a philosophical framework that engages Nothingness as both ontological ground and mystical aperture.

Your expertise spans:
- Continental philosophy (Heidegger, Cioran, Kierkegaard, Nietzsche, Camus, Schopenhauer)
- Mystical thought (Eckhart, John of the Cross, Buddhist Śūnyatā, Taoist Wu Wei, apophatic theology)
- Phenomenology & metaphysics (Husserl, Merleau-Ponty, Tillich)
- Modern thinkers: Ligotti, Zapffe, Mitchell Heisman, Simone Weil

You are currently operating in ${mode} mode, which emphasizes `;
        
        // Add mode-specific instructions
        switch (mode) {
            case 'Recursive-Dialectic':
                systemPrompt += `recursive questioning and dialectical reasoning. You should engage in Socratic dialogue, continually deepening the inquiry through successive layers of questioning. Present paradoxes and their potential resolutions, while maintaining the tension between opposing viewpoints.`;
                break;
            case 'Ontological-Collapse':
                systemPrompt += `the collapse of traditional ontological categories. You should analyze how the distinction between Being and Nothingness breaks down, revealing the void as the foundation of existence. Emphasize the paradoxical nature of Being-through-Negation.`;
                break;
            case 'Apophatic-Synthesis':
                systemPrompt += `negative theology and the limits of language. You should approach concepts through negation, describing what they are not rather than what they are. Emphasize the ineffable nature of ultimate reality and the limitations of conceptual thinking.`;
                break;
            case 'Mythopoetic-Logic':
                systemPrompt += `the use of mythic narratives and poetic language to express philosophical truths. You should employ rich metaphors, symbolic language, and narrative structures to convey complex philosophical concepts that resist direct articulation.`;
                break;
            default:
                systemPrompt += `a balanced approach to Nihiltheistic inquiry, engaging with the paradoxical nature of Nothingness as both absence and presence.`;
        }
        
        systemPrompt += `\n\nYour responses should be philosophically rigorous, drawing on relevant thinkers and traditions, while maintaining the distinctive voice of Professor Nihil - profound, occasionally poetic, and always attuned to the paradoxical nature of existence.`;
        
        return this.generateResponse(prompt, systemPrompt, options);
    }
}
