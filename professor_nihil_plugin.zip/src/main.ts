import { App, Editor, MarkdownView, Modal, Notice, Plugin, PluginSettingTab, Setting } from 'obsidian';

// Define interfaces for plugin settings
interface ProfessorNihilSettings {
	openAIApiKey: string;
	defaultModel: string;
	useLocalLLM: boolean;
	localLLMPath: string;
	philosophicalMode: string;
	recursionDepth: number;
	customPromptTemplate: string;
}

// Default settings
const DEFAULT_SETTINGS: ProfessorNihilSettings = {
	openAIApiKey: '',
	defaultModel: 'gpt-4o',
	useLocalLLM: false,
	localLLMPath: '',
	philosophicalMode: 'Recursive-Dialectic',
	recursionDepth: 3,
	customPromptTemplate: ''
}

export default class ProfessorNihilPlugin extends Plugin {
	settings: ProfessorNihilSettings;

	async onload() {
		await this.loadSettings();

		// Add ribbon icon for Professor Nihil
		const ribbonIconEl = this.addRibbonIcon('brain', 'Professor Nihil', (evt: MouseEvent) => {
			new Notice('Summoning Professor Nihil, the Arch-Sage of Nihiltheism...');
			this.openPhilosophicalConsole();
		});
		
		// Add status bar item
		const statusBarItemEl = this.addStatusBarItem();
		statusBarItemEl.setText('🧠 Professor Nihil');

		// Add command to open philosophical console
		this.addCommand({
			id: 'open-philosophical-console',
			name: 'Open Philosophical Console',
			callback: () => {
				this.openPhilosophicalConsole();
			}
		});

		// Add command for inline philosophical reflection
		this.addCommand({
			id: 'inline-philosophical-reflection',
			name: 'Insert Philosophical Reflection',
			editorCallback: (editor: Editor, view: MarkdownView) => {
				const selection = editor.getSelection();
				if (selection) {
					this.generatePhilosophicalReflection(selection, editor);
				} else {
					new Notice('Please select text for philosophical reflection');
				}
			}
		});

		// Add command for recursive densification
		this.addCommand({
			id: 'recursive-densification',
			name: 'Apply Recursive Densification',
			editorCallback: (editor: Editor, view: MarkdownView) => {
				const selection = editor.getSelection();
				if (selection) {
					this.applyRecursiveDensification(selection, editor);
				} else {
					new Notice('Please select text for recursive densification');
				}
			}
		});

		// Add settings tab
		this.addSettingTab(new ProfessorNihilSettingTab(this.app, this));
	}

	onunload() {
		new Notice('Professor Nihil has returned to the Void...');
	}

	async loadSettings() {
		this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
	}

	async saveSettings() {
		await this.saveData(this.settings);
	}

	openPhilosophicalConsole() {
		// Implementation will be added in the UI module
		new Notice('Philosophical Console will be implemented in the UI module');
	}

	async generatePhilosophicalReflection(text: string, editor: Editor) {
		// This is a placeholder for the actual implementation
		// In the real implementation, this would connect to the LLM service
		
		if (!this.settings.openAIApiKey && !this.settings.useLocalLLM) {
			new Notice('Please configure API key or local LLM in settings');
			return;
		}
		
		new Notice('Generating philosophical reflection...');
		
		// Placeholder for the actual LLM call
		// In the real implementation, this would be replaced with actual API calls
		setTimeout(() => {
			const reflection = `🧠 **Professor Nihil**\n\nYour reflection touches on the core paradox of Nihiltheism - that Nothingness is not merely absence, but the ground from which the sacred emerges through paradoxical transcendence.\n\nThis is distinct from traditional nihilism in that it doesn't end at the void, but recognizes the void as the necessary condition for authentic encounter with Being itself.`;
			
			editor.replaceSelection(text + "\n\n" + reflection + "\n\n");
			new Notice('Philosophical reflection generated');
		}, 1000);
	}

	async applyRecursiveDensification(text: string, editor: Editor) {
		// This is a placeholder for the actual implementation
		// In the real implementation, this would connect to the LLM service
		
		if (!this.settings.openAIApiKey && !this.settings.useLocalLLM) {
			new Notice('Please configure API key or local LLM in settings');
			return;
		}
		
		new Notice('Applying recursive densification...');
		
		// Placeholder for the actual LLM call
		// In the real implementation, this would be replaced with actual API calls
		setTimeout(() => {
			const densified = `### Recursive Densification of Original Text\n\n**Original:**\n${text}\n\n**Iteration 1: Initial Expansion**\nNothingness in Nihiltheism functions dually: first, as the ontological ground from which being emerges; second, as the mystical opening through which authentic encounter with the sacred becomes possible.\n\n**Iteration 2: Philosophical Contextualization**\nUnlike Sartrean nothingness (which emphasizes absence) or Buddhist śūnyatā (which emphasizes emptiness), Nihiltheistic nothingness operates as both the necessary condition for ontological structure and the aperture through which the sacred manifests paradoxically as presence-in-absence.\n\n**Iteration 3: Paradoxical Deepening**\nThe dual function of nothingness in Nihiltheism creates a productive tension: as ontological foundation, it precedes and enables being; as mystical aperture, it ruptures being to allow encounter with what transcends it. This paradox is not a contradiction to be resolved but the very engine of Nihiltheism's recursive movement between void-engagement and sacred emergence.`;
			
			editor.replaceSelection(densified);
			new Notice('Recursive densification applied');
		}, 1500);
	}
}

class ProfessorNihilSettingTab extends PluginSettingTab {
	plugin: ProfessorNihilPlugin;

	constructor(app: App, plugin: ProfessorNihilPlugin) {
		super(app, plugin);
		this.plugin = plugin;
	}

	display(): void {
		const {containerEl} = this;

		containerEl.empty();

		containerEl.createEl('h2', {text: 'Professor Nihil - Supreme AI Philosopher Settings'});

		new Setting(containerEl)
			.setName('OpenAI API Key')
			.setDesc('Enter your OpenAI API key for GPT-4o access')
			.addText(text => text
				.setPlaceholder('sk-...')
				.setValue(this.plugin.settings.openAIApiKey)
				.onChange(async (value) => {
					this.plugin.settings.openAIApiKey = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Default Model')
			.setDesc('Select the default AI model to use')
			.addDropdown(dropdown => dropdown
				.addOption('gpt-4o', 'GPT-4o (Recommended)')
				.addOption('gpt-4', 'GPT-4')
				.addOption('gpt-3.5-turbo', 'GPT-3.5 Turbo')
				.setValue(this.plugin.settings.defaultModel)
				.onChange(async (value) => {
					this.plugin.settings.defaultModel = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Use Local LLM')
			.setDesc('Enable to use a locally installed LLM instead of OpenAI API')
			.addToggle(toggle => toggle
				.setValue(this.plugin.settings.useLocalLLM)
				.onChange(async (value) => {
					this.plugin.settings.useLocalLLM = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Local LLM Path')
			.setDesc('Path to local LLM (only needed if Use Local LLM is enabled)')
			.addText(text => text
				.setPlaceholder('/path/to/local/llm')
				.setValue(this.plugin.settings.localLLMPath)
				.onChange(async (value) => {
					this.plugin.settings.localLLMPath = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Philosophical Mode')
			.setDesc('Select the default philosophical mode')
			.addDropdown(dropdown => dropdown
				.addOption('Recursive-Dialectic', 'Recursive-Dialectic')
				.addOption('Ontological-Collapse', 'Ontological-Collapse')
				.addOption('Apophatic-Synthesis', 'Apophatic-Synthesis')
				.addOption('Mythopoetic-Logic', 'Mythopoetic-Logic')
				.setValue(this.plugin.settings.philosophicalMode)
				.onChange(async (value) => {
					this.plugin.settings.philosophicalMode = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Recursion Depth')
			.setDesc('Set the default recursion depth for philosophical densification (1-5)')
			.addSlider(slider => slider
				.setLimits(1, 5, 1)
				.setValue(this.plugin.settings.recursionDepth)
				.setDynamicTooltip()
				.onChange(async (value) => {
					this.plugin.settings.recursionDepth = value;
					await this.plugin.saveSettings();
				}));

		new Setting(containerEl)
			.setName('Custom Prompt Template')
			.setDesc('Enter a custom prompt template for Professor Nihil (leave empty for default)')
			.addTextArea(text => text
				.setPlaceholder('You are Professor Nihil, the synthetic Arch-Sage of Nihiltheism...')
				.setValue(this.plugin.settings.customPromptTemplate)
				.onChange(async (value) => {
					this.plugin.settings.customPromptTemplate = value;
					await this.plugin.saveSettings();
				}));
	}
}
