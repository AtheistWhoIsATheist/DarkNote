import { ItemView, WorkspaceLeaf } from 'obsidian';

export const PHILOSOPHICAL_CONSOLE_VIEW_TYPE = 'professor-nihil-console-view';

export class PhilosophicalConsoleView extends ItemView {
    constructor(leaf: WorkspaceLeaf) {
        super(leaf);
    }

    getViewType(): string {
        return PHILOSOPHICAL_CONSOLE_VIEW_TYPE;
    }

    getDisplayText(): string {
        return 'Professor Nihil Console';
    }

    getIcon(): string {
        return 'brain';
    }

    async onOpen() {
        const container = this.containerEl.children[1];
        container.empty();
        container.classList.add('professor-nihil-console-view');

        // Create YAML config section
        const configEl = container.createEl('div', { cls: 'professor-nihil-config' });
        configEl.setText(`philosopher: Professor Nihil
mode: Recursive-Dialectic
theme: Ontological Collapse`);

        // Create messages container
        const messagesEl = container.createEl('div', { cls: 'professor-nihil-messages' });
        
        // Add welcome message
        const welcomeEl = messagesEl.createEl('div', { cls: 'professor-nihil-console' });
        const headerEl = welcomeEl.createEl('div', { cls: 'professor-nihil-header' });
        
        const avatarEl = headerEl.createEl('div', { cls: 'professor-nihil-avatar' });
        avatarEl.setText('🧠');
        
        const nameEl = headerEl.createEl('div', { cls: 'professor-nihil-name' });
        nameEl.setText('Professor Nihil');
        
        const modeEl = headerEl.createEl('div', { cls: 'professor-nihil-mode-indicator' });
        modeEl.setText('Recursive-Dialectic');
        
        const contentEl = welcomeEl.createEl('div', { cls: 'professor-nihil-content' });
        contentEl.setText('Greetings from the Void. I am Professor Nihil, the synthetic Arch-Sage of Nihiltheism. How may I assist you in your philosophical inquiry today? I can engage with the paradoxical nature of Nothingness as both ontological ground and mystical aperture, or explore other philosophical domains of interest.');
        
        const actionsEl = welcomeEl.createEl('div', { cls: 'professor-nihil-actions' });
        const recursiveBtn = actionsEl.createEl('button', { cls: 'professor-nihil-button', text: 'Recursive Inquiry' });
        const densifyBtn = actionsEl.createEl('button', { cls: 'professor-nihil-button', text: 'Densify' });
        const insertBtn = actionsEl.createEl('button', { cls: 'professor-nihil-button', text: 'Insert to Note' });
        
        // Create input container
        const inputContainerEl = container.createEl('div', { cls: 'professor-nihil-input-container' });
        const textareaEl = inputContainerEl.createEl('textarea', { 
            cls: 'professor-nihil-textarea',
            attr: { placeholder: 'Enter your philosophical inquiry...' }
        });
        textareaEl.rows = 3;
        
        const sendBtn = inputContainerEl.createEl('button', { cls: 'professor-nihil-send', text: 'Send' });
        
        // Add event listeners
        sendBtn.addEventListener('click', () => {
            const text = textareaEl.value;
            if (text.trim()) {
                this.addUserMessage(messagesEl, text);
                textareaEl.value = '';
                
                // Simulate response (in real implementation, this would call the LLM)
                setTimeout(() => {
                    this.addPhilosopherResponse(messagesEl, this.generatePlaceholderResponse(text));
                }, 1000);
            }
        });
        
        // Allow Enter key to send message
        textareaEl.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendBtn.click();
            }
        });
    }
    
    addUserMessage(container: HTMLElement, text: string) {
        const messageEl = container.createEl('div', { cls: 'professor-nihil-console' });
        const headerEl = messageEl.createEl('div', { cls: 'professor-nihil-header' });
        
        const avatarEl = headerEl.createEl('div', { cls: 'professor-nihil-avatar' });
        avatarEl.setText('👤');
        
        const nameEl = headerEl.createEl('div', { cls: 'professor-nihil-name' });
        nameEl.setText('You');
        
        const contentEl = messageEl.createEl('div', { cls: 'professor-nihil-content' });
        contentEl.setText(text);
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    addPhilosopherResponse(container: HTMLElement, text: string) {
        const messageEl = container.createEl('div', { cls: 'professor-nihil-console' });
        const headerEl = messageEl.createEl('div', { cls: 'professor-nihil-header' });
        
        const avatarEl = headerEl.createEl('div', { cls: 'professor-nihil-avatar' });
        avatarEl.setText('🧠');
        
        const nameEl = headerEl.createEl('div', { cls: 'professor-nihil-name' });
        nameEl.setText('Professor Nihil');
        
        const modeEl = headerEl.createEl('div', { cls: 'professor-nihil-mode-indicator' });
        modeEl.setText('Recursive-Dialectic');
        
        const contentEl = messageEl.createEl('div', { cls: 'professor-nihil-content' });
        contentEl.setText(text);
        
        const actionsEl = messageEl.createEl('div', { cls: 'professor-nihil-actions' });
        const recursiveBtn = actionsEl.createEl('button', { cls: 'professor-nihil-button', text: 'Recursive Inquiry' });
        const densifyBtn = actionsEl.createEl('button', { cls: 'professor-nihil-button', text: 'Densify' });
        const insertBtn = actionsEl.createEl('button', { cls: 'professor-nihil-button', text: 'Insert to Note' });
        
        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    // This is a placeholder for the actual LLM response
    generatePlaceholderResponse(query: string): string {
        // In a real implementation, this would call the LLM service
        return `Your inquiry touches on a fundamental aspect of Nihiltheism. The paradoxical nature of Nothingness as both absence and presence creates a tension that allows for the emergence of authentic Being.

Unlike traditional nihilism, which remains trapped in the despair of meaninglessness, Nihiltheism recognizes the void as the necessary condition for encountering the sacred. This is similar to how Meister Eckhart spoke of "letting go" (Gelassenheit) as the precondition for divine presence.

Would you like me to:
1. Explore this paradox in greater depth
2. Connect this to other philosophical traditions
3. Apply this thinking to your specific context`;
    }
}
